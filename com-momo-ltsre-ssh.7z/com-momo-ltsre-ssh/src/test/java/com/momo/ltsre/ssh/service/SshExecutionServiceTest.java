package com.momo.ltsre.ssh.service;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import lombok.extern.slf4j.Slf4j;

/**
 * SSH 會話管理器測試類
 * 
 * <p>測試新的會話持久化架構：
 * 1. createSSHSession - 建立會話並獲得 apiKey
 * 2. executeSSHCommand - 通過 apiKey 執行命令（隊列序列化）
 * </p>
 * 
 * @author SSH MCP Server Team
 * @version 2.0.0
 * @since 2025-11-04
 */
@Slf4j
@SpringBootTest
class SshExecutionServiceTest {

    // SSH 會話管理器實例
    @Autowired
    private SshSessionManager sshSessionManager;

    /** 測試用的私鑰內容（PEM 格式） */
    private static final String TEST_PRIVATE_KEY = """
-----BEGIN RSA PRIVATE KEY-----
MIIJKAIBAAKCAgEA6OmiVeJds/pI0kPY4rjaqcM4CDwSSwKQlirDJoRhFOvWA2vx
GFkhaVHhCDKiBdpMW/qZ60XGw3xL/JZZ7x2fIzeG/7RWqIXv1JzfqbnWW0si+1yM
MK/NKEGYCfFzd50G/tWBz4K9jjXruxL1PrmmKpcl1TkI6XezbEJ8o/4loRsoH4C3
03fzUbRgunSFQUJ1/QJwa3wSz6eaiGW7l/KMiw54uYBJ7x5SDYvIQyqSYNKcuX/G
txFcLBF1ooPVh8mlhXii5jXwOgr+N+ZYfWVL24HGzLOc/vh0GEMqPlb4CsYdFaGu
19uzrNqGpycEwh1UhYVNT0QQ+e2oEFmU3COdLY5FVLq8XJwU9J8TAX+M/7cAfiRB
aezqyJEOtNsoh2iEFGeO/DRjLn4gbjVUyDXJ9MuDKCpLX34qBz+lr330e4xLI8zi
9tCmyBGkCmjWBzKSUlpa8qPyj5nskASV3DucLAiKBdqRVWLZiwXHvNtBjGzcBiqH
fZm3uENS0FZaohuUoDX0rKHFj6oljy+9SDrlKnmA9fV+Pclh4V3Veks4BkfBOfDT
DJpWkW7y1k+U8ix4I4IAnmZwdSgx0OmlqY/BVCJ51o6H3mwdT0Cz8/WVsgoejdT9
lxJHOw3l1aw1vMTHtKXJcwLTvGC/5K8uHobWwzTenP00Rkgu2JcWIv0SWO0CAwEA
AQKCAgAzWqAyc5DZiAvaYJ9Hjh6YY7TNDAG0jEI4+gDBU1rcdAtiAcDM74oQYL9P
QWq8A5/mf+DEIURsAdH3RWda85sM9sdLRgX9blqs9FHUaGc9BdoWthcq/PgtMhlF
x/j/nJ3YPlc628bTvkvVmZ59UA21QlJTKxot7/idnCNDPVwqo4Q7PfRKKh56G11g
fySKeQ7u1ETZTigPpRLLlDLCk/YtCunPbNvgXz0UQ4fKV26i7o0j0WqNHsTF6quX
Q54nLGzUev7f53CqO5ZF2QIV0+nf4kNlCw1IoptmZhjAWgiix3/OLzIP4h9Bs4UR
AedorXLfZb7gBVAA60etIzNRPoD/CLrbpELQkKGFDdKAM+zCblr0h2ekTkUlNPfV
WlV292dWwFkL8U8fCN++Yc0zCwwx34eAfO0bjTvdjI4xwl3eLm80RKk6OKuyovT2
6pyQTNA/atfNxQfBKMalknE+PyTxRNilCtcWLnPsyXm+ftavNRQsTmbDsJaL9l4H
19UXvEx3oFM3vce090602la4Z3EgIJcNBHcIwYK07BhJZpqQ4XPX2DywICLS9X7z
UpgY9zzCMCxPqp5kiqzaOhZlO07xpMagNHWcRTr0IetT2Rrsdivi37Q24nU2z9Zb
5sFo+QYvWVrqgBnlzg8vccxjbR2HvREhpRIjnKzP+RklGEbsAQKCAQEA9cj7KHAh
fgKcvUMpD8YK9ihY3QZZoh3FFlb1q90NfBHYUCtC503z+PdH+nGRfy6Z7yvGTGhQ
FXr0dDF1XdT6NtnePyHZ6oDKF6oL3U9//PXBoIr66z/qc9SyigUX3SRvjvc48eFv
liX5E56E0ukbvkxKewCimCwHSWgM8V4KJdqa3QHGFOo3vSGJ1R83yL00YcWVf7ss
pNtcFdfts1ITv9VhnyByi//HoLO95QS08IC5PYm+Pn1fx9c75Yw4Lmjfsy1HRzyO
99JKYcihTFkFI1fLQVP2sgoaXMNMH/azZGFXQTZ1CsDVwWp/HUpT2KcIiwYhuGV5
0vjmT0lkENqebQKCAQEA8peyfL8ozwUrAC96Nsjc9VSs30TG+93sloOMjHfHgWYv
V1lNMK7Aa3VXqp0c/COToOWJiyi/XF0apz8brdMIOFPrzjcNWI+8Kqr7ZidE9i16
83CAZ8dDc7Gi2qTharTQiJAcCfS5loXyTC+GwNtu8yt4UXhKhg8i4ChgbxGBpe3T
FxCXhJxd3Ewfjjb6VUlz4hoGJqz4ivhttFJZISoX4GIqqbPe9SpEAbtFmc4lyil9
z0e3vxqI5yZfvojIsPWUyiSuQ0IVwVZMQHl7eMBr0/SgbVc8RGMWwJAQWU50YAZo
LCkxbzny/TZUyvl9e1LmBbTuGh2NlgyVzZvPX6gUgQKCAQEA5oOFkup/buhSSmsn
oqSR+UXj+f+Ppy0WgBo0tOhQUlGGN8IrMDZ7H8AD4M4MsGRreNXsWBLpMQwtIqCU
O9mYhkMVXs6Hy5jYcRNJp1l9ZyiyXbibFnHOmK4eeLXIKN6YRlR1Mt3EwuSAUzcz
yX9ZRsPUgsIYvHFmsCEHKoSRLel1ntugBFOazSYcWCa8MefJrf0adj5842zcU5w9
UhYjcaJVuWE8LTNJ7d1FtvoQHRQNJ7r9EyyQ3SNvCJ3Wvygazbgkhpo0WBcBLe51
4N4IpJodhfqSf25cRS3hQoUkwHtO01mYseojUBBqgXUJaENYDtNEYuXBOO25SxlA
4VG4jQKCAQAKYRst4y/ny5zPYTilZ2qsxHaxBsxMsm4Q8ofs6qMKkkisQBHhZ1is
QFUD47z9vLfwRmHgJloppYIibbzNbx4G6vBH3msfwuaWHMKs2DlHHyMHj2SvDAOC
y7LgD/XlDt9tOF06v9HA8vIu+EmXrsvMc6uuMKtfmP4xAQk/N0yIwOgrMHaLIfWS
G1+uQgPr6jyfC+X/eZ8YsxBeirdth9OFsi2JHT0I2EoYmN6degh74dKUL8lYz9XT
rfyitk9/4sH+9BrQnd84amzQxWHXBMSYSPskMntNob+zdXZ9m7G2+g8y9IA89gnD
c7OlC4+m2yEkVV1qmKEaLmeqaGQy/4oBAoIBAERhPM0rtIkO4pYsMyS22AX3ht+Z
7a2iGysdllvyjiLjah+AEqImyCk/mrH2ZJkrCwNARGdOgh/H8jj7XpxifLogvv7d
zIr4NaMYDA/GvwDq5a6dfI+h98I8eP5fR/2vaiO1oKz1KwZSSsjrv+lpucul7xZy
z3/kT9MBAyr/5pF2qS1824qCfdHfCsgMbQv0V+BgDn9iexM3MOLvpqAs4u98lh0R
U7CT8aMKEKv7BRUdJTjtgiY2eHG209IdA+OjvABE7aSGbI1Vb14Wo1zRne6P9U7p
tpM2ROh5t5nTsUAlF3L6f8vGqUJyHC5ETDoe0HEw35kxh9BhN20Y4+qOixE=
-----END RSA PRIVATE KEY-----
    """;

    // 全局變數儲存 apiKey，供多個測試使用
    private static String testApiKey;

    /**
     * 測試 1：建立會話
     * 
     * <p>驗證 createSSHSession 能正確建立會話並返回有效的 apiKey</p>
     */
    @Test
    void testCreateSSHSession() {
        log.info("========== 測試 1: 建立 SSH 會話 ==========");
        
        try {
            // 呼叫建立會話
            String apiKey = sshSessionManager.createSSHSession(
                "localhost", 2223, "tsai", TEST_PRIVATE_KEY
            );
            
            // 驗證返回值
            assertNotNull(apiKey, "apiKey 不應該為 null");
            assertTrue(apiKey.startsWith("ssh-"), "apiKey 應該以 'ssh-' 開頭");
            
            log.info("✅ 會話建立成功");
            log.info("📌 apiKey: {}", apiKey);
            log.info("✅ apiKey 格式驗證通過（以 'ssh-' 開頭）");
            
            // 存儲 apiKey 供後續測試使用
            testApiKey = apiKey;
            
        } catch (Exception e) {
            log.error("❌ 會話建立失敗: {}", e.getMessage(), e);
            fail("會話建立失敗: " + e.getMessage());
        }
    }

    /**
     * 測試 2：執行單個命令
     * 
     * <p>驗證 executeSSHCommand 能正確執行命令並返回結果</p>
     */
    @Test
    void testExecuteSingleCommand() {
        log.info("========== 測試 2: 執行單個命令 ==========");
        
        try {
            // 先建立會話
            if (testApiKey == null) {
                testApiKey = sshSessionManager.createSSHSession(
                    "localhost", 2223, "tsai", TEST_PRIVATE_KEY
                );
            }
            
            // 執行 whoami 命令
            String output = sshSessionManager.executeSSHCommand(testApiKey, "whoami");
            
            // 驗證輸出
            assertNotNull(output, "命令輸出不應該為 null");
            assertFalse(output.isEmpty(), "命令輸出不應該為空");
            assertTrue(output.contains("tsai"), "輸出應該包含用戶名 'tsai'");
            
            log.info("✅ 命令執行成功");
            log.info("📝 命令: whoami");
            log.info("📄 輸出: {}", output.trim());
            
        } catch (Exception e) {
            log.error("❌ 命令執行失敗: {}", e.getMessage(), e);
            fail("命令執行失敗: " + e.getMessage());
        }
    }

    /**
     * 測試 3：序列化執行多個命令（驗證隊列機制）
     * 
     * <p>驗證同一會話的多個命令能正確序列化執行</p>
     */
    @Test
    void testSequentialCommandExecution() {
        log.info("========== 測試 3: 序列化執行多個命令 ==========");
        
        try {
            // 先建立會話
            if (testApiKey == null) {
                testApiKey = sshSessionManager.createSSHSession(
                    "localhost", 2223, "tsai", TEST_PRIVATE_KEY
                );
            }
            
            // 執行第一個命令
            log.info("執行命令 1: pwd");
            String output1 = sshSessionManager.executeSSHCommand(testApiKey, "pwd");
            assertNotNull(output1);
            log.info("✅ 輸出: {}", output1.trim());
            
            // 執行第二個命令
            log.info("執行命令 2: whoami");
            String output2 = sshSessionManager.executeSSHCommand(testApiKey, "whoami");
            assertNotNull(output2);
            assertTrue(output2.contains("tsai"));
            log.info("✅ 輸出: {}", output2.trim());
            
            // 執行第三個命令
            log.info("執行命令 3: id");
            String output3 = sshSessionManager.executeSSHCommand(testApiKey, "id");
            assertNotNull(output3);
            log.info("✅ 輸出: {}", output3.trim());
            
            log.info("✅ 序列化執行驗證完成（三個命令依序執行）");
            
        } catch (Exception e) {
            log.error("❌ 序列化執行失敗: {}", e.getMessage(), e);
            fail("序列化執行失敗: " + e.getMessage());
        }
    }

    /**
     * 測試 4：驗證錯誤訊息（apiKey 不存在）
     * 
     * <p>驗證使用無效 apiKey 時返回清晰的錯誤訊息</p>
     */
    @Test
    void testInvalidApiKeyError() {
        log.info("========== 測試 4: 無效 apiKey 錯誤處理 ==========");
        
        try {
            // 使用不存在的 apiKey
            String invalidApiKey = "ssh-invalidkey123456";
            
            log.info("嘗試使用無效 apiKey: {}", invalidApiKey);
            sshSessionManager.executeSSHCommand(invalidApiKey, "whoami");
            
            fail("應該拋出 IllegalArgumentException");
            
        } catch (IllegalArgumentException e) {
            String errorMsg = e.getMessage();
            log.info("✅ 捕獲預期的異常");
            log.info("📝 錯誤訊息: {}", errorMsg);
            
            // 驗證錯誤訊息內容
            assertTrue(errorMsg.contains("會話不存在"), "錯誤訊息應該提及會話不存在");
            assertTrue(errorMsg.contains("createSSHSession"), "錯誤訊息應該建議使用 createSSHSession");
            
            log.info("✅ 錯誤訊息格式驗證通過（包含清晰的引導）");
            
        } catch (Exception e) {
            log.error("❌ 未預期的異常類型: {}", e.getClass().getSimpleName(), e);
            fail("應該拋出 IllegalArgumentException，但拋出了 " + e.getClass().getSimpleName());
        }
    }

    @Test
    void testQueueLimitExceeded() {
        log.info("========== 測試 5: 隊列限制驗證 ==========");
        
        try {
            // 先建立會話
            String apiKey = sshSessionManager.createSSHSession(
                "localhost", 2223, "tsai", TEST_PRIVATE_KEY
            );
            
            log.info("嘗試提交超過 10 個命令...");
            
            // 嘗試提交 11 個命令（第 11 個應該被拒絕）
            for (int i = 0; i < 11; i++) {
                try {
                    sshSessionManager.executeSSHCommand(apiKey, "echo test" + i);
                } catch (IllegalArgumentException e) {
                    if (e.getMessage().contains("隊列已滿")) {
                        log.info("✅ 在第 {} 個命令時被正確拒絕", (i + 1));
                        log.info("📝 錯誤訊息: {}", e.getMessage());
                        return; // 測試通過
                    }
                    throw e;
                }
            }
            
            log.warn("⚠️ 警告：隊列限制測試可能需要並發才能觸發");
            
        } catch (Exception e) {
            log.error("❌ 測試失敗: {}", e.getMessage(), e);
            fail("隊列限制測試失敗: " + e.getMessage());
        }
    }

    /**
     * 測試 6：驗證獨立的會話（apiKey 隔離）
     * 
     * <p>驗證不同的 apiKey 對應不同的會話</p>
     */
    @Test
    void testMultipleSessions() {
        log.info("========== 測試 6: 多個獨立會話 ==========");
        
        try {
            // 建立第一個會話
            String apiKey1 = sshSessionManager.createSSHSession(
                "localhost", 2223, "tsai", TEST_PRIVATE_KEY
            );
            log.info("✅ 會話 1 建立成功，apiKey: {}", apiKey1);
            
            // 建立第二個會話
            String apiKey2 = sshSessionManager.createSSHSession(
                "localhost", 2223, "tsai", TEST_PRIVATE_KEY
            );
            log.info("✅ 會話 2 建立成功，apiKey: {}", apiKey2);
            
            // 驗證兩個 apiKey 不同
            assertNotEquals(apiKey1, apiKey2, "不同的會話應該有不同的 apiKey");
            log.info("✅ apiKey 隔離驗證通過（兩個 apiKey 不同）");
            
            // 驗證可以分別使用兩個會話
            String output1 = sshSessionManager.executeSSHCommand(apiKey1, "whoami");
            String output2 = sshSessionManager.executeSSHCommand(apiKey2, "whoami");
            
            assertTrue(output1.contains("tsai"));
            assertTrue(output2.contains("tsai"));
            log.info("✅ 兩個獨立會話都能正常執行命令");
            
        } catch (Exception e) {
            log.error("❌ 多會話測試失敗: {}", e.getMessage(), e);
            fail("多會話測試失敗: " + e.getMessage());
        }
    }
}