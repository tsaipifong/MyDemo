package com.momo.ltsre.ssh.service;

/**
 * SSH 執行異常
 * 
 * <p>當 SSH 連接、認證或命令執行過程中發生錯誤時拋出此異常。</p>
 * 
 * <p>常見的異常情況包括：</p>
 * <ul>
 *   <li>SSH 連接超時或失敗</li>
 *   <li>SSH 金鑰認證失敗</li>
 *   <li>命令執行超時</li>
 *   <li>網路連接中斷</li>
 *   <li>目標主機不可達</li>
 * </ul>
 * 
 * @author SSH MCP Server Team
 * @version 1.0.0
 * @since 2025-10-31
 */
public class SshExecutionException extends RuntimeException {

    /** 序列化版本 ID */
    private static final long serialVersionUID = 1L;

    /**
     * 建構異常，僅包含錯誤訊息
     * 
     * @param message 錯誤訊息
     */
    public SshExecutionException(String message) {
        super(message);
    }

    /**
     * 建構異常，包含錯誤訊息和原因
     * 
     * @param message 錯誤訊息
     * @param cause 原始異常
     */
    public SshExecutionException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * 建構異常，僅包含原因
     * 
     * @param cause 原始異常
     */
    public SshExecutionException(Throwable cause) {
        super(cause);
    }

    /**
     * 建構異常，包含完整參數
     * 
     * @param message 錯誤訊息
     * @param cause 原始異常
     * @param enableSuppression 是否啟用異常抑制
     * @param writableStackTrace 是否可寫入堆疊追蹤
     */
    public SshExecutionException(String message, Throwable cause, 
                                boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}