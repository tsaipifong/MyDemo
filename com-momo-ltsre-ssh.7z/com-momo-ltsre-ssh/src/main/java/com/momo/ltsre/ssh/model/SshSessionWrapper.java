package com.momo.ltsre.ssh.model;

import org.apache.sshd.client.session.ClientSession;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

/**
 * SSH 會話包裝類
 * 封裝一個持久的 SSH ClientSession 及其命令隊列
 * 每個 apiKey 對應一個 SshSessionWrapper 實例
 * 
 * 隊列使用容量限制為 1 的 LinkedBlockingQueue，
 * 實現同一會話的命令序列化執行
 */
public class SshSessionWrapper {
    
    /**
     * 會話的唯一標識符（UUID 格式）
     */
    private final String apiKey;
    
    /**
     * 持久的 SSH 客戶端會話
     */
    private final ClientSession clientSession;
    
    /**
     * 該會話的命令請求隊列（容量限制為 1，實現序列化執行）
     */
    private final BlockingQueue<SshCommandRequest> commandQueue;
    
    /**
     * 上次使用時間戳（毫秒）
     * 用於超時清理檢測（15 分鐘未使用則清理）
     */
    private volatile long lastUsedTime;
    
    /**
     * 建構子
     * @param apiKey 會話的唯一標識符
     * @param clientSession 持久的 SSH 客戶端會話
     */
    public SshSessionWrapper(String apiKey, ClientSession clientSession) {
        this.apiKey = apiKey;
        this.clientSession = clientSession;
        // 創建容量為 1 的隊列 - 強制序列化執行
        this.commandQueue = new LinkedBlockingQueue<>(1);
        this.lastUsedTime = System.currentTimeMillis();
    }
    
    /**
     * 獲取會話的 API 密鑰
     * @return apiKey
     */
    public String getApiKey() {
        return apiKey;
    }
    
    /**
     * 獲取持久的 SSH 客戶端會話
     * @return ClientSession 實例
     */
    public ClientSession getClientSession() {
        return clientSession;
    }
    
    /**
     * 獲取命令隊列（BlockingQueue）
     * @return 命令隊列引用
     */
    public BlockingQueue<SshCommandRequest> getCommandQueue() {
        return commandQueue;
    }
    
    /**
     * 獲取上次使用時間
     * @return 時間戳（毫秒）
     */
    public long getLastUsedTime() {
        return lastUsedTime;
    }
    
    /**
     * 更新上次使用時間為當前時間
     * 在每次使用會話時調用
     */
    public void updateLastUsedTime() {
        this.lastUsedTime = System.currentTimeMillis();
    }
    
    /**
     * 檢查會話是否已超時
     * @param timeoutMillis 超時時間（毫秒）
     * @return 若上次使用時間超過 timeoutMillis 則返回 true
     */
    public boolean isExpired(long timeoutMillis) {
        long timeSinceLastUse = System.currentTimeMillis() - lastUsedTime;
        return timeSinceLastUse > timeoutMillis;
    }
}
