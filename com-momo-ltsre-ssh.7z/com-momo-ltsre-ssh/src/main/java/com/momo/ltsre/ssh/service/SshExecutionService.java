package com.momo.ltsre.ssh.service;

import com.momo.ltsre.ssh.model.SshConnectionRequest;
import org.apache.sshd.client.SshClient;
import org.apache.sshd.client.channel.ChannelExec;
import org.apache.sshd.client.session.ClientSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.StringReader;
import java.security.KeyPair;
import java.security.Security;
import java.time.Duration;
import java.util.concurrent.TimeUnit;


import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openssl.PEMKeyPair;
import org.bouncycastle.openssl.PEMParser;
import org.bouncycastle.openssl.jcajce.JcaPEMKeyConverter;

/**
 * SSH 命令執行服務
 * 
 * <p>使用 Apache MINA SSHD 客戶端向遠程主機發送命令並獲取執行結果。</p>
 * <p>完全無狀態設計，每次執行都建立新的 SSH 連線。</p>
 * <p>僅支援 SSH 金鑰認證，確保自動化執行的可靠性。</p>
 * 
 * <p>主要功能：</p>
 * <ul>
 *   <li>SSH 金鑰認證連接</li>
 *   <li>遠程命令執行</li>
 *   <li>標準輸出和錯誤輸出收集</li>
 *   <li>連接超時和命令超時控制</li>
 *   <li>自動資源清理</li>
 * </ul>
 * 
 * @author SSH MCP Server Team
 * @version 1.0.0
 * @since 2025-10-31
 */
@Service
public class SshExecutionService {

    /** 日誌記錄器 */
    private static final Logger logger = LoggerFactory.getLogger(SshExecutionService.class);

    /** 預設連接超時時間 */
    private static final Duration DEFAULT_CONNECT_TIMEOUT = Duration.ofSeconds(30);

    /** 預設命令執行超時時間 */
    private static final Duration DEFAULT_COMMAND_TIMEOUT = Duration.ofMinutes(5);

    /**
     * 無狀態建構子
     * 
     * <p>服務不維護任何持久連線，所有連線資訊由呼叫方提供</p>
     */
    public SshExecutionService() {
        logger.info("✅ SSH 執行服務已初始化（無狀態模式）");
    }

    /**
     * 執行 SSH 命令（使用預設超時時間）
     * 
     * @param connectionRequest SSH 連線請求參數
     * @param command 要執行的命令
     * @return SSH 命令執行結果
     * @throws SshExecutionException 當 SSH 執行失敗時
     */
    public SshExecutionResult executeCommand(SshConnectionRequest connectionRequest, String command) {
        return executeCommand(connectionRequest, command, DEFAULT_CONNECT_TIMEOUT, DEFAULT_COMMAND_TIMEOUT);
    }

    /**
     * 執行 SSH 命令（指定超時時間）
     * 
     * @param connectionRequest SSH 連線請求參數
     * @param command 要執行的命令
     * @param connectTimeout 連接超時時間
     * @param commandTimeout 命令執行超時時間
     * @return SSH 命令執行結果
     * @throws SshExecutionException 當 SSH 執行失敗時
     */
    public SshExecutionResult executeCommand(SshConnectionRequest connectionRequest, String command,
                                           Duration connectTimeout, Duration commandTimeout) {
        
        // 驗證連線請求參數
        connectionRequest.validate();
        
        logger.info("🔗 開始 SSH 連接: {}@{}:{}", 
                    connectionRequest.username(), connectionRequest.host(), connectionRequest.port());
        logger.debug("📝 執行命令: {}", command);

        SshClient sshClient = null;
        ClientSession session = null;
        ChannelExec channelExec = null;

        try {
            // 建立臨時 SSH 客戶端
            sshClient = SshClient.setUpDefaultClient();
            sshClient.start();
            
            // 建立 SSH 連接
            session = createSshSession(sshClient, connectionRequest, connectTimeout);
            
            // 創建執行通道
            channelExec = session.createExecChannel(command);
            
            // 準備輸出流
            ByteArrayOutputStream stdout = new ByteArrayOutputStream();
            ByteArrayOutputStream stderr = new ByteArrayOutputStream();
            channelExec.setOut(stdout);
            channelExec.setErr(stderr);
            
            // 開啟通道並執行命令
            channelExec.open();
            
            // 等待命令執行完成 (等待通道關閉)
            try {
                Thread.sleep(1000); // 給命令一些時間開始執行
                
                // 簡單的輪詢方式等待命令完成
                long startTime = System.currentTimeMillis();
                while (channelExec.isOpen() && (System.currentTimeMillis() - startTime) < commandTimeout.toMillis()) {
                    Thread.sleep(100);
                }
                
                if (channelExec.isOpen()) {
                    throw new SshExecutionException("命令執行超時: " + command);
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new SshExecutionException("命令執行被中斷: " + command, e);
            }
            
            // 獲取執行結果
            Integer exitCode = channelExec.getExitStatus();
            String standardOutput = stdout.toString("UTF-8").trim();
            String errorOutput = stderr.toString("UTF-8").trim();
            
            int finalExitCode = exitCode != null ? exitCode : -1;
            logger.info("✅ 命令執行完成，退出代碼: {}", finalExitCode);
            
            return new SshExecutionResult(
                command,
                finalExitCode,
                standardOutput,
                errorOutput,
                finalExitCode == 0 // 退出代碼為 0 表示成功
            );
            
        } catch (Exception e) {
            logger.error("❌ SSH 命令執行失敗: {}", e.getMessage(), e);
            throw new SshExecutionException("SSH 命令執行失敗: " + e.getMessage(), e);
            
        } finally {
            // 清理資源
            if (channelExec != null) {
                try {
                    channelExec.close();
                } catch (IOException e) {
                    logger.warn("⚠️ 關閉執行通道時發生錯誤: {}", e.getMessage());
                }
            }
            
            if (session != null) {
                try {
                    session.close();
                    logger.debug("🔒 SSH 會話已關閉");
                } catch (IOException e) {
                    logger.warn("⚠️ 關閉 SSH 會話時發生錯誤: {}", e.getMessage());
                }
            }
            
            if (sshClient != null) {
                try {
                    // 給非同步操作時間完成，避免 "Executor has been shut down" 錯誤
                    Thread.sleep(500);
                    sshClient.stop();
                    logger.debug("🔒 SSH 客戶端已關閉");
                } catch (Exception e) {
                    logger.warn("⚠️ 關閉 SSH 客戶端時發生錯誤: {}", e.getMessage());
                }
            }
        }
    }

    /**
     * 創建並認證 SSH 會話
     * 
     * @param sshClient SSH 客戶端實例
     * @param connectionRequest 連線請求參數
     * @param connectTimeout 連接超時時間
     * @return 已認證的 SSH 會話
     * @throws Exception 當連接或認證失敗時
     */
    private ClientSession createSshSession(SshClient sshClient, SshConnectionRequest connectionRequest,
                                         Duration connectTimeout) throws Exception {
        
        // 建立連接
        ClientSession session = sshClient.connect(
            connectionRequest.username(), 
            connectionRequest.host(), 
            connectionRequest.port()
        ).verify(connectTimeout.toMillis(), TimeUnit.MILLISECONDS).getSession();
        
        // 解析私鑰內容並進行認證
        KeyPair keyPair = parsePrivateKeyContent(connectionRequest.privateKey());
        
        // 使用私鑰進行認證 - 正確的 API 使用方式
        session.setKeyIdentityProvider(org.apache.sshd.common.keyprovider.KeyPairProvider.wrap(keyPair));
        boolean authSuccess = session.auth().verify(connectTimeout).isSuccess();
        
        if (!authSuccess) {
            throw new SshExecutionException("SSH 私鑰認證失敗");
        }
        
        logger.debug("✅ SSH 私鑰認證成功");
        return session;
    }

    /**
     * 解析 PEM 格式的私鑰內容
     * 
     * @param privateKeyContent PEM 格式的私鑰內容字串
     * @return 解析後的 KeyPair 物件
     * @throws Exception 當私鑰格式無效或解析失敗時
     */
    private KeyPair parsePrivateKeyContent(String privateKeyContent) throws Exception {
        if (privateKeyContent == null || privateKeyContent.trim().isEmpty()) {
            throw new SshExecutionException("私鑰內容不能為空");
        }
        
        try {
            // 確保 Bouncy Castle Provider 已註冊
            if (Security.getProvider(BouncyCastleProvider.PROVIDER_NAME) == null) {
                Security.addProvider(new BouncyCastleProvider());
            }
            
            // 處理 OpenSSH 格式的私鑰
            if (privateKeyContent.contains("BEGIN OPENSSH PRIVATE KEY")) {
                return parseOpenSSHPrivateKey(privateKeyContent);
            }
            
            // 處理標準 PEM 格式的私鑰
            try (PEMParser pemParser = new PEMParser(new StringReader(privateKeyContent))) {
                Object pemObject = pemParser.readObject();
                
                JcaPEMKeyConverter converter = new JcaPEMKeyConverter()
                    .setProvider(BouncyCastleProvider.PROVIDER_NAME);
                
                if (pemObject instanceof PEMKeyPair) {
                    return converter.getKeyPair((PEMKeyPair) pemObject);
                } else if (pemObject instanceof KeyPair) {
                    return (KeyPair) pemObject;
                } else {
                    throw new SshExecutionException("不支援的私鑰格式: " + pemObject.getClass().getSimpleName());
                }
            }
            
        } catch (Exception e) {
            logger.error("❌ 私鑰解析失敗: {}", e.getMessage(), e);
            throw new SshExecutionException("私鑰解析失敗: " + e.getMessage(), e);
        }
    }
    
    /**
     * 解析 OpenSSH 格式的私鑰
     * 
     * @param privateKeyContent OpenSSH 格式的私鑰內容
     * @return 解析後的 KeyPair 物件
     * @throws Exception 當解析失敗時
     */
    private KeyPair parseOpenSSHPrivateKey(String privateKeyContent) throws Exception {
        try {
            // 先嘗試使用 Bouncy Castle 解析
            // OpenSSH 格式較複雜，暫時簡化實作
            // 實際專案中可能需要更精細的處理
            throw new SshExecutionException("暫不支援 OpenSSH 私鑰格式，請提供標準 PEM 格式私鑰");
        } catch (Exception e) {
            logger.error("❌ OpenSSH 私鑰解析失敗: {}", e.getMessage(), e);
            throw new SshExecutionException("OpenSSH 私鑰解析失敗: " + e.getMessage(), e);
        }
    }
}