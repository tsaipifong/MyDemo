package com.momo.ltsre.ssh;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * SSH MCP Server 主應用程式類別
 * 
 * <p>基於 Spring AI MCP 框架構建的 SSH 命令執行服務，提供以下核心功能：</p>
 * <ul>
 *   <li>無狀態 SSH 連接 - 每次請求獨立執行</li>
 *   <li>遠程命令執行 - 在目標主機上執行任意命令</li>
 *   <li>私鑰認證支援 - 僅支援 SSH 金鑰認證</li>
 *   <li>MCP 協議支援 - 提供標準化的 AI Agent 介面</li>
 * </ul>
 * 
 * <p>技術架構：</p>
 * <ul>
 *   <li>Spring Boot 3.4.10 + Java 21</li>
 *   <li>Spring AI MCP Server WebMvc</li>
 *   <li>Apache MINA SSHD 2.12.0</li>
 *   <li>支援 HTTP/SSE 傳輸協議</li>
 * </ul>
 * 
 * @author SSH MCP Server Team
 * @version 1.0.0
 * @since 2025-10-31
 */
@SpringBootApplication
public class SshMcpServerApplication {

    /** 日誌記錄器 */
    private static final Logger logger = LoggerFactory.getLogger(SshMcpServerApplication.class);

    /**
     * 應用程式入口點
     * 
     * @param args 命令列參數
     */
    public static void main(String[] args) {
        logger.info("🚀 啟動 SSH MCP Server...");
        logger.info("📋 Java 版本: {}", System.getProperty("java.version"));
        logger.info("🏗️  Spring Boot 版本: {}", SpringApplication.class.getPackage().getImplementationVersion());
        
        try {
            // 啟動 Spring Boot 應用程式
            SpringApplication application = new SpringApplication(SshMcpServerApplication.class);
            application.run(args);
            
            logger.info("✅ SSH MCP Server 啟動成功!");
            logger.info("🌐 HTTP/SSE 端點: http://localhost:8080");
            logger.info("📡 MCP 事件端點: http://localhost:8080/ssh/mcp/events");
            logger.info("📖 健康檢查: http://localhost:8080/actuator/health");
            
        } catch (Exception e) {
            logger.error("❌ SSH MCP Server 啟動失敗: {}", e.getMessage(), e);
            System.exit(1);
        }
    }
}