package com.momo.ltsre.ssh.service;

import com.momo.ltsre.ssh.model.SshCommandRequest;
import com.momo.ltsre.ssh.model.SshSessionWrapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.sshd.client.SshClient;
import org.apache.sshd.client.channel.ChannelExec;
import org.apache.sshd.client.session.ClientSession;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openssl.PEMKeyPair;
import org.bouncycastle.openssl.PEMParser;
import org.bouncycastle.openssl.jcajce.JcaPEMKeyConverter;
import org.springframework.stereotype.Service;

import jakarta.annotation.PreDestroy;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;
import java.security.KeyPair;
import java.security.Security;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/**
 * SSH 會話管理器
 * 負責 SSH session 的生命週期管理、命令隊列處理、超時清理等
 * 
 * 核心功能：
 * 1. 創建 SSH 會話，返回 apiKey
 * 2. 通過 apiKey 執行命令（隊列序列化）
 * 3. 15 分鐘空閒超時自動清理
 */
@Slf4j
@Service
public class SshSessionManager {
    
    // ============ 配置常量 ============
    
    /** SSH 會話空閒超時時間（15 分鐘） */
    private static final long SESSION_IDLE_TIMEOUT_MS = 15 * 60 * 1000;
    
    /** 命令執行超時時間（10 分鐘） */
    private static final long COMMAND_EXECUTION_TIMEOUT_SEC = 10 * 60;
    
    /** SSH 通道等待超時時間（10 分鐘） */
    private static final long SSH_CHANNEL_TIMEOUT_MS = 10 * 60 * 1000;
    
    /** SSH 讀取超時時間（無新輸出超過 2 分鐘則超時） */
    private static final long SSH_READ_TIMEOUT_MS = 2 * 60 * 1000;
    
    /** 命令入隊超時時間（5 分鐘） */
    private static final long COMMAND_ENQUEUE_TIMEOUT_SEC = 5 * 60;
    
    /** 會話清理檢查間隔（1 分鐘） */
    private static final long CLEANUP_INTERVAL_MS = 60 * 1000;
    
    // ============ 成員變數 ============
    
    /**
     * 會話存儲：apiKey → SshSessionWrapper
     * 使用 ConcurrentHashMap 以支持多線程併發存取
     */
    private final Map<String, SshSessionWrapper> sessions = new ConcurrentHashMap<>();
    
    /**
     * 共享線程池：用於執行所有會話的命令隊列
     * 固定 10 個線程，處理來自所有 session 的命令
     */
    private final ExecutorService sharedExecutor;
    
    /**
     * SSH 客戶端單例
     */
    private final SshClient sshClient;
    
    /**
     * 建構子
     * 初始化共享執行器和定時清理任務
     */
    public SshSessionManager() {
        // 創建共享線程池（10 個固定線程）
        this.sharedExecutor = Executors.newFixedThreadPool(10, runnable -> {
            Thread thread = new Thread(runnable, "SshCommandWorker-" + UUID.randomUUID());
            thread.setDaemon(false);
            return thread;
        });
        
        // 初始化 SSH 客戶端
        this.sshClient = SshClient.setUpDefaultClient();
        this.sshClient.start();
        
        // 啟動定時清理任務
        startCleanupTask();
        
        log.info("SSH 會話管理器初始化完成，共享執行器設置為 10 個線程");
    }
    
    /**
     * 建立新的 SSH 會話
     * 
     * @param host 遠程主機地址
     * @param port SSH 連接埠（通常 22）
     * @param username SSH 使用者名稱
     * @param privateKeyPem PEM 格式的私鑰內容
     * @return 會話的 apiKey（格式：ssh-[12字符UUID]）
     * @throws Exception 連接失敗、私鑰解析失敗等異常
     */
    public String createSSHSession(String host, int port, String username, String privateKeyPem) 
            throws Exception {
        
        log.info("建立 SSH 會話：{}@{}:{}", username, host, port);
        
        try {
            // 1. 解析私鑰
            KeyPair keyPair = parsePrivateKey(privateKeyPem);
            
            // 2. 建立 SSH 連接
            ClientSession clientSession = sshClient.connect(username, host, port)
                .verify(30000, TimeUnit.MILLISECONDS)
                .getSession();
            
            // 3. 使用私鑰進行認證
            clientSession.setKeyIdentityProvider(
                org.apache.sshd.common.keyprovider.KeyPairProvider.wrap(keyPair)
            );
            clientSession.auth().verify();
            
            // 4. 生成 apiKey
            String apiKey = generateApiKey();
            
            // 5. 包裝並存儲會話
            SshSessionWrapper wrapper = new SshSessionWrapper(apiKey, clientSession);
            sessions.put(apiKey, wrapper);
            
            log.info("SSH 會話創建成功，apiKey: {}", apiKey);
            return apiKey;
            
        } catch (Exception e) {
            log.error("SSH 會話創建失敗：{}@{}:{}", username, host, port, e);
            throw e;
        }
    }
    
    /**
     * 通過 apiKey 執行單個 SSH 命令
     * 
     * 流程：
     * 1. 驗證 apiKey 對應的會話是否存在
     * 2. 嘗試將命令加入隊列（有 30 秒超時）
     * 3. 提交隊列處理任務到執行器
     * 4. 【同步阻塞】等待命令執行完成或超時
     * 5. 返回結果
     * 
     * @param apiKey 會話的 apiKey
     * @param command 要執行的 SSH 命令
     * @return 命令的執行輸出
     * @throws IllegalArgumentException 當 apiKey 不存在
     * @throws TimeoutException 當入隊或執行超過超時時間
     * @throws Exception 命令執行過程中的其他異常
     */
    public String executeSSHCommand(String apiKey, String command) 
            throws IllegalArgumentException, TimeoutException, Exception {
        
        // 驗證 apiKey
        SshSessionWrapper wrapper = sessions.get(apiKey);
        if (wrapper == null) {
            String errorMsg = String.format(
                "會話不存在（apiKey: %s）。請先調用 createSSHSession 方法使用 SSH 私鑰建立會話以獲取 apiKey。",
                apiKey
            );
            log.warn(errorMsg);
            throw new IllegalArgumentException(errorMsg);
        }
        
        // 更新上次使用時間
        wrapper.updateLastUsedTime();
        
        // 建立命令請求
        SshCommandRequest request = new SshCommandRequest(command);
        
        // 嘗試將命令加入隊列（隊列大小限制為 1）
        try {
            boolean enqueued = wrapper.getCommandQueue().offer(
                request, 
                COMMAND_ENQUEUE_TIMEOUT_SEC, 
                TimeUnit.SECONDS
            );
            
            if (!enqueued) {
                String errorMsg = String.format(
                    "命令入隊超時（超過 %d 秒）- 該會話的隊列仍在等待執行",
                    COMMAND_ENQUEUE_TIMEOUT_SEC
                );
                log.warn("apiKey: {} - {}", apiKey, errorMsg);
                throw new TimeoutException(errorMsg);
            }
            
            log.debug("命令已加入隊列，apiKey: {}", apiKey);
            
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new RuntimeException("命令入隊被中斷", e);
        }
        
        // 提交隊列處理任務
        submitQueueProcessing(apiKey, wrapper);
        
        try {
            // 【同步等待】直到命令執行完成或超時
            String result = request.getResult().get(COMMAND_EXECUTION_TIMEOUT_SEC, TimeUnit.SECONDS);
            log.debug("命令執行成功，apiKey: {}", apiKey);
            return result;
            
        } catch (TimeoutException e) {
            String errorMsg = String.format(
                "命令執行超時（超過 %d 秒）：%s",
                COMMAND_EXECUTION_TIMEOUT_SEC,
                command
            );
            log.error("apiKey: {} - {}", apiKey, errorMsg);
            throw new TimeoutException(errorMsg);
        }
    }
    
    /**
     * 提交隊列處理任務
     * 檢查是否已有執行任務，若沒有則提交新任務
     * 
     * @param apiKey 會話的 apiKey
     * @param wrapper 會話包裝物件
     */
    private void submitQueueProcessing(String apiKey, SshSessionWrapper wrapper) {
        // 將隊列處理任務提交到共享執行器
        sharedExecutor.submit(() -> processCommandQueue(apiKey, wrapper));
    }
    
    /**
     * 處理單個會話的命令隊列
     * 從隊列中取出命令並執行（隊列容量為 1，一次只有一個命令）
     * 
     * @param apiKey 會話的 apiKey
     * @param wrapper 會話包裝物件
     */
    private void processCommandQueue(String apiKey, SshSessionWrapper wrapper) {
        // 由於隊列容量限制為 1，poll() 最多取一個命令
        SshCommandRequest request = wrapper.getCommandQueue().poll();
        if (request == null) {
            return;
        }
        
        try {
            log.debug("開始執行命令，apiKey: {}，命令: {}", apiKey, request.getCommand());
            
            // 執行 SSH 命令
            String output = executeSshCommandInternal(wrapper.getClientSession(), request.getCommand());
            
            // 設置結果
            request.getResult().complete(output);
            log.debug("命令執行完成，apiKey: {}", apiKey);
            
        } catch (Exception e) {
            log.error("命令執行失敗，apiKey: {}", apiKey, e);
            request.getResult().completeExceptionally(e);
        }
    }
    
    /**
     * 內部 SSH 命令執行方法
     * 使用已建立的 ClientSession 執行命令並獲取輸出
     * 採用 read timeout 機制：以行為單位追蹤，如果超過 2 分鐘沒有新的一行輸出，則判定為超時
     * 每行輸出都會打印 log，便於追蹤執行進度
     * 
     * @param clientSession SSH 客戶端會話
     * @param command 要執行的命令
     * @return 命令的完整標準輸出
     * @throws Exception 命令執行失敗或超時
     */
    private String executeSshCommandInternal(ClientSession clientSession, String command) throws Exception {
        // 創建帶有行級別追蹤的 OutputStream
        class LineTrackedByteArrayOutputStream extends ByteArrayOutputStream {
            private volatile long lastLineTime = System.currentTimeMillis();
            private int lineNumber = 0;
            private StringBuilder currentLine = new StringBuilder();
            
            @Override
            public synchronized void write(int b) {
                super.write(b);
                currentLine.append((char) b);
                
                // 檢測到換行符
                if (b == '\n') {
                    lineNumber++;
                    String line = currentLine.toString().trim();
                    lastLineTime = System.currentTimeMillis();
                    
                    // 打印每一行輸出到 log
                    if (!line.isEmpty()) {
                        log.debug("[SSH 輸出-第{}行] {}", lineNumber, line);
                    }
                    
                    currentLine = new StringBuilder();
                }
            }
            
            @Override
            public synchronized void write(byte[] b, int off, int len) {
                super.write(b, off, len);
                for (int i = off; i < off + len; i++) {
                    write(b[i]);
                }
            }
            
            public long getLastLineTime() {
                return lastLineTime;
            }
            
            public int getLineNumber() {
                return lineNumber;
            }
        }
        
        LineTrackedByteArrayOutputStream output = new LineTrackedByteArrayOutputStream();
        ChannelExec channelExec = null;
        
        try {
            // 建立執行通道
            channelExec = clientSession.createExecChannel(command);
            channelExec.setOut(output);
            channelExec.open();
            
            log.debug("開始執行 SSH 命令: {}", command);
            
            // 等待命令執行完成，採用行級別的 read timeout 機制
            long startTime = System.currentTimeMillis();
            while (channelExec.isOpen()) {
                long currentTime = System.currentTimeMillis();
                long totalElapsed = currentTime - startTime;
                long lastLineElapsed = currentTime - output.getLastLineTime();
                
                // 檢查總超時（10 分鐘）
                if (totalElapsed > SSH_CHANNEL_TIMEOUT_MS) {
                    log.error("SSH 命令總執行時間超時（總耗時 {} 秒，已收到 {} 行輸出）",
                        totalElapsed / 1000, output.getLineNumber());
                    throw new RuntimeException(String.format(
                        "命令執行超時（總耗時超過 %d 秒，已收到 %d 行輸出）",
                        SSH_CHANNEL_TIMEOUT_MS / 1000,
                        output.getLineNumber()
                    ));
                }
                
                // 檢查讀取超時（2 分鐘無新輸出行）
                if (lastLineElapsed > SSH_READ_TIMEOUT_MS) {
                    log.error("SSH 命令讀取超時（無新輸出超過 {} 秒，已收到 {} 行輸出）",
                        lastLineElapsed / 1000, output.getLineNumber());
                    throw new RuntimeException(String.format(
                        "命令執行超時（無新輸出超過 %d 秒，已收到 %d 行輸出）",
                        SSH_READ_TIMEOUT_MS / 1000,
                        output.getLineNumber()
                    ));
                }
                
                Thread.sleep(100);
            }
            
            String result = output.toString(StandardCharsets.UTF_8);
            log.debug("SSH 命令執行完成，共收到 {} 行輸出", output.getLineNumber());
            return result;
            
        } finally {
            if (channelExec != null) {
                try {
                    channelExec.close();
                } catch (IOException e) {
                    log.warn("關閉通道失敗", e);
                }
            }
        }
    }
    
    /**
     * 解析 PEM 格式的私鑰
     * 
     * @param privateKeyPem PEM 格式的私鑰內容
     * @return KeyPair 物件
     * @throws Exception 解析失敗
     */
    private KeyPair parsePrivateKey(String privateKeyPem) throws Exception {
        // 確保 Bouncy Castle Provider 已註冊
        if (Security.getProvider(BouncyCastleProvider.PROVIDER_NAME) == null) {
            Security.addProvider(new BouncyCastleProvider());
        }
        
        try (PEMParser pemParser = new PEMParser(new StringReader(privateKeyPem))) {
            Object pemObject = pemParser.readObject();
            
            JcaPEMKeyConverter converter = new JcaPEMKeyConverter()
                .setProvider(BouncyCastleProvider.PROVIDER_NAME);
            
            if (pemObject instanceof PEMKeyPair) {
                return converter.getKeyPair((PEMKeyPair) pemObject);
            } else if (pemObject instanceof KeyPair) {
                return (KeyPair) pemObject;
            } else {
                throw new RuntimeException("不支援的私鑰格式: " + pemObject.getClass().getSimpleName());
            }
        } catch (Exception e) {
            log.error("私鑰解析失敗", e);
            throw new RuntimeException("私鑰解析失敗: " + e.getMessage(), e);
        }
    }
    
    /**
     * 生成 apiKey
     * 格式：ssh-[UUID 前 12 字符]
     * 
     * @return apiKey
     */
    private String generateApiKey() {
        String uuid = UUID.randomUUID().toString();
        String shortUuid = uuid.substring(0, 12);
        return "ssh-" + shortUuid;
    }
    
    /**
     * 啟動定時清理任務
     * 每 1 分鐘檢查一次，清理超過 15 分鐘未使用的會話
     */
    private void startCleanupTask() {
        Thread cleanupThread = new Thread(() -> {
            while (true) {
                try {
                    Thread.sleep(CLEANUP_INTERVAL_MS);
                    cleanupExpiredSessions();
                } catch (InterruptedException e) {
                    log.warn("清理線程被中斷");
                    Thread.currentThread().interrupt();
                    break;
                }
            }
        }, "SshSessionCleanup");
        
        cleanupThread.setDaemon(true);
        cleanupThread.start();
    }
    
    /**
     * 清理超時的會話
     * 移除所有超過 15 分鐘未使用的會話
     */
    private void cleanupExpiredSessions() {
        sessions.forEach((apiKey, wrapper) -> {
            if (wrapper.isExpired(SESSION_IDLE_TIMEOUT_MS)) {
                try {
                    wrapper.getClientSession().close();
                    sessions.remove(apiKey);
                    log.info("會話已清理（超時），apiKey: {}", apiKey);
                } catch (Exception e) {
                    log.error("會話清理失敗，apiKey: {}", apiKey, e);
                }
            }
        });
    }
    
    /**
     * 關閉管理器
     * 應在應用程式關閉時調用
     */
    @PreDestroy
    public void shutdown() {
        log.info("正在關閉 SSH 會話管理器...");
        
        // 關閉所有會話
        sessions.forEach((apiKey, wrapper) -> {
            try {
                wrapper.getClientSession().close();
            } catch (Exception e) {
                log.error("關閉會話失敗，apiKey: {}", apiKey, e);
            }
        });
        sessions.clear();
        
        // 關閉執行器
        sharedExecutor.shutdown();
        try {
            if (!sharedExecutor.awaitTermination(10, TimeUnit.SECONDS)) {
                sharedExecutor.shutdownNow();
            }
        } catch (InterruptedException e) {
            sharedExecutor.shutdownNow();
            Thread.currentThread().interrupt();
        }
        
        // 關閉 SSH 客戶端
        try {
            sshClient.stop();
        } catch (Exception e) {
            log.error("SSH 客戶端關閉失敗", e);
        }
        
        log.info("SSH 會話管理器已關閉");
    }
}
