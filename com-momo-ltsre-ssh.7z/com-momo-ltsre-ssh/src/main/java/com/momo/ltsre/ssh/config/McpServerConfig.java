package com.momo.ltsre.ssh.config;

import com.momo.ltsre.ssh.service.McpSshExecutionService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.tool.method.MethodToolCallbackProvider;
import org.springframework.ai.tool.ToolCallbackProvider;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * MCP Server 配置類別
 * 
 * <p>使用 Spring AI 的 ToolCallbackProvider 來暴露 SSH 工具給 MCP 客戶端</p>
 * <p>根據 Spring AI 官方文檔的建議模式實現</p>
 * 
 * @author SSH MCP Server Team
 * @version 1.0.0
 * @since 2025-10-31
 */
@Configuration
@Slf4j
public class McpServerConfig {

    /**
     * 建立 ToolCallbackProvider Bean 來暴露 SSH 工具
     * 
     * <p>此方法註冊 McpSshExecutionService 中所有標註 @Tool 的方法</p>
     * <p>使得這些方法可以被 MCP 客戶端發現和調用</p>
     * 
     * @param mcpSshExecutionService SSH 執行服務實例
     * @return ToolCallbackProvider 實例
     */
    @Bean
    public ToolCallbackProvider sshTools(McpSshExecutionService mcpSshExecutionService) {
        log.info("正在註冊 SSH MCP 工具...");
        return MethodToolCallbackProvider.builder()
                .toolObjects(mcpSshExecutionService)
                .build();
    }
}
