package com.momo.ltsre.ssh.service;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

/**
 * MCP SSH 執行服務類別
 * 
 * <p>提供 Model Context Protocol 介面，透過會話持久化的方式管理 SSH 連接</p>
 * <p>這個類別作為 MCP Server 的工具提供者，提供兩個核心工具：
 * 1. createSSHSession - 建立新的 SSH 會話並返回 apiKey
 * 2. executeSSHCommand - 通過 apiKey 執行命令（會話內命令序列化執行）
 * </p>
 * 
 * <p>設計特點：</p>
 * <ul>
 *   <li>會話持久化 - 避免重複身份驗證開銷</li>
 *   <li>命令隊列 - 確保同一會話內的命令序列化執行（SSH 協議特性）</li>
 *   <li>15分鐘自動超時清理 - 防止資源泄漏</li>
 *   <li>同步等待 - 保證 MCP Request-Response 一致性</li>
 *   <li>清晰的錯誤訊息 - 引導 AI 正確使用工具流程</li>
 * </ul>
 * 
 * @author SSH MCP Server Team
 * @version 2.0.0
 * @since 2025-11-04
 */
@Service
@Slf4j
public class McpSshExecutionService {

    /** SSH 會話管理器實例 */
    @Autowired
    private SshSessionManager sshSessionManager;

    // ================================
    // SSH 會話管理 MCP Tools
    // ================================

    /**
     * 建立 SSH 會話
     * 
     * <p>使用 SSH 私鑰連接到遠程主機，並建立持久會話。返回 apiKey 供後續命令使用。</p>
     * 
     * <p>工作流程：</p>
     * <ol>
     *   <li>驗證連接參數</li>
     *   <li>與遠程主機建立 SSH 連接</li>
     *   <li>使用私鑰進行身份驗證</li>
     *   <li>生成並返回 apiKey（格式：ssh-[12字符UUID]）</li>
     *   <li>會話在伺服器端維持 15 分鐘（無請求時自動清理）</li>
     * </ol>
     * 
     * <p><strong>重要提示：</strong>
     * 此工具必須首先被調用，以獲得 apiKey。後續的 executeSSHCommand 工具需要使用此 apiKey。
     * </p>
     * 
     * @param host 遠程主機地址（IP 或域名）
     * @param port SSH 連接端口，預設 22
     * @param username SSH 用戶名（如：root、ubuntu、admin）
     * @param privateKey SSH 私鑰內容（PEM 格式，必須包含 -----BEGIN ... PRIVATE KEY----- 標籤）
     * @return 包含 apiKey 的 JSON 字串
     */
    @Tool(description = "【必須首先調用】建立 SSH 會話並獲得 apiKey。" +
            "此工具用於建立到遠程主機的持久 SSH 會話。成功後返回 apiKey，用於後續的 executeSSHCommand 工具調用。" +
            "如果你還沒有 apiKey，或需要連接到新的主機，請先使用此工具。" +
            "會話將在 15 分鐘無活動後自動清理。")
    public String createSSHSession(
            @ToolParam(description = "遠程主機地址，例如：192.168.1.100 或 server.example.com")
            String host,
            
            @ToolParam(description = "SSH 連接端口，通常為 22（標準 SSH 端口）")
            int port,
            
            @ToolParam(description = "SSH 用戶名，例如：root、ubuntu、admin。根據遠程系統配置而異")
            String username,
            
            @ToolParam(description = "SSH 私鑰內容（PEM 格式）。" +
                    "必須包含完整的 -----BEGIN RSA PRIVATE KEY----- 或 -----BEGIN PRIVATE KEY----- 標籤。" +
                    "從本地 ~/.ssh/id_rsa 檔案複製整個內容（包括頭尾標籤）。")
            String privateKey) {
        
        try {
            log.info("MCP: 建立 SSH 會話 - 主機: {}:{}, 用戶: {}", host, port, username);
            
            // 委派給 SshSessionManager 建立會話
            String apiKey = sshSessionManager.createSSHSession(host, port, username, privateKey);
            
            // 構建回應
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("apiKey", apiKey);
            response.put("host", host);
            response.put("port", port);
            response.put("username", username);
            response.put("message", String.format(
                "SSH 會話建立成功。apiKey: %s。" +
                "請使用此 apiKey 調用 executeSSHCommand 工具執行命令。" +
                "會話將在 15 分鐘無活動後自動清理。",
                apiKey
            ));
            
            log.info("MCP: SSH 會話建立成功，apiKey: {}", apiKey);
            return convertToJsonString(response);
            
        } catch (Exception e) {
            log.error("MCP: 建立 SSH 會話失敗", e);
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("error", "建立 SSH 會話失敗: " + e.getMessage());
            errorResponse.put("message", "連接失敗。請檢查主機地址、端口、用戶名和私鑰是否正確。");
            return convertToJsonString(errorResponse);
        }
    }

    /**
     * 執行 SSH 命令
     * 
     * <p>通過已建立的會話（使用 apiKey）執行單個 SSH 命令。</p>
     * 
     * <p>重要特性：</p>
     * <ul>
     *   <li>命令序列化執行 - 同一會話的多個命令會依序執行，確保正確性</li>
     *   <li>隊列限制 - 最多 10 個待執行命令，超過會被拒絕</li>
     *   <li>執行超時 - 單個命令最長執行 120 秒，超時會返回錯誤</li>
     *   <li>同步等待 - 工具會等待命令完成並返回結果</li>
     * </ul>
     * 
     * <p><strong>使用前提：</strong>
     * 必須先調用 createSSHSession 工具獲得 apiKey。
     * </p>
     * 
     * <p><strong>如果收到 "會話不存在" 錯誤：</strong>
     * 這表示 apiKey 無效或會話已過期（15 分鐘無活動後清理）。
     * 請重新調用 createSSHSession 工具建立新會話。
     * </p>
     * 
     * @param apiKey 會話的 apiKey（來自 createSSHSession 的返回值）
     * @param command 要執行的 Shell 命令
     * @return 包含命令執行結果的 JSON 字串
     */
    @Tool(description = "執行 SSH 命令（需要有效的 apiKey）。" +
            "此工具用於通過已建立的會話執行遠程命令。必須先調用 createSSHSession 獲得 apiKey。" +
            "同一會話的命令會序列化執行，確保 SSH 協議的正確性。" +
            "如果收到 'apiKey 不存在' 的錯誤，說明需要重新調用 createSSHSession 建立新會話。")
    public String executeSSHCommand(
            @ToolParam(description = "會話的 apiKey，由 createSSHSession 工具返回。格式為 ssh-[12字符]，例如：ssh-a1b2c3d4e5f6")
            String apiKey,
            
            @ToolParam(description = "要執行的 Shell 命令，例如：whoami、ls -la、ps aux 等。支援複雜的管道命令。")
            String command) {
        
        try {
            log.info("MCP: 執行 SSH 命令，apiKey: {}，命令: {}", apiKey, command);
            
            // 委派給 SshSessionManager 執行命令
            String output = sshSessionManager.executeSSHCommand(apiKey, command);
            
            // 構建回應
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("apiKey", apiKey);
            response.put("command", command);
            response.put("output", output);
            response.put("message", "命令執行成功");
            
            log.info("MCP: 命令執行成功，apiKey: {}", apiKey);
            return convertToJsonString(response);
            
        } catch (IllegalArgumentException e) {
            // apiKey 不存在或隊列已滿的情況
            log.warn("MCP: API Key 錯誤", e);
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("apiKey", apiKey);
            errorResponse.put("command", command);
            errorResponse.put("error", e.getMessage());
            errorResponse.put("suggestedAction", "請先調用 createSSHSession 工具建立新會話並獲得 apiKey");
            return convertToJsonString(errorResponse);
            
        } catch (java.util.concurrent.TimeoutException e) {
            // 命令執行超時
            log.warn("MCP: 命令執行超時", e);
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("apiKey", apiKey);
            errorResponse.put("command", command);
            errorResponse.put("error", "命令執行超時（超過 120 秒）");
            return convertToJsonString(errorResponse);
            
        } catch (Exception e) {
            log.error("MCP: 執行 SSH 命令失敗", e);
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("apiKey", apiKey);
            errorResponse.put("command", command);
            errorResponse.put("error", "命令執行失敗: " + e.getMessage());
            return convertToJsonString(errorResponse);
        }
    }

    // ================================
    // 輔助方法 (Helper Methods)
    // ================================

    /**
     * 將物件轉換為 JSON 字串
     * 
     * @param object 要轉換的物件
     * @return JSON 字串
     */
    private String convertToJsonString(Object object) {
        try {
            // 建立 ObjectMapper 實例以正確處理 SSH 執行結果物件
            ObjectMapper mapper = new ObjectMapper();
            mapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
            mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
            mapper.setVisibility(PropertyAccessor.FIELD, JsonAutoDetect.Visibility.ANY);
            mapper.setVisibility(PropertyAccessor.GETTER, JsonAutoDetect.Visibility.ANY);
            mapper.setVisibility(PropertyAccessor.SETTER, JsonAutoDetect.Visibility.NONE);

            return mapper.writeValueAsString(object);
        } catch (Exception e) {
            log.error("JSON 序列化失敗: {}", e.getMessage(), e);
            // 後備機制：若 Jackson 序列化失敗，返回 null 字串
            return "null";
        }
    }
}
