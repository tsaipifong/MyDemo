package com.momo.ltsre.ssh.model;

import java.util.concurrent.CompletableFuture;

/**
 * SSH 命令請求模型
 * 表示一個等待執行的 SSH 命令及其關聯的異步結果
 */
public class SshCommandRequest {
    
    /**
     * 要執行的 SSH 命令
     */
    private final String command;
    
    /**
     * 命令執行結果的異步容器
     * 背景線程執行命令後調用 complete() 或 completeExceptionally()
     * 前景線程通過 get() 同步等待結果
     */
    private final CompletableFuture<String> result;
    
    /**
     * 命令提交時間戳（毫秒）
     * 用於追蹤超時
     */
    private final long submittedTime;
    
    /**
     * 建構子
     * @param command 要執行的 SSH 命令
     */
    public SshCommandRequest(String command) {
        this.command = command;
        this.result = new CompletableFuture<>();
        this.submittedTime = System.currentTimeMillis();
    }
    
    /**
     * 獲取要執行的命令
     * @return 命令字符串
     */
    public String getCommand() {
        return command;
    }
    
    /**
     * 獲取結果的異步容器
     * @return CompletableFuture<String>
     */
    public CompletableFuture<String> getResult() {
        return result;
    }
    
    /**
     * 獲取命令提交時間
     * @return 時間戳（毫秒）
     */
    public long getSubmittedTime() {
        return submittedTime;
    }
    
    /**
     * 檢查命令是否已超時
     * @param timeoutMillis 超時時間（毫秒）
     * @return 若提交時間距現在超過 timeoutMillis 則返回 true
     */
    public boolean isTimedOut(long timeoutMillis) {
        long elapsedTime = System.currentTimeMillis() - submittedTime;
        return elapsedTime > timeoutMillis;
    }
}
