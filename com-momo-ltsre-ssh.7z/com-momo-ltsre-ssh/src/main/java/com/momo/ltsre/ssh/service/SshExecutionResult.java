package com.momo.ltsre.ssh.service;

/**
 * SSH 命令執行結果
 * 
 * <p>封裝 SSH 遠程命令執行的完整結果，包含標準輸出、錯誤輸出、退出代碼等資訊。</p>
 * 
 * @author SSH MCP Server Team
 * @version 1.0.0
 * @since 2025-10-31
 * 
 * @param command 執行的命令
 * @param exitCode 命令退出代碼 (0 表示成功)
 * @param stdout 標準輸出內容
 * @param stderr 錯誤輸出內容  
 * @param success 是否執行成功 (exitCode == 0)
 */
public record SshExecutionResult(
    /** 執行的 SSH 命令 */
    String command,
    
    /** 命令退出代碼 (0=成功, 非0=失敗) */
    int exitCode,
    
    /** 標準輸出內容 */
    String stdout,
    
    /** 錯誤輸出內容 */
    String stderr,
    
    /** 是否執行成功 */
    boolean success
) {
    
    /**
     * 獲取完整的輸出內容 (標準輸出 + 錯誤輸出)
     * 
     * @return 完整輸出內容
     */
    public String getFullOutput() {
        StringBuilder output = new StringBuilder();
        
        if (stdout != null && !stdout.trim().isEmpty()) {
            output.append("STDOUT:\n").append(stdout);
        }
        
        if (stderr != null && !stderr.trim().isEmpty()) {
            if (output.length() > 0) {
                output.append("\n\n");
            }
            output.append("STDERR:\n").append(stderr);
        }
        
        return output.toString();
    }
    
    /**
     * 獲取主要輸出 (優先使用標準輸出，如果為空則使用錯誤輸出)
     * 
     * @return 主要輸出內容
     */
    public String getPrimaryOutput() {
        if (stdout != null && !stdout.trim().isEmpty()) {
            return stdout;
        }
        return stderr != null ? stderr : "";
    }
    
    /**
     * 檢查是否有錯誤輸出
     * 
     * @return true 如果有錯誤輸出
     */
    public boolean hasErrors() {
        return stderr != null && !stderr.trim().isEmpty();
    }
    
    /**
     * 檢查是否有任何輸出
     * 
     * @return true 如果有標準輸出或錯誤輸出
     */
    public boolean hasOutput() {
        return (stdout != null && !stdout.trim().isEmpty()) || 
               (stderr != null && !stderr.trim().isEmpty());
    }
    
    /**
     * 轉換為可讀的字串格式
     * 
     * @return 格式化的結果字串
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("SshExecutionResult{");
        sb.append("command='").append(command).append("'");
        sb.append(", exitCode=").append(exitCode);
        sb.append(", success=").append(success);
        
        if (hasOutput()) {
            sb.append(", output=").append(getPrimaryOutput().length()).append(" chars");
        }
        
        sb.append('}');
        return sb.toString();
    }
}