package com.momo.ltsre.ssh.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;

/**
 * SSH 連接請求資料模型
 * 
 * <p>封裝建立 SSH 連接所需的所有參數，僅支援私鑰認證方式。</p>
 * <p>私鑰內容由客戶端隨請求傳送，支援 PEM 格式或 Base64 編碼。</p>
 * 
 * @author SSH MCP Server Team
 * @version 1.0.0
 * @since 2025-10-31
 */
public record SshConnectionRequest(
    
    /** 目標主機名稱或 IP 位址 */
    @NotBlank(message = "主機名稱不能為空")
    @JsonProperty("host")
    String host,
    
    /** SSH 連接埠 (預設 22) */
    @Min(value = 1, message = "連接埠必須大於 0")
    @Max(value = 65535, message = "連接埠必須小於 65536") 
    @JsonProperty("port")
    int port,
    
    /** SSH 使用者名稱 */
    @NotBlank(message = "使用者名稱不能為空")
    @JsonProperty("username") 
    String username,
    
    /** 私鑰內容 (PEM 格式或 Base64 編碼) */
    @NotBlank(message = "私鑰內容不能為空")
    @JsonProperty("privateKey") 
    String privateKey
) {
    
    /**
     * 建構子，設定預設埠為 22
     */
    @JsonCreator
    public SshConnectionRequest(
        @JsonProperty("host") String host,
        @JsonProperty("port") Integer port,
        @JsonProperty("username") String username,
        @JsonProperty("privateKey") String privateKey
    ) {
        this(
            host,
            port != null ? port : 22, // 預設埠為 22
            username,
            privateKey
        );
    }
    
    /**
     * 驗證連接請求的有效性
     * 
     * @throws IllegalArgumentException 當必要參數缺失時
     */
    public void validate() {
        if (privateKey == null || privateKey.trim().isEmpty()) {
            throw new IllegalArgumentException("私鑰內容不能為空");
        }
    }
    

}