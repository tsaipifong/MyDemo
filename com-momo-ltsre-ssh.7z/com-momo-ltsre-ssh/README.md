# SSH MCP Server

基於 Spring AI MCP 的 SSH 連接管理服務器，為 AI 助手（如 GitHub Copilot）提供遠端 SSH 命令執行能力。

## 📋 專案簡介

SSH MCP Server 是一個遵循 [Model Context Protocol (MCP)](https://spec.modelcontextprotocol.io/) 規範的服務器，它允許 AI 助手通過 SSH 協議連接並管理遠端伺服器。透過持久化會話管理，AI 可以在遠端主機上執行命令、查詢系統狀態、管理服務等操作。

### 主要特點

- ✅ **持久化會話管理** - 避免重複身份驗證，提高執行效率
- ✅ **私鑰認證** - 支援 RSA/DSA/ECDSA 等多種私鑰格式
- ✅ **命令序列化執行** - 確保同一會話內的命令按順序執行
- ✅ **自動超時清理** - 15 分鐘無活動後自動釋放資源
- ✅ **Docker 容器化部署** - 開箱即用的容器化方案
- ✅ **完整的錯誤處理** - 清晰的錯誤訊息引導正確使用

## 🚀 快速開始

### 前置需求

- Java 21 或更高版本
- Maven 3.9 或更高版本
- Docker（用於容器化部署）

### 本地運行

```bash
# 克隆專案
git clone <repository-url>
cd com-momo-ltsre-ssh

# 編譯專案
mvn clean package

# 運行應用
java -jar target/com-momo-ltsre-ssh-1.0.0.jar
```

應用程式將在 `http://localhost:8080` 啟動。

### Docker 部署

```powershell
# 建置 Docker 映像
docker build -t ssh-mcp-server:1.0.0 .

# 運行容器（映射到本機端口 10002）
docker run -d -p 10002:8080 --name ssh-mcp-server ssh-mcp-server:1.0.0

# 查看容器狀態
docker ps | Select-String "ssh-mcp-server"

# 查看日誌
docker logs ssh-mcp-server
```

## 🔧 使用方式

### 1. 建立 SSH 會話

首先需要建立一個 SSH 會話以獲得 `apiKey`：

```json
{
  "tool": "createSSHSession",
  "parameters": {
    "host": "192.168.56.101",
    "port": 22,
    "username": "your-username",
    "privateKey": "-----BEGIN RSA PRIVATE KEY-----\nMIIJK...\n-----END RSA PRIVATE KEY-----"
  }
}
```

成功後會返回：

```json
{
  "success": true,
  "apiKey": "ssh-4d563f5e-f1c",
  "host": "192.168.56.101",
  "port": 22,
  "username": "your-username",
  "message": "SSH 會話建立成功。apiKey: ssh-4d563f5e-f1c。請使用此 apiKey 調用 executeSSHCommand 工具執行命令。會話將在 15 分鐘無活動後自動清理。"
}
```

### 2. 執行 SSH 命令

使用獲得的 `apiKey` 執行遠端命令：

```json
{
  "tool": "executeSSHCommand",
  "parameters": {
    "apiKey": "ssh-4d563f5e-f1c",
    "command": "whoami"
  }
}
```

返回結果：

```json
{
  "success": true,
  "apiKey": "ssh-4d563f5e-f1c",
  "command": "whoami",
  "output": "your-username\n",
  "message": "命令執行成功"
}
```

### 3. 在 GitHub Copilot 中使用

當 SSH MCP Server 在 VS Code 中配置為 MCP 工具後，您可以直接向 Copilot 發送指令：

```
幫我連接到 VM (192.168.56.101)，使用者是 tsai，私鑰在 C:\Users\xxx\.ssh\mcp_key_pem
```

Copilot 會自動：
1. 讀取私鑰內容
2. 調用 `createSSHSession` 建立會話
3. 獲得 `apiKey`
4. 使用 `executeSSHCommand` 執行後續命令

## 📁 專案結構

```
com-momo-ltsre-ssh/
├── src/
│   ├── main/
│   │   ├── java/com/momo/ltsre/ssh/
│   │   │   ├── SshMcpServerApplication.java      # Spring Boot 主程式
│   │   │   ├── config/
│   │   │   │   └── McpServerConfig.java          # MCP Server 配置
│   │   │   ├── model/
│   │   │   │   ├── SshCommandRequest.java        # SSH 命令請求模型
│   │   │   │   └── SshSessionWrapper.java        # SSH 會話包裝類
│   │   │   └── service/
│   │   │       ├── McpSshExecutionService.java   # MCP 工具提供者
│   │   │       └── SshSessionManager.java        # SSH 會話管理器
│   │   └── resources/
│   │       └── application.properties            # 應用配置
│   └── test/
├── Dockerfile                                     # Docker 建置檔案
├── pom.xml                                        # Maven 專案配置
└── README.md                                      # 專案說明文件
```

## 🔑 核心組件說明

### McpSshExecutionService

MCP 工具提供者，暴露兩個核心工具給 AI 助手：

- **createSSHSession** - 建立 SSH 會話並返回 apiKey
- **executeSSHCommand** - 使用 apiKey 執行遠端命令

### SshSessionManager

管理 SSH 會話的生命週期：

- 建立和維護 SSH 連接
- 管理命令隊列（每個會話一個隊列）
- 自動清理過期會話（15 分鐘無活動）
- 命令序列化執行（確保 SSH 協議正確性）

### SshSessionWrapper

封裝單個 SSH 會話的狀態：

- SSH 客戶端連接
- 命令執行隊列
- 上次使用時間
- 會話唯一標識（apiKey）

## ⚙️ 配置說明

### application.properties

```properties
# 應用程式基本配置
spring.application.name=ssh-mcp-server
server.port=8080

# Spring AI MCP Server 配置
spring.ai.mcp.server.enabled=true
spring.ai.mcp.server.name=SSH Remote Command Execution Server
spring.ai.mcp.server.version=1.0.0

# MCP Server 功能配置
spring.ai.mcp.server.capabilities.tool=true
spring.ai.mcp.server.capabilities.resource=false
spring.ai.mcp.server.capabilities.prompt=false
spring.ai.mcp.server.capabilities.completion=false

# 日誌配置
logging.level.root=INFO
logging.level.com.momo.ltsre.ssh=DEBUG
```

## 🔒 安全性考量

1. **私鑰安全**
   - 私鑰內容通過 HTTPS 傳輸
   - 私鑰僅在記憶體中使用，不會寫入磁碟
   - 會話結束後自動清理

2. **會話管理**
   - 每個會話都有唯一的 apiKey
   - 自動超時機制防止資源洩漏
   - 會話僅能執行提交的命令

3. **網路安全**
   - 建議在內部網路或 VPN 環境中使用
   - 可配置防火牆規則限制訪問

## 🛠️ 技術棧

- **Spring Boot 3.4.10** - 應用程式框架
- **Spring AI 1.0.3** - MCP Server 實現
- **Apache MINA SSHD 2.12.0** - SSH 客戶端庫
- **Bouncy Castle 1.78.1** - 加密和密鑰解析
- **Java 21** - 程式語言版本
- **Maven 3.9** - 建置工具
- **Docker** - 容器化部署

## 📊 系統需求

### 運行時需求

- **記憶體**: 最小 256MB，建議 512MB
- **CPU**: 單核心即可，建議雙核心
- **磁碟**: 約 50MB（應用程式 + JRE）
- **網路**: 需要能夠訪問目標 SSH 主機

### Docker 容器配置

預設資源限制（可在 docker run 時調整）：

```bash
docker run -d \
  --memory="512m" \
  --cpus="0.5" \
  -p 10002:8080 \
  --name ssh-mcp-server \
  ssh-mcp-server:1.0.0
```

## 🐛 疑難排解

### 連接失敗

**問題**: `建立 SSH 會話失敗: 私鑰解析失敗`

**解決方案**:
- 確認私鑰格式正確（包含完整的 BEGIN/END 標籤）
- 確認私鑰類型被支援（RSA/DSA/ECDSA）
- 檢查私鑰是否有密碼保護（目前不支援）

### apiKey 不存在

**問題**: `apiKey 不存在，可能已超時或未建立。請先調用 createSSHSession`

**解決方案**:
- 重新調用 `createSSHSession` 建立新會話
- 確認會話未超過 15 分鐘無活動時間

### 命令執行超時

**問題**: 命令長時間無回應

**解決方案**:
- 檢查命令是否需要互動式輸入
- 使用非互動式命令（如 `ls -la` 而非 `top`）
- 確認網路連接穩定

## 📝 版本歷史

### v1.0.0 (2025-11-05)

- ✨ 初始版本發布
- ✅ 支援 SSH 私鑰認證
- ✅ 持久化會話管理
- ✅ 命令序列化執行
- ✅ 自動超時清理
- ✅ Docker 容器化部署

## 🤝 貢獻

歡迎提交 Issue 和 Pull Request！

## 📄 授權

請參考專案授權文件。
