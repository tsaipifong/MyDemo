package idv.tsai.example.pattern.service.member;


/**
 * 工廠方法介面
 */
public interface MemberServiceFactory<SERVICE extends MemberService<? extends MemberRequest, ? extends MemberResponse>> {

    SERVICE getSingleton();

}
