package idv.tsai.example.pattern.service.order.create;

import idv.tsai.example.pattern.service.order.OrderResponse;

public class CreateOrderResponse extends OrderResponse {

}
