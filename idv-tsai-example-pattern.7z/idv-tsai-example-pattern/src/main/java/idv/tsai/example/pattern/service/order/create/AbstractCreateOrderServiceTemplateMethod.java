package idv.tsai.example.pattern.service.order.create;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 模版方法模式
 */
abstract class AbstractCreateOrderServiceTemplateMethod implements CreateOrderService<CreateOrderRequest, CreateOrderResponse> {

    private static final Logger LOGGER = LoggerFactory.getLogger(AbstractCreateOrderServiceTemplateMethod.class);

    /**
     * 模版方法
     */
    @Override
    public final CreateOrderResponse execute(CreateOrderRequest request) {
        
        
        LOGGER.info("Executing create order service with request: {}", request);
        
        // Pre-processing steps
        preProcess(request);

        // Core logic for creating an order
        createOrder(request);

        // Post-processing steps
        postProcess(request);

        // Create and return the response
        CreateOrderResponse response = new CreateOrderResponse();
        response.setSuccess(true);
        LOGGER.info("Create order service executed successfully with response: {}", response);
        
        return response;

    }

    protected abstract void preProcess(CreateOrderRequest request);

    protected abstract void createOrder(CreateOrderRequest request);

    protected abstract void postProcess(CreateOrderRequest request);

}
