package idv.tsai.example.pattern.utils.json;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;


/**
 * Facade for JSON conversion using Gson / Jackson.
 * 
 * 門戶(外觀)模式類別，提供統一的介面進行 JSON 轉換，可抽換底層實現。
 * 
 * 如果Gson發生安全漏洞，可以切換到Jackson。
 */
public class MyJsonUtil {

    private static final Logger LOGGER = LoggerFactory.getLogger(MyJsonUtil.class);

    public static String toJson(Object object) {

        LOGGER.info("Converting object to JSON by using Gson");
        Gson gson = new Gson();
        return gson.toJson(object);

        // LOGGER.info("Converting object to JSON by using Jackson");
        // ObjectMapper mapper = new ObjectMapper();
        // try {
        //     return mapper.writeValueAsString(object);
        // } catch (Exception e) {
        //     throw new RuntimeException("Failed to convert object to JSON", e);
        // } 

    }

}
