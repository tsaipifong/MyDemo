package idv.tsai.example.pattern.service.order;

public interface OrderServiceFactory<REQUEST extends OrderRequest, RESPONSE extends OrderResponse, SERVICE extends OrderService<REQUEST, RESPONSE>> {

    public SERVICE getSingleton();

}
