package idv.tsai.example.pattern.service.order;

import idv.tsai.example.pattern.service.MyServiceResponse;

public class OrderResponse extends MyServiceResponse {


}
