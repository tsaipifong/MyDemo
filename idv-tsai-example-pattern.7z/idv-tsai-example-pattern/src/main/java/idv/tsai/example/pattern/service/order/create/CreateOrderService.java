package idv.tsai.example.pattern.service.order.create;

import idv.tsai.example.pattern.service.order.OrderService;

public interface CreateOrderService<REQUEST extends CreateOrderRequest, RESPONSE extends CreateOrderResponse> extends OrderService<REQUEST, RESPONSE> {

    @Override
    RESPONSE execute(REQUEST request);

}
