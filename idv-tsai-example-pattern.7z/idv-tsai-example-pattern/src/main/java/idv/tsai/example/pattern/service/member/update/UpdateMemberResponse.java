package idv.tsai.example.pattern.service.member.update;

import idv.tsai.example.pattern.service.member.MemberResponse;

public class UpdateMemberResponse extends MemberResponse {

}
