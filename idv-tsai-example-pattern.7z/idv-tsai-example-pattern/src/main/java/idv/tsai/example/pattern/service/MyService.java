package idv.tsai.example.pattern.service;

public interface MyService<REQUEST extends MyServiceRequest, RESPONSE extends MyServiceResponse> {

    RESPONSE execute(REQUEST request);

}
