package idv.tsai.example.pattern.utils.validation.order.create;

import idv.tsai.example.pattern.service.order.create.CreateOrderRequest;
import idv.tsai.example.pattern.utils.validation.MyValidationException;
import idv.tsai.example.pattern.utils.validation.order.OrderValidator;

public interface CreateOrderValidator extends OrderValidator<CreateOrderRequest, CreateOrderValidator, CreateOrderValidatorChain> {

    @Override
    void doValidate(CreateOrderRequest request, CreateOrderValidatorChain chain) throws MyValidationException;


}
