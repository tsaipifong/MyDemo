package idv.tsai.example.pattern.utils.validation.order.create;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import idv.tsai.example.pattern.service.order.create.CreateOrderRequest;
import idv.tsai.example.pattern.utils.validation.MyValidationException;

class NullValueValidator implements CreateOrderValidator {

    private static final Logger LOGGER = LoggerFactory.getLogger(NullValueValidator.class);

    @Override
    public void doValidate(CreateOrderRequest request, CreateOrderValidatorChain chain) throws MyValidationException {
        LOGGER.debug("Validating null values for CreateOrderRequest: {}", request);
        if (request == null) {
            chain.addException(new MyValidationException("CreateOrderRequest cannot be null"));
        } else {
            if (request.getOrderId() == null) {
                chain.addException(new MyValidationException("Order ID cannot be null"));
            }
            if (request.getMemberId() == null) {
                chain.addException(new MyValidationException("Member ID cannot be null"));
            }
        }
        chain.doValidate(request);
    }

}
