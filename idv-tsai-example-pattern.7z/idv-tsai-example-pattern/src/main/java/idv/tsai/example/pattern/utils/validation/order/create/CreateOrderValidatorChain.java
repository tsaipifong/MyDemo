package idv.tsai.example.pattern.utils.validation.order.create;

import idv.tsai.example.pattern.service.order.create.CreateOrderRequest;
import idv.tsai.example.pattern.utils.validation.MyValidationException;
import idv.tsai.example.pattern.utils.validation.order.OrderValidatorChain;

public interface CreateOrderValidatorChain extends OrderValidatorChain<CreateOrderRequest, CreateOrderValidator, CreateOrderValidatorChain> {

    @Override
    void addValidator(CreateOrderValidator validator);

    @Override
    void doValidate(CreateOrderRequest request) throws MyValidationException;

}
