package idv.tsai.example.pattern.service.product.create;

import idv.tsai.example.pattern.service.product.ProductRequest;

public class CreateProductRequest extends ProductRequest {

}
