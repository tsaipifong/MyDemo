package idv.tsai.example.pattern.service.order;

import idv.tsai.example.pattern.service.MyService;

public interface OrderService<REQUEST extends OrderRequest, RESPONSE extends OrderResponse> 
extends MyService<REQUEST, RESPONSE> {

    RESPONSE execute(REQUEST request);

}
