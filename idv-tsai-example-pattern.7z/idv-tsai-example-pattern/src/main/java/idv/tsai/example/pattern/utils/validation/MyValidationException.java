package idv.tsai.example.pattern.utils.validation;

import java.util.Arrays;
import java.util.Iterator;

/**
 * 迭代模式
 */
public class MyValidationException extends RuntimeException implements Iterable<Throwable> {

    private static final long serialVersionUID = 123456789987654321L;

    public MyValidationException(String message) {
        super(message);
    }

    @Override
    public Iterator<Throwable> iterator() {
        return Arrays.asList(this.getSuppressed()).iterator();
    }

}
