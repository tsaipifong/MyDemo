package idv.tsai.example.pattern.service.member;

import idv.tsai.example.pattern.service.MyServiceResponse;

public class MemberResponse extends MyServiceResponse {


}
