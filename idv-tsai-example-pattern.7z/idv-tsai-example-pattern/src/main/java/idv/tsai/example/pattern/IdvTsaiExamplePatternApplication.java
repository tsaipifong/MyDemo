package idv.tsai.example.pattern;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IdvTsaiExamplePatternApplication {

	public static void main(String[] args) {
		SpringApplication.run(IdvTsaiExamplePatternApplication.class, args);
	}

}
