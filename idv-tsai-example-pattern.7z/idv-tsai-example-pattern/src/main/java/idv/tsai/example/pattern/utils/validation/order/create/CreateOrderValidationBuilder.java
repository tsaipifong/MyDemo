package idv.tsai.example.pattern.utils.validation.order.create;

public class CreateOrderValidationBuilder {

    private CreateOrderValidatorChain validatorChain;

    private CreateOrderValidationBuilder() {
    }

    public static CreateOrderValidationBuilder builder() {
        CreateOrderValidationBuilder builder = new CreateOrderValidationBuilder();
        builder.init();
        return builder;
    }

    private void init(){
        this.validatorChain = new CreateOrderValidatorChainImpl();
        this.validatorChain.addValidator(new NullValueValidator());
        this.validatorChain.addValidator(new EmptyValueValidator());
        this.validatorChain.addValidator(new MaxLengthValidator(10));
    }

    public CreateOrderValidatorChain build() {
        return validatorChain;
    }

}
