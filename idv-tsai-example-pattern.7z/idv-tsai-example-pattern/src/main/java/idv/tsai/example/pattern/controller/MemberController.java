package idv.tsai.example.pattern.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import idv.tsai.example.pattern.service.member.MemberServiceSimpleFactory;
import idv.tsai.example.pattern.service.member.create.CreateMemberRequest;
import idv.tsai.example.pattern.service.member.create.CreateMemberResponse;
import idv.tsai.example.pattern.service.member.create.CreateMemberService;
import idv.tsai.example.pattern.service.member.update.UpdateMemberGradeRequest;
import idv.tsai.example.pattern.service.member.update.UpdateMemberGradeResponse;
import idv.tsai.example.pattern.service.member.update.UpdateMemberRequest;
import idv.tsai.example.pattern.service.member.update.UpdateMemberResponse;
import idv.tsai.example.pattern.service.member.update.UpdateMemberService;



@RestController
public class MemberController {

    private static final Logger LOGGER = LoggerFactory.getLogger(MemberController.class);

    @GetMapping("/member/create")
    public CreateMemberResponse memberCreate(@RequestBody CreateMemberRequest createMemberRequest) {
        LOGGER.info("Processing create member request: {}", createMemberRequest);
        @SuppressWarnings("unchecked")
        CreateMemberService<CreateMemberRequest, CreateMemberResponse> createMemberService = (CreateMemberService<CreateMemberRequest, CreateMemberResponse>) MemberServiceSimpleFactory.getSingleton(createMemberRequest);
        CreateMemberResponse response = createMemberService.execute(createMemberRequest);
        LOGGER.info("Create member response: {}", response);
        return response;
    }

    @GetMapping("/member/update")
    public UpdateMemberResponse memberUpdate(@RequestBody UpdateMemberRequest updateMemberRequest) {
        LOGGER.info("Processing update member request: {}", updateMemberRequest);
        @SuppressWarnings("unchecked")
        UpdateMemberService<UpdateMemberRequest, UpdateMemberResponse> updateMemberService = (UpdateMemberService<UpdateMemberRequest, UpdateMemberResponse>) MemberServiceSimpleFactory.getSingleton(updateMemberRequest);
        UpdateMemberResponse response = updateMemberService.execute(updateMemberRequest);
        LOGGER.info("Update member response: {}", response);
        return response;
    }

    @GetMapping("/member/update/grade")
    public UpdateMemberGradeResponse updateMemberGrade(@RequestBody UpdateMemberGradeRequest updateMemberGradeRequest) {
        LOGGER.info("Processing update member grade request: {}", updateMemberGradeRequest);
        @SuppressWarnings("unchecked")
        UpdateMemberService<UpdateMemberGradeRequest, UpdateMemberGradeResponse> updateMemberService = (UpdateMemberService<UpdateMemberGradeRequest, UpdateMemberGradeResponse>) MemberServiceSimpleFactory.getSingleton(updateMemberGradeRequest);
        UpdateMemberGradeResponse response = updateMemberService.execute(updateMemberGradeRequest);
        LOGGER.info("Update member grade response: {}", response);
        return response;
    }

}
