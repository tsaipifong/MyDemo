package idv.tsai.example.pattern.service.member.update;

import idv.tsai.example.pattern.service.member.MemberGrade;

/**
 * 簡單工廠模式
 */
public class UpdateMemberServiceFactory {

    private static final class InstanceHolder {
        private static final UpdateMemberServiceImpl INSTANCE = new UpdateMemberServiceImpl();
    }

    private static final class InstanceHolderForGradeNormal {
        private static final UpdateMemberGradeNormal INSTANCE = new UpdateMemberGradeNormal();
    }

    private static final class InstanceHolderForGradeVIP {
        private static final UpdateMemberGradeVIP INSTANCE = new UpdateMemberGradeVIP();
    }

    private static final class InstanceHolderForGradeSuperVIP {
        private static final UpdateMemberGradeSuperVIP INSTANCE = new UpdateMemberGradeSuperVIP();
    }

    public static UpdateMemberService<UpdateMemberRequest, UpdateMemberResponse> getSingleton() {
        return InstanceHolder.INSTANCE;
    }

    /**
     * 策略模式，根據會員等級決定更新會員策略
     */
    public static UpdateMemberService<UpdateMemberGradeRequest, UpdateMemberGradeResponse> getSingleton(MemberGrade memberGrade) {
        switch (memberGrade) {
            case Normal:
                return InstanceHolderForGradeNormal.INSTANCE;
            case VIP:
                return InstanceHolderForGradeVIP.INSTANCE;
            case SuperVIP:
                return InstanceHolderForGradeSuperVIP.INSTANCE;
            default:
                throw new IllegalArgumentException("未知的會員等級: " + memberGrade);
        }
    }

}
