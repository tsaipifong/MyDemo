package idv.tsai.example.pattern.utils.validation;

import idv.tsai.example.pattern.service.MyServiceRequest;

public interface MyValidator<REQUEST extends MyServiceRequest, VALIDATOR extends MyValidator<REQUEST, VALIDATOR, CHAIN>, CHAIN extends MyValidatorChain<REQUEST, VALIDATOR, CHAIN>> {

    void doValidate(REQUEST request, CHAIN chain) throws MyValidationException;

}
