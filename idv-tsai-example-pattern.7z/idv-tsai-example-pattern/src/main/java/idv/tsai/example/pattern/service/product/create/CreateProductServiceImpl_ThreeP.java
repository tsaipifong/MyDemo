package idv.tsai.example.pattern.service.product.create;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import idv.tsai.example.pattern.service.product.create.dao.CreateProductDao;

class CreateProductServiceImpl_ThreeP implements CreateProductService<CreateProductRequest, CreateProductResponse> {

    private static final Logger LOGGER = LoggerFactory.getLogger(CreateProductServiceImpl_ThreeP.class);

    private CreateProductDao createProductDao;

    public CreateProductServiceImpl_ThreeP(CreateProductDao createProductDao) {
        this.createProductDao = createProductDao;
    }

    @Override
    public CreateProductResponse execute(CreateProductRequest request) {

        LOGGER.info("Executing create product with request: {}", request);

        LOGGER.info("Create product business logic of 3P");
        
        createProductDao.createProduct(request);
        CreateProductResponse response = new CreateProductResponse();
        response.setSuccess(true);
        LOGGER.info("Create product response: {}", response);
        return response;
        
    }

}
