package idv.tsai.example.pattern.service.member.create;

import idv.tsai.example.pattern.service.member.MemberResponse;

public class CreateMemberResponse extends MemberResponse {


}
