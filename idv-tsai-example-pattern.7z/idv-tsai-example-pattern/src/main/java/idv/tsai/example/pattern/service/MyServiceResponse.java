package idv.tsai.example.pattern.service;

import idv.tsai.example.pattern.utils.json.MyJsonUtil;

public class MyServiceResponse implements Cloneable {

    private boolean success = true;

    public MyServiceResponse() {
    }

    public MyServiceResponse(boolean success) {
        this.success = success;
    }

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    @Override
    public String toString() {
        return MyJsonUtil.toJson(this);
    }

    @Override
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }

}
