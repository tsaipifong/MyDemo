package idv.tsai.example.pattern.service.member.update;


public class UpdateMemberGradeResponse extends UpdateMemberResponse {

}
