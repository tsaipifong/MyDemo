package idv.tsai.example.pattern.service.product.create;

import idv.tsai.example.pattern.service.product.ProductService;

public interface CreateProductService<REQUEST extends CreateProductRequest, RESPONSE extends CreateProductResponse> 
extends ProductService<REQUEST, RESPONSE> {

    @Override
    RESPONSE execute(REQUEST request);

}
