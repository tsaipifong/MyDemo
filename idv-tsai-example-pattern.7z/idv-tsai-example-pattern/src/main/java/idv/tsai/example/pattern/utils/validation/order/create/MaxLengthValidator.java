package idv.tsai.example.pattern.utils.validation.order.create;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import idv.tsai.example.pattern.service.order.create.CreateOrderRequest;
import idv.tsai.example.pattern.utils.validation.MyValidationException;

class MaxLengthValidator implements CreateOrderValidator {

    private static final Logger LOGGER = LoggerFactory.getLogger(MaxLengthValidator.class);

    private final int maxLength;

    public MaxLengthValidator(int maxLength) {
        this.maxLength = maxLength;
    }

    @Override
    public void doValidate(CreateOrderRequest request, CreateOrderValidatorChain chain) throws MyValidationException {
        LOGGER.debug("Validating max length for CreateOrderRequest: {}", request);
        if (request != null && request.getOrderId() != null && request.getOrderId().length() > maxLength) {
            chain.addException(new MyValidationException("Order ID exceeds maximum length of " + maxLength));
        }
        if (request != null && request.getMemberId() != null && request.getMemberId().length() > maxLength) {
            chain.addException(new MyValidationException("Member ID exceeds maximum length of " + maxLength));
        }
        chain.doValidate(request);
    }

}
