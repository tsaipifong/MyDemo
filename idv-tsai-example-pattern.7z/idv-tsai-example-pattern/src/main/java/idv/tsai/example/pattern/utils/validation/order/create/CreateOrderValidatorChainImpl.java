package idv.tsai.example.pattern.utils.validation.order.create;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import idv.tsai.example.pattern.service.order.create.CreateOrderRequest;
import idv.tsai.example.pattern.utils.validation.MyValidationException;

class CreateOrderValidatorChainImpl implements CreateOrderValidatorChain {

    private static final Logger LOGGER = LoggerFactory.getLogger(CreateOrderValidatorChainImpl.class);

    private MyValidationException validationException = null;
    private final List<CreateOrderValidator> validators = new ArrayList<>();
    private int currentIndex = 0;

    @Override
    public void addValidator(CreateOrderValidator validator) {
        validators.add(validator);
    }

    @Override
    public void doValidate(CreateOrderRequest request) throws MyValidationException {
        LOGGER.info("Validators count: {}", validators.size());
        LOGGER.info("Current index: {}", currentIndex);
        if (hasNext()) {
            validators.get(currentIndex++).doValidate(request, this);
        } else {
            LOGGER.info("check validationException is null:{}", validationException == null);
            if (validationException != null) {
                LOGGER.info("Validation failed with errors: {}", validationException.getMessage());
                throw validationException;
            }
        }
    }

    @Override
    public boolean hasNext() {
        return currentIndex < validators.size();
    }

    @Override
    public void addException(MyValidationException exception) {
        if(validationException == null) {
            validationException = new MyValidationException("Validation failed with errors");
        }
        validationException.addSuppressed(exception);
    }

}
