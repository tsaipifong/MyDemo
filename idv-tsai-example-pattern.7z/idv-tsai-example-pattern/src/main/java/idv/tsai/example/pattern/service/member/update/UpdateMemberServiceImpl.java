package idv.tsai.example.pattern.service.member.update;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 開閉原則：對擴展開放，對修改閉合
 */
class UpdateMemberServiceImpl implements UpdateMemberService<UpdateMemberRequest, UpdateMemberResponse> {

    private static final Logger LOGGER = LoggerFactory.getLogger(UpdateMemberServiceImpl.class);

    private static final UpdateMemberResponse RESPONSE = new UpdateMemberResponse();

    @Override
    public UpdateMemberResponse execute(UpdateMemberRequest updateMemberRequest) {

        LOGGER.info("Updating member: {}", updateMemberRequest);

        /**
         * 使用原型模式克隆回應物件，確保每次執行都返回新的實例
         */
        UpdateMemberResponse response;
        try {
            response = (UpdateMemberResponse) RESPONSE.clone();
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage(), e);
        }

        LOGGER.info("Member updated successfully: {}", response);

        LOGGER.info("SAME OBJECT? {}", response == RESPONSE);

        return response;
    }

}
