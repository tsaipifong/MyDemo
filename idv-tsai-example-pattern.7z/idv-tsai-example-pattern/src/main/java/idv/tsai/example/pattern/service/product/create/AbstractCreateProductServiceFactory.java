package idv.tsai.example.pattern.service.product.create;

import idv.tsai.example.pattern.service.product.create.dao.CreateProductDao;

/**
 * 抽象工廠
 * 希望保持架構的靈活性和可擴展性時使用抽象工廠模式。
 */
public abstract class AbstractCreateProductServiceFactory {

    public enum ShopType {
        OneP, ThreeP;
    }

    public abstract CreateProductDao configCreateProductDao();

    public CreateProductService<CreateProductRequest, CreateProductResponse> getCreateProductService(ShopType shopType) {
        CreateProductDao dao = configCreateProductDao();
        return switch (shopType) {
            case OneP -> new CreateProductServiceImpl_OneP(dao);
            case ThreeP -> new CreateProductServiceImpl_ThreeP(dao);
            default -> throw new IllegalArgumentException("Unknown ShopType: " + shopType);
        };
    }

}
