package idv.tsai.example.pattern.service.order.create;

public class CreateOrderServiceFactoryImpl implements CreateOrderServiceFactory {

    private static final class InstanceHolder {
        private static final AbstractCreateOrderServiceTemplateMethod INSTANCE = new ProxyCreateOrderServiceImpl(new CreateOrderServiceImpl());
    }

    @Override
    public CreateOrderService<CreateOrderRequest, CreateOrderResponse> getSingleton() {
        return InstanceHolder.INSTANCE;
    }

}
