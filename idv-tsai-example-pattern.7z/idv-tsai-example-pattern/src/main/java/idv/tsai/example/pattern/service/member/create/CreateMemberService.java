package idv.tsai.example.pattern.service.member.create;

import idv.tsai.example.pattern.service.member.MemberService;

public interface CreateMemberService<REQUEST extends CreateMemberRequest, RESPONSE extends CreateMemberResponse> 
extends MemberService<REQUEST, RESPONSE> {


}
