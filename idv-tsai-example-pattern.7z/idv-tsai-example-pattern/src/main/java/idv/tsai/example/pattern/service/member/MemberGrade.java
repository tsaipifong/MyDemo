package idv.tsai.example.pattern.service.member;

public enum MemberGrade {
    Normal, VIP, SuperVIP;
}
