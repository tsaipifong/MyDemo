package idv.tsai.example.pattern.service.product;

import idv.tsai.example.pattern.service.MyService;

public interface ProductService<REQUEST extends ProductRequest, RESPONSE extends ProductResponse> 
extends MyService<REQUEST, RESPONSE> {

    RESPONSE execute(REQUEST productServiceRequest);

}
