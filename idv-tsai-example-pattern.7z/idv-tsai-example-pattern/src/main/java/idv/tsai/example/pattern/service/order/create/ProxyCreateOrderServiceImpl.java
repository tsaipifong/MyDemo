package idv.tsai.example.pattern.service.order.create;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import idv.tsai.example.pattern.utils.validation.MyValidationException;
import idv.tsai.example.pattern.utils.validation.order.create.CreateOrderValidationBuilder;
import idv.tsai.example.pattern.utils.validation.order.create.CreateOrderValidatorChain;


/**
 * 靜態代理
 */
class ProxyCreateOrderServiceImpl extends AbstractCreateOrderServiceTemplateMethod {

    private static final Logger LOGGER = LoggerFactory.getLogger(ProxyCreateOrderServiceImpl.class);

    private CreateOrderServiceImpl delegate;

    ProxyCreateOrderServiceImpl(CreateOrderServiceImpl delegate) {
        this.delegate = delegate;
    }

    @Override
    protected void preProcess(CreateOrderRequest request) {
        CreateOrderValidatorChain chain = CreateOrderValidationBuilder.builder().build();
        try {
            chain.doValidate(request);
        } catch (MyValidationException e) {
            Iterator<Throwable> it = e.iterator();
            List<String> errorMessages = new ArrayList<>();
            while (it.hasNext()) {
                Throwable throwable = it.next();
                errorMessages.add(throwable.getMessage());
            }
            LOGGER.error("Validation errors found: {}", errorMessages);
            throw new RuntimeException("Validation failed: " + String.join(", ", errorMessages));
        }
        delegate.preProcess(request);
    }

    @Override
    protected void createOrder(CreateOrderRequest request) {
        delegate.createOrder(request);
    }

    @Override
    protected void postProcess(CreateOrderRequest request) {
        delegate.postProcess(request);
    }

}
