package idv.tsai.example.pattern.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import idv.tsai.example.pattern.service.product.create.AbstractCreateProductServiceFactory;
import idv.tsai.example.pattern.service.product.create.AbstractCreateProductServiceFactory.ShopType;
import idv.tsai.example.pattern.service.product.create.CreateProductRequest;
import idv.tsai.example.pattern.service.product.create.CreateProductResponse;
import idv.tsai.example.pattern.service.product.create.CreateProductService;
import idv.tsai.example.pattern.service.product.create.CreateProductServiceBuilder;
import idv.tsai.example.pattern.service.product.create.CreateProductServiceBuilder.BuildType;
import idv.tsai.example.pattern.service.product.create.dao.CreateProductDao;
import idv.tsai.example.pattern.service.product.create.dao.CreateProductDaoFactory;
import idv.tsai.example.pattern.service.product.create.dao.CreateProductDaoFactory.DaoType;

@RestController
public class ProductController {

    private static final Logger LOGGER = LoggerFactory.getLogger(ProductController.class);

    @GetMapping("/product/create/by/{shopType}/{daoType}")
    public CreateProductResponse createProduct(@RequestBody CreateProductRequest request,
                                                @PathVariable ShopType shopType,
                                                @PathVariable DaoType daoType) {
        AbstractCreateProductServiceFactory factory = new AbstractCreateProductServiceFactory() {
            @Override
            public CreateProductDao configCreateProductDao() {
                return CreateProductDaoFactory.getInstance(daoType);
            }
        };
        return factory.getCreateProductService(shopType).execute(request);
    }

    /**
     * 使用自定義的 DAO 實現
     */
    @GetMapping("/product/create/customdao/{shopType}")
    public CreateProductResponse createProductCustomDao(@RequestBody CreateProductRequest request,
                                                         @PathVariable ShopType shopType) {
        CreateProductCustomDaoFactory factory = new CreateProductCustomDaoFactory();
        return factory.getCreateProductService(shopType).execute(request);
    }

    /**
     * 為方便查閱寫在這，否則應該寫為獨立類
     */
    private static final class CreateProductCustomDaoFactory extends AbstractCreateProductServiceFactory {
        @Override
        public CreateProductDao configCreateProductDao() {
            return new CreateProductDao() {
                @Override
                public void createProduct(CreateProductRequest request) {
                    LOGGER.info("Creating product with custom dao logic: {}", request);
                }
            };
        }
    }

    /**
     * 自定義服務實現，daotype邏輯
     */
    @GetMapping("/product/create/customservice/{daoType}")
    public CreateProductResponse createProductCustom(@RequestBody CreateProductRequest request,
                                                      @PathVariable DaoType daoType) {
        
        CreateProductDao dao = CreateProductDaoFactory.getInstance(daoType);
        CreateProductCustomServiceFactory factory = new CreateProductCustomServiceFactory(dao);

        return factory.getCreateProductService(null).execute(request);
    }

    /**
     * 為方便查閱寫在這，否則應該寫為獨立類
     */
    private static final class CreateProductCustomServiceFactory extends AbstractCreateProductServiceFactory {

        private final CreateProductDao dao;

        public CreateProductCustomServiceFactory(CreateProductDao dao) {
            super();
            this.dao = dao;
        }

        @Override
        public CreateProductDao configCreateProductDao() {
            return dao;
        }

        @Override
        public CreateProductService<CreateProductRequest, CreateProductResponse> getCreateProductService(ShopType shopType) {
            return new CreateProductService<>() {
                @Override
                public CreateProductResponse execute(CreateProductRequest request) {
                    LOGGER.info("Executing all custom create product logic: {}", request);
                    dao.createProduct(request);
                    CreateProductResponse response = new CreateProductResponse();
                    response.setSuccess(true);
                    LOGGER.info("All custom create product response: {}", response);
                    return response;
                }
            };
        }
    }

    @GetMapping("/product/create/builder/{shopType}/{daoType}")
    public CreateProductResponse createProductBuilder(@RequestBody CreateProductRequest request,
                                                      @PathVariable ShopType shopType,
                                                      @PathVariable DaoType daoType) {

        CreateProductService<CreateProductRequest, CreateProductResponse> service = CreateProductServiceBuilder.builder()
                .shopType(shopType)
                .daoType(daoType)
                .build();
        return service.execute(request);
    }

    @GetMapping("/product/create/builder-flyweight")
    public CreateProductResponse createProductBuilderFlyweight(@RequestBody CreateProductRequest request) {
        CreateProductService<CreateProductRequest, CreateProductResponse> service = CreateProductServiceBuilder.builder()
                .build(BuildType.ThreeP_API);
        return service.execute(request);
    }

}
