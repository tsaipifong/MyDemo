package idv.tsai.example.pattern.service;

import idv.tsai.example.pattern.utils.json.MyJsonUtil;

public class MyServiceRequest implements Cloneable {

    @Override
    public String toString() {
        return MyJsonUtil.toJson(this);
    }

    @Override
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }

}
