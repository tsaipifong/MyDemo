package idv.tsai.example.pattern.service.product.create;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import idv.tsai.example.pattern.service.product.create.AbstractCreateProductServiceFactory.ShopType;
import idv.tsai.example.pattern.service.product.create.dao.CreateProductDao;
import idv.tsai.example.pattern.service.product.create.dao.CreateProductDaoFactory;
import idv.tsai.example.pattern.service.product.create.dao.CreateProductDaoFactory.DaoType;

/**
 * 建造者模式：用於構建複雜對象的過程
 */
public class CreateProductServiceBuilder {

    private static final Logger LOGGER = LoggerFactory.getLogger(CreateProductServiceBuilder.class);

    private ShopType shopType;
    private DaoType daoType;

    private CreateProductServiceBuilder() {
    }

    public static CreateProductServiceBuilder builder() {
        return new CreateProductServiceBuilder();
    }

    public CreateProductServiceBuilder shopType(ShopType shopType) {
        this.shopType = shopType;
        return this;
    }

    public CreateProductServiceBuilder daoType(DaoType daoType) {
        this.daoType = daoType;
        return this;
    }

    /**
     * 建造者模式，若shopType與daoType未提供，則使用預設的值
     * 這裡分別預設為 OneP 和 DB
     */
    public CreateProductService<CreateProductRequest, CreateProductResponse> build() {
        if (shopType == null) {
            shopType = ShopType.OneP;
            LOGGER.warn("ShopType is null, using default: {}", shopType);
        }
        if (daoType == null) {
            daoType = DaoType.DB;
            LOGGER.warn("DaoType is null, using default: {}", daoType);
        }
        for (BuildType buildType : BuildType.values()) {
            if (buildType.getShopType() == shopType && buildType.getDaoType() == daoType) {
                LOGGER.info("Using existing BuildType: {}", buildType);
                return buildType.getService();
            }
        }
        // 邏輯均使用enum，且排除null的情況，因此理論上程式不會執行到這裡
        LOGGER.warn("No matching BuildType found, using default: {}", BuildType.OneP_DB);
        return BuildType.OneP_DB.getService();
    }

    /**
     * 依BuildType提供服務
     */
    public CreateProductService<CreateProductRequest, CreateProductResponse> build(BuildType buildType) {
        if(buildType == null) {
            LOGGER.warn("BuildType is null, using default: {}", BuildType.OneP_DB);
            buildType = BuildType.OneP_DB;
        }
        LOGGER.info("Building CreateProductService with BuildType:{}", buildType);
        return buildType.getService();
    }

    /**
     * 享元模式 Flyweight Pattern 
     */
    public enum BuildType {

        OneP_DB(ShopType.OneP, DaoType.DB), OneP_API(ShopType.OneP, DaoType.API),
        ThreeP_DB(ShopType.ThreeP, DaoType.DB), ThreeP_API(ShopType.ThreeP, DaoType.API);

        private ShopType shopType;
        private DaoType daoType;
        private CreateProductService<CreateProductRequest, CreateProductResponse> service;

        private BuildType(ShopType shopType, DaoType daoType) {
            this.shopType = shopType;
            this.daoType = daoType;
            CreateProductDao dao = CreateProductDaoFactory.getInstance(daoType);
            this.service = switch (shopType) {
                case OneP -> new CreateProductServiceImpl_OneP(dao);
                case ThreeP -> new CreateProductServiceImpl_ThreeP(dao);
                default -> throw new IllegalArgumentException("Unknown ShopType: " + shopType);
            };
        }

        public ShopType getShopType() {
            return shopType;
        }

        public DaoType getDaoType() {
            return daoType;
        }

        public CreateProductService<CreateProductRequest, CreateProductResponse> getService() {
            return service;
        }
    }

}
