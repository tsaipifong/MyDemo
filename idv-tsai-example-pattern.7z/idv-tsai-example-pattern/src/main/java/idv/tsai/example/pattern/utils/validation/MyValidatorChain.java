package idv.tsai.example.pattern.utils.validation;

import idv.tsai.example.pattern.service.MyServiceRequest;

public interface MyValidatorChain<REQUEST extends MyServiceRequest, VALIDATOR extends MyValidator<REQUEST, VALIDATOR, CHAIN>, CHAIN extends MyValidatorChain<REQUEST, VALIDATOR, CHAIN>> {

    void addValidator(VALIDATOR validator);

    void doValidate(REQUEST request) throws MyValidationException;

    boolean hasNext();

    void addException(MyValidationException exception);

}
