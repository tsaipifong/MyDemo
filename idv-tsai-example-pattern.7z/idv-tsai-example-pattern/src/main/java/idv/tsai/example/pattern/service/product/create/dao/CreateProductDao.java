package idv.tsai.example.pattern.service.product.create.dao;

import idv.tsai.example.pattern.service.product.create.CreateProductRequest;

public interface CreateProductDao {

    void createProduct(CreateProductRequest request);

}
