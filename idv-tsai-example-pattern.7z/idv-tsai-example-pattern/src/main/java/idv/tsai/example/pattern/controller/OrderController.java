package idv.tsai.example.pattern.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import idv.tsai.example.pattern.service.order.create.CreateOrderRequest;
import idv.tsai.example.pattern.service.order.create.CreateOrderResponse;
import idv.tsai.example.pattern.service.order.create.CreateOrderServiceFactoryImpl;

@RestController
public class OrderController {

    private static final CreateOrderServiceFactoryImpl FACTORY = new CreateOrderServiceFactoryImpl();

    @GetMapping("/order/create")
    public CreateOrderResponse createOrder(@RequestBody CreateOrderRequest createOrderRequest) {
        return FACTORY.getSingleton().execute(createOrderRequest);
    }

}
