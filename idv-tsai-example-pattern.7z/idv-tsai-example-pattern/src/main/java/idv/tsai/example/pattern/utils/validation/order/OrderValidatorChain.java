package idv.tsai.example.pattern.utils.validation.order;

import idv.tsai.example.pattern.service.order.OrderRequest;
import idv.tsai.example.pattern.utils.validation.MyValidatorChain;

public interface OrderValidatorChain<REQUEST extends OrderRequest, VALIDATOR extends OrderValidator<REQUEST, VALIDATOR, CHAIN>, CHAIN extends OrderValidatorChain<REQUEST, VALIDATOR, CHAIN>> 
extends MyValidatorChain<REQUEST, VALIDATOR, CHAIN> {

}
