package idv.tsai.example.pattern.service.product.create.dao;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import idv.tsai.example.pattern.service.product.create.CreateProductRequest;

class CreateProductDao_API implements CreateProductDao {

    private static final Logger LOGGER = LoggerFactory.getLogger(CreateProductDao_API.class);

    @Override
    public void createProduct(CreateProductRequest request) {
        LOGGER.info("Creating product via API with request: {}", request);
        LOGGER.info("Product created successfully via API");
    }

}
