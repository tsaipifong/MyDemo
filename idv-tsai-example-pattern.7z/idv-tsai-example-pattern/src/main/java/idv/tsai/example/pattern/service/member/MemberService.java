package idv.tsai.example.pattern.service.member;

import idv.tsai.example.pattern.service.MyService;

public interface MemberService<REQUEST extends MemberRequest, RESPONSE extends MemberResponse> 
extends MyService<REQUEST, RESPONSE> {

}
