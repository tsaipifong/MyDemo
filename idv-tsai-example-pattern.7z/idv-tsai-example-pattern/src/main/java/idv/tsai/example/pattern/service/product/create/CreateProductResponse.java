package idv.tsai.example.pattern.service.product.create;

import idv.tsai.example.pattern.service.product.ProductResponse;

public class CreateProductResponse extends ProductResponse {

}
