package idv.tsai.example.pattern.service.order.create;

import idv.tsai.example.pattern.service.order.OrderRequest;

public class CreateOrderRequest extends OrderRequest {


}
