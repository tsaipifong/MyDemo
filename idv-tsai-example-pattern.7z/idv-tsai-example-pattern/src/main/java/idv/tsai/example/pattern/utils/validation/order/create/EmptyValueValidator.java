package idv.tsai.example.pattern.utils.validation.order.create;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import idv.tsai.example.pattern.service.order.create.CreateOrderRequest;
import idv.tsai.example.pattern.utils.validation.MyValidationException;

class EmptyValueValidator implements CreateOrderValidator {

    private static final Logger LOGGER = LoggerFactory.getLogger(EmptyValueValidator.class);

    @Override
    public void doValidate(CreateOrderRequest request, CreateOrderValidatorChain chain) throws MyValidationException {
        LOGGER.debug("Validating empty values for CreateOrderRequest: {}", request);
        if(request != null){
            if(request.getOrderId() != null && request.getOrderId().isEmpty()) {
                chain.addException(new MyValidationException("Order ID cannot be empty"));
            }
            if(request.getMemberId() != null && request.getMemberId().isEmpty()) {
                chain.addException(new MyValidationException("Member ID cannot be empty"));
            }
        }
        chain.doValidate(request);
    }

}
