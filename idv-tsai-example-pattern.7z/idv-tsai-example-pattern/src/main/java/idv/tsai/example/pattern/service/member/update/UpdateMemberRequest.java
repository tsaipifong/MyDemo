package idv.tsai.example.pattern.service.member.update;

import idv.tsai.example.pattern.service.member.MemberRequest;

public class UpdateMemberRequest extends MemberRequest {

}
