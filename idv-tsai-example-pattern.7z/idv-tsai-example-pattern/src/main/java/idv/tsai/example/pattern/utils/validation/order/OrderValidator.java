package idv.tsai.example.pattern.utils.validation.order;

import idv.tsai.example.pattern.service.order.OrderRequest;
import idv.tsai.example.pattern.utils.validation.MyValidator;

public interface OrderValidator<REQUEST extends OrderRequest, VALIDATOR extends OrderValidator<REQUEST, VALIDATOR, CHAIN>, CHAIN extends OrderValidatorChain<REQUEST, VALIDATOR, CHAIN>> 
extends MyValidator<REQUEST, VALIDATOR, CHAIN> {

}
