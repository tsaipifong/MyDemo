package idv.tsai.example.pattern.service.product.create.dao;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import idv.tsai.example.pattern.service.product.create.CreateProductRequest;

class CreateProductDao_DB implements CreateProductDao {

    private static final Logger LOGGER = LoggerFactory.getLogger(CreateProductDao_DB.class);

    @Override
    public void createProduct(CreateProductRequest request) {
        LOGGER.info("Creating product in DB with request: {}", request);
        LOGGER.info("Product created successfully in DB");
    }

}
