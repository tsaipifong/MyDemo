package idv.tsai.example.pattern.service.order.create;

import idv.tsai.example.pattern.service.order.OrderServiceFactory;


/**
 * 工廠方法模式
 */
public interface CreateOrderServiceFactory extends OrderServiceFactory<CreateOrderRequest, CreateOrderResponse, CreateOrderService<CreateOrderRequest, CreateOrderResponse>> {

    @Override
    CreateOrderService<CreateOrderRequest, CreateOrderResponse> getSingleton();

}
