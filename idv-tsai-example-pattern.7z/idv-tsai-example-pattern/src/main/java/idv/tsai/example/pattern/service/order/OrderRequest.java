package idv.tsai.example.pattern.service.order;

import idv.tsai.example.pattern.service.MyServiceRequest;

public class OrderRequest extends MyServiceRequest {

    private String orderId;
    private String memberId;

    public String getOrderId() {
        return orderId;
    }
    
    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

}
