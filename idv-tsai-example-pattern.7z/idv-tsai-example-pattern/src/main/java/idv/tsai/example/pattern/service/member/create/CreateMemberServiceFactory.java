package idv.tsai.example.pattern.service.member.create;

import idv.tsai.example.pattern.service.member.MemberServiceFactory;

/**
 *  工廠方法模式：繼承工廠介面
 */
public class CreateMemberServiceFactory implements MemberServiceFactory<CreateMemberService<CreateMemberRequest, CreateMemberResponse>> {
    
    @Override
    public CreateMemberService<CreateMemberRequest, CreateMemberResponse> getSingleton() {
        return CreateMemberServiceImpl.getSingleton();
    }

}
