package idv.tsai.example.pattern.service.product.create;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import idv.tsai.example.pattern.service.product.create.dao.CreateProductDao;

class CreateProductServiceImpl_OneP implements CreateProductService<CreateProductRequest, CreateProductResponse> {

    private static final Logger LOGGER = LoggerFactory.getLogger(CreateProductServiceImpl_OneP.class);

    private CreateProductDao createProductDao;

    public CreateProductServiceImpl_OneP(CreateProductDao createProductDao) {
        this.createProductDao = createProductDao;
    }

    @Override
    public CreateProductResponse execute(CreateProductRequest request) {

        LOGGER.info("Executing create product with request: {}", request);

        LOGGER.info("Create product business logic of 1P");
        
        createProductDao.createProduct(request);
        CreateProductResponse response = new CreateProductResponse();
        response.setSuccess(true);
        LOGGER.info("Create product response: {}", response);
        return response;
        
    }

}
