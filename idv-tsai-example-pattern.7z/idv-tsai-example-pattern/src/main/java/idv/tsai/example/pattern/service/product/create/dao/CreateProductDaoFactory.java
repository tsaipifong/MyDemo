package idv.tsai.example.pattern.service.product.create.dao;

/**
 * 簡單工廠
 */
public class CreateProductDaoFactory {

    private static final class InstanceHolder_DB {
        private static final CreateProductDao_DB INSTANCE = new CreateProductDao_DB();
    }

    private static final class InstanceHolder_API {
        private static final CreateProductDao_API INSTANCE = new CreateProductDao_API();
    }

    public enum DaoType {
        DB, API
    }

    public static CreateProductDao getInstance(DaoType daoType) {
        switch (daoType) {
            case DB:
                return InstanceHolder_DB.INSTANCE;
            case API:
                return InstanceHolder_API.INSTANCE;
            default:
                throw new IllegalArgumentException("Unknown DaoType: " + daoType);
        }
    }

}
