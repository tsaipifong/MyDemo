package idv.tsai.example.pattern.service.member.update;

import idv.tsai.example.pattern.service.member.MemberService;

/**
 * 單一職責原則：每個類別應該只有一個職責。
 */
public interface UpdateMemberService<REQUEST extends UpdateMemberRequest, RESPONSE extends UpdateMemberResponse> 
extends MemberService<REQUEST, RESPONSE> {

    @Override
    RESPONSE execute(REQUEST request);

}