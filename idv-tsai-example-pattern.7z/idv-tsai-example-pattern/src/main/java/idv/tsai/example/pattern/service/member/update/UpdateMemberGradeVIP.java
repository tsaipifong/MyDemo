package idv.tsai.example.pattern.service.member.update;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * 開閉原則：對擴展開放，對修改關閉。
 */
class UpdateMemberGradeVIP implements UpdateMemberService<UpdateMemberGradeRequest, UpdateMemberGradeResponse> {

    private static final Logger LOGGER = LoggerFactory.getLogger(UpdateMemberGradeVIP.class);

    @Override
    public UpdateMemberGradeResponse execute(UpdateMemberGradeRequest updateMemberGradeRequest) {

        LOGGER.info("Updating member grade to VIP: {}", updateMemberGradeRequest.toString());

        UpdateMemberGradeResponse response = new UpdateMemberGradeResponse();

        LOGGER.info("Member grade updated to VIP successfully.");

        return response;

    }

}
