package idv.tsai.example.pattern.service.member;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import idv.tsai.example.pattern.service.member.create.CreateMemberRequest;
import idv.tsai.example.pattern.service.member.create.CreateMemberResponse;
import idv.tsai.example.pattern.service.member.create.CreateMemberService;
import idv.tsai.example.pattern.service.member.create.CreateMemberServiceFactory;
import idv.tsai.example.pattern.service.member.update.UpdateMemberGradeRequest;
import idv.tsai.example.pattern.service.member.update.UpdateMemberRequest;
import idv.tsai.example.pattern.service.member.update.UpdateMemberServiceFactory;

/**
 * 簡單工廠模式
 * 由於提供一個靜態方法來創建實例，因此不需要介面或抽象類別
 */
public class MemberServiceSimpleFactory {

    private static final Logger LOGGER = LoggerFactory.getLogger(MemberServiceSimpleFactory.class);

    private static final class CreateMemberServiceInstanceHolder {
        private static final CreateMemberService<CreateMemberRequest, CreateMemberResponse> INSTANCE = new CreateMemberServiceFactory().getSingleton();
    }

    private MemberServiceSimpleFactory() {
        // Private constructor to prevent instantiation
    }

    /**
     * 運用策略模式的簡單工廠
     */
    public static MemberService<? extends MemberRequest, ? extends MemberResponse> getSingleton(MemberRequest memberRequest) {
        LOGGER.info("memberRequest: {}", memberRequest);
        MemberService<? extends MemberRequest, ? extends MemberResponse> memberService = switch (memberRequest) {

            // UpdateMemberGradeRequest 是 UpdateMemberRequest 的子類別，所以要先判斷
            case UpdateMemberGradeRequest updateMemberGradeRequest -> UpdateMemberServiceFactory.getSingleton(updateMemberGradeRequest.getMemberGrade());
            
            case CreateMemberRequest createMemberRequest -> CreateMemberServiceInstanceHolder.INSTANCE;
            
            case UpdateMemberRequest updateMemberRequest -> UpdateMemberServiceFactory.getSingleton();
            
            default -> throw new IllegalArgumentException("Unsupported member request type: " + memberRequest.getClass().getName());
        };
        return memberService;
    }

    
}
