package idv.tsai.example.pattern.service.product;

import idv.tsai.example.pattern.service.MyServiceResponse;

public class ProductResponse extends MyServiceResponse {


}
