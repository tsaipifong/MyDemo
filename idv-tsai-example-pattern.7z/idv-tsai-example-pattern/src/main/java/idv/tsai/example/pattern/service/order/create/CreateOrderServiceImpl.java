package idv.tsai.example.pattern.service.order.create;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

class CreateOrderServiceImpl extends AbstractCreateOrderServiceTemplateMethod {

    private static final Logger LOGGER = LoggerFactory.getLogger(CreateOrderServiceImpl.class);

    @Override
    protected void preProcess(CreateOrderRequest request) {
        // Implement pre-processing logic here
        LOGGER.info("Pre-processing before creating order.");
    }

    @Override
    protected void createOrder(CreateOrderRequest request) {
        // Implement core logic for creating an order here
        LOGGER.info("Creating order in the core logic.");
    }

    @Override
    protected void postProcess(CreateOrderRequest request) {
        // Implement post-processing logic here
        LOGGER.info("Post-processing after creating order.");
    }

}
