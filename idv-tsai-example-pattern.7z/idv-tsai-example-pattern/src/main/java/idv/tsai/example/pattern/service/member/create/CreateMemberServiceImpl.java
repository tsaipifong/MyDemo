package idv.tsai.example.pattern.service.member.create;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 單一實例模式
 * 優點：確保只有一個實例存在、延遲實例化、線程安全
 * 缺點：無法被繼承、無法輕易測試
 */
class CreateMemberServiceImpl implements CreateMemberService<CreateMemberRequest, CreateMemberResponse> {

    private static final Logger LOGGER = LoggerFactory.getLogger(CreateMemberServiceImpl.class);

    private static final class InstanceHolder {
        private static final CreateMemberServiceImpl INSTANCE = new CreateMemberServiceImpl();
    }

    private CreateMemberServiceImpl() {
        // 私有建構子，防止外部實例化
    }

    public static CreateMemberService<CreateMemberRequest, CreateMemberResponse> getSingleton() {
        return InstanceHolder.INSTANCE;
    }

    @Override
    public CreateMemberResponse execute(CreateMemberRequest createMemberRequest) {

        LOGGER.info("Executing create member request: {}", createMemberRequest.toString());

        CreateMemberResponse response = new CreateMemberResponse();

        LOGGER.info("Create member executed successfully: {}", response.toString());

        return response;
    }

}
