package idv.tsai.example.pattern.idv_tsai_example_pattern;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IdvTsaiExamplePatternApplicationTests {

	@Test
	void contextLoads() {
	}

}
