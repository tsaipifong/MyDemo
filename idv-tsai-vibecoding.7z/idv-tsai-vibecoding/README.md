# Spring Quartz 排程管理系統

## 專案概述

本專案是一個基於 **Spring Boot** 和 **Quartz Scheduler** 的排程管理系統，展示了 **Vibe Coding** 的 AI 輔助開發環境。系統整合了 GitHub Copilot + MCP Tools，實現了現代化的 AI 協作開發流程。

專案實現了一個每分鐘執行一次的時間日誌排程任務，輸出 24 小時制的時間格式：`Current time: 2024-01-01 12:00:00`。

## 技術架構

### 核心技術棧
- **Spring Boot**: 3.5.5
- **Java**: 21
- **Quartz Scheduler**: 2.5.0
- **H2 Database**: 檔案型資料庫持久化
- **Maven**: 專案建置管理
- **JUnit 5 + Mockito**: 單元測試框架

### 設計原則
- **SOLID 原則**: 嚴格遵循單一職責、開放封閉、里氏替換、介面隔離、依賴反轉原則
- **封裝可見性**: public 類別限制，優先使用 package-private
- **介面導向設計**: 服務層採用介面 + 實作模式
- **依賴注入**: 建構子注入模式，final 變數宣告

## 專案目錄結構

```
├── .github/
│   ├── copilot-instructions.md          # AI 代理指令檔案
│   └── instructions/
│       └── java.instructions.md         # Java 程式碼標準
├── src/
│   ├── main/
│   │   ├── java/idv/tsai/vibecoding/
│   │   │   ├── IdvTsaiVibecodingApplication.java     # 主程式入口
│   │   │   ├── config/                               # 配置類別
│   │   │   │   ├── QuartzConfig.java                 # Quartz 排程器配置
│   │   │   │   └── AutoWiringSpringBeanJobFactory.java  # Spring Bean 工廠
│   │   │   ├── controller/                           # REST API 控制器
│   │   │   │   └── ScheduleController.java           # 排程管理控制器
│   │   │   └── service/                              # 服務層
│   │   │       └── schedule/                         # 排程模組
│   │   │           ├── ScheduleService.java          # 排程服務介面
│   │   │           ├── ScheduleServiceImpl.java      # 排程服務實作 (package-private)
│   │   │           ├── TimeLogJob.java               # 時間日誌任務 (package-private)
│   │   │           └── ScheduleInitializer.java      # 排程初始化器
│   │   └── resources/
│   │       └── application.properties                # 應用程式配置
│   └── test/
│       └── java/idv/tsai/vibecoding/
│           ├── IdvTsaiVibecodingApplicationTests.java  # 應用程式測試
│           ├── controller/
│           │   └── ScheduleControllerTest.java        # 控制器測試
│           └── service/schedule/
│               ├── ScheduleServiceTest.java           # 服務層單元測試
│               ├── ScheduleServiceIntegrationTest.java # 整合測試
│               └── TimeLogJobTest.java                # 任務測試
├── data/                                              # H2 資料庫檔案
├── logs/                                              # 應用程式日誌
├── pom.xml                                            # Maven 專案配置
└── README.md                                          # 本檔案
```

## 核心功能

### 1. 排程管理服務 (ScheduleService)
- **啟動時間日誌任務**: `startTimeLogJob()`
- **停止時間日誌任務**: `stopTimeLogJob()`
- **檢查任務狀態**: `isTimeLogJobRunning()`
- **立即執行任務**: `executeTimeLogJobNow()`

### 2. 時間日誌任務 (TimeLogJob)
- 每分鐘執行一次 (Cron: `0 * * * * ?`)
- 輸出格式: `Current time: 2025-09-18 13:45:00`
- 使用 24 小時制時間格式
- 支援 Spring 依賴注入

### 3. REST API 控制器
- `POST /api/schedule/time-log/start` - 啟動時間日誌任務
- `POST /api/schedule/time-log/stop` - 停止時間日誌任務
- `GET /api/schedule/time-log/status` - 檢查任務狀態
- `POST /api/schedule/time-log/execute` - 立即執行任務
- `GET /api/schedule/info` - 獲取排程器資訊

### 4. 自動初始化
- 應用程式啟動時自動初始化排程任務
- 確保時間日誌任務在系統啟動後立即開始運行

## 建置與執行

### 系統需求
- Java 21 或以上版本
- Maven 3.8 或以上版本

### 建置指令
```bash
# 編譯專案
./mvnw clean compile

# 執行測試
./mvnw test

# 啟動應用程式
./mvnw spring-boot:run
```

### 執行結果
應用程式啟動後：
1. Tomcat 伺服器運行在 `http://localhost:8080`
2. H2 資料庫控制台可在 `http://localhost:8080/h2-console` 訪問
3. 時間日誌任務自動啟動，每分鐘輸出當前時間

## 測試覆蓋率

### 測試統計
- **總測試數量**: 39 個測試
- **測試結果**: 全部通過 (0 失敗, 0 錯誤)
- **介面覆蓋率**: 100% (所有 public interface 方法都有測試)
- **業務邏輯覆蓋率**: 90% 以上

### 測試分類
- **ScheduleControllerTest**: 13 個測試 - REST API 控制器測試
- **ScheduleServiceTest**: 15 個測試 - 服務層單元測試  
- **ScheduleServiceIntegrationTest**: 4 個測試 - 整合測試
- **TimeLogJobTest**: 6 個測試 - 任務執行測試
- **IdvTsaiVibecodingApplicationTests**: 1 個測試 - 應用程式啟動測試

## 配置說明

### application.properties 主要配置
```properties
# Quartz 排程器配置
spring.quartz.job-store-type=memory
spring.quartz.properties.org.quartz.scheduler.instanceName=QuartzScheduler
spring.quartz.properties.org.quartz.threadPool.threadCount=10

# H2 資料庫配置
spring.datasource.url=jdbc:h2:file:./data/quartz_db
spring.datasource.driver-class-name=org.h2.Driver
spring.h2.console.enabled=true

# 日誌配置
logging.level.idv.tsai.vibecoding=DEBUG
```

## Vibe Coding 特色

### AI 輔助開發
- **GitHub Copilot**: 程式碼自動建議和生成
- **MCP 工具整合**: 外部工具和服務的無縫整合
- **結構化提示**: 使用 `.prompt.md` 檔案定義 AI 任務

### 程式碼品質保證
- **SOLID 原則遵循**: 確保程式碼可維護性和擴展性
- **完整測試覆蓋**: 單元測試 + 整合測試 + 端到端測試
- **自動化建置**: Maven 自動化編譯、測試、部署流程

### 開發體驗優化
- **即時反饋**: AI 實時程式碼建議和錯誤檢測
- **文檔驅動**: 詳細的繁體中文註解和文檔
- **模組化設計**: 清晰的分層架構和職責分離

## 日誌輸出範例

```
2025-09-18T13:46:00.000+08:00  INFO 10924 --- [QuartzScheduler_Worker-1] i.t.v.service.schedule.TimeLogJob : Current time: 2025-09-18 13:46:00
2025-09-18T13:47:00.000+08:00  INFO 10924 --- [QuartzScheduler_Worker-1] i.t.v.service.schedule.TimeLogJob : Current time: 2025-09-18 13:47:00
2025-09-18T13:48:00.000+08:00  INFO 10924 --- [QuartzScheduler_Worker-1] i.t.v.service.schedule.TimeLogJob : Current time: 2025-09-18 13:48:00
```

## 專案意義

這個專案展示了現代化的 AI 輔助開發流程，整合了最新的開發工具和最佳實踐，是 **Vibe Coding** 理念的完美體現：
- 直覺式的自然語言需求表達
- AI 智能化的程式碼生成和優化
- 高品質的程式碼標準和測試覆蓋
- 完整的專案文檔和部署流程

透過這個專案，開發者可以體驗到 AI 輔助開發如何大幅提升開發效率和程式碼品質。