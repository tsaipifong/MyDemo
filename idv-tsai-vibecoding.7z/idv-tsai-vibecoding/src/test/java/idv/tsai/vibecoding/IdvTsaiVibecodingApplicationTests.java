package idv.tsai.vibecoding;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * Spring Boot 應用程式測試類別
 * 用於驗證應用程式上下文是否能正常載入
 */
@SpringBootTest
class IdvTsaiVibecodingApplicationTests {

	/**
	 * 測試應用程式上下文載入
	 * 確保 Spring Boot 應用程式能夠正常啟動
	 */
	@Test
	void contextLoads() {
		// 此測試方法驗證 Spring 應用程式上下文能夠成功載入
		// 如果上下文載入失敗，測試會拋出異常
	}

}