package idv.tsai.vibecoding.service.schedule;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;

import static org.awaitility.Awaitility.await;
import static org.junit.jupiter.api.Assertions.*;

import java.time.Duration;

/**
 * 排程服務整合測試
 * 
 * 使用 @SpringBootTest 進行完整的應用程式上下文整合測試，
 * 驗證排程服務在真實環境中的運作情況。
 */
@SpringBootTest
@TestPropertySource(properties = {
    "spring.quartz.job-store-type=memory",
    "spring.quartz.scheduler.startup-delay=1s",
    "logging.level.idv.tsai.vibecoding=DEBUG"
})
class ScheduleServiceIntegrationTest {

    /**
     * 排程服務實例
     */
    @Autowired
    private ScheduleService scheduleService;

    /**
     * 測試排程服務基本功能的整合測試
     */
    @Test
    void testScheduleServiceIntegration() throws Exception {
        // 初始狀態：任務應該不在運行（或從初始化器啟動的任務）
        // 先停止任何現有的任務，確保測試環境乾淨
        try {
            scheduleService.stopTimeLogJob();
        } catch (Exception e) {
            // 忽略停止不存在任務的錯誤
        }

        // 等待一下確保任務完全停止
        await().atMost(Duration.ofSeconds(3))
                .until(() -> !scheduleService.isTimeLogJobRunning());

        // 測試啟動任務
        scheduleService.startTimeLogJob();
        
        // 驗證任務已啟動
        assertTrue(scheduleService.isTimeLogJobRunning(), "任務應該正在運行");

        // 測試立即執行任務
        assertDoesNotThrow(() -> scheduleService.executeTimeLogJobNow(),
                "立即執行任務不應該拋出異常");

        // 測試停止任務
        scheduleService.stopTimeLogJob();
        
        // 驗證任務已停止
        assertFalse(scheduleService.isTimeLogJobRunning(), "任務應該已停止");

        // 測試重新啟動任務
        scheduleService.startTimeLogJob();
        assertTrue(scheduleService.isTimeLogJobRunning(), "任務應該重新啟動成功");

        // 清理：停止任務
        scheduleService.stopTimeLogJob();
    }

    /**
     * 測試任務重複啟動的行為
     */
    @Test
    void testMultipleStartStop() throws Exception {
        // 清理環境
        try {
            scheduleService.stopTimeLogJob();
        } catch (Exception e) {
            // 忽略
        }

        // 測試多次啟動和停止
        for (int i = 0; i < 3; i++) {
            // 啟動任務
            scheduleService.startTimeLogJob();
            assertTrue(scheduleService.isTimeLogJobRunning(), 
                    "第" + (i + 1) + "次啟動失敗");

            // 重複啟動應該不會出錯
            assertDoesNotThrow(() -> scheduleService.startTimeLogJob(),
                    "重複啟動不應該拋出異常");

            // 停止任務
            scheduleService.stopTimeLogJob();
            assertFalse(scheduleService.isTimeLogJobRunning(), 
                    "第" + (i + 1) + "次停止失敗");
        }
    }

    /**
     * 測試在任務不存在時執行立即執行的錯誤處理
     */
    @Test
    void testExecuteNonExistentJob() throws Exception {
        // 確保任務不存在
        try {
            scheduleService.stopTimeLogJob();
        } catch (Exception e) {
            // 忽略
        }

        // 等待確保任務完全停止
        await().atMost(Duration.ofSeconds(3))
                .until(() -> !scheduleService.isTimeLogJobRunning());

        // 嘗試執行不存在的任務應該拋出異常
        assertThrows(IllegalStateException.class, 
                () -> scheduleService.executeTimeLogJobNow(),
                "執行不存在的任務應該拋出 IllegalStateException");
    }

    /**
     * 測試任務狀態檢查的準確性
     */
    @Test
    void testJobStatusAccuracy() throws Exception {
        // 清理環境
        try {
            scheduleService.stopTimeLogJob();
        } catch (Exception e) {
            // 忽略
        }

        // 初始狀態：任務不在運行
        await().atMost(Duration.ofSeconds(3))
                .until(() -> !scheduleService.isTimeLogJobRunning());

        // 啟動任務並立即檢查狀態
        scheduleService.startTimeLogJob();
        
        // 等待任務確實啟動
        await().atMost(Duration.ofSeconds(5))
                .until(() -> scheduleService.isTimeLogJobRunning());

        // 停止任務並檢查狀態
        scheduleService.stopTimeLogJob();
        
        // 等待任務確實停止
        await().atMost(Duration.ofSeconds(3))
                .until(() -> !scheduleService.isTimeLogJobRunning());
    }
}