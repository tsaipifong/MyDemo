package idv.tsai.vibecoding.service.schedule;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

/**
 * TimeLogJob 類別的單元測試
 * 
 * 測試時間日誌任務的執行邏輯，確保任務能正確執行並處理異常情況。
 */
@ExtendWith(MockitoExtension.class)
class TimeLogJobTest {

    /**
     * 模擬的任務執行上下文
     */
    @Mock
    private JobExecutionContext jobExecutionContext;

    /**
     * 被測試的時間日誌任務實例
     */
    private TimeLogJob timeLogJob;

    /**
     * 測試前的初始化設定
     */
    @BeforeEach
    void setUp() {
        timeLogJob = new TimeLogJob();
    }

    /**
     * 測試任務執行 - 正常情況
     */
    @Test
    void testExecute_Success() throws JobExecutionException {
        // Given
        Date nextFireTime = new Date(System.currentTimeMillis() + 60000); // 下次執行時間：1分鐘後
        when(jobExecutionContext.getNextFireTime()).thenReturn(nextFireTime);

        // When & Then - 不應該拋出異常
        assertDoesNotThrow(() -> timeLogJob.execute(jobExecutionContext));
        
        // 驗證上下文被正確使用
        verify(jobExecutionContext).getNextFireTime();
    }

    /**
     * 測試任務執行 - 空的下次執行時間
     */
    @Test
    void testExecute_NullNextFireTime() throws JobExecutionException {
        // Given
        when(jobExecutionContext.getNextFireTime()).thenReturn(null);

        // When & Then - 不應該拋出異常，任務應該能正常處理 null 值
        assertDoesNotThrow(() -> timeLogJob.execute(jobExecutionContext));
        
        // 驗證上下文被正確使用
        verify(jobExecutionContext).getNextFireTime();
    }

    /**
     * 測試任務執行 - 上下文為 null 的邊界情況
     */
    @Test
    void testExecute_NullContext() {
        // When & Then - 應該拋出 NullPointerException
        assertThrows(JobExecutionException.class, () -> timeLogJob.execute(null));
    }

    /**
     * 測試任務執行的時間格式化
     * 
     * 雖然我們無法直接測試日誌輸出，但可以確保方法執行完成而不拋出異常
     */
    @Test
    void testExecute_TimeFormatting() throws JobExecutionException {
        // Given
        Date nextFireTime = new Date();
        when(jobExecutionContext.getNextFireTime()).thenReturn(nextFireTime);

        // When
        long startTime = System.currentTimeMillis();
        timeLogJob.execute(jobExecutionContext);
        long endTime = System.currentTimeMillis();

        // Then
        // 任務執行應該很快完成（小於1秒）
        assertTrue(endTime - startTime < 1000, "任務執行時間應該很短");
        
        // 驗證上下文被正確調用
        verify(jobExecutionContext).getNextFireTime();
    }

    /**
     * 測試任務執行的重複呼叫
     * 
     * 確保任務可以被重複執行而不出現問題
     */
    @Test
    void testExecute_MultipleInvocations() throws JobExecutionException {
        // Given
        Date nextFireTime = new Date();
        when(jobExecutionContext.getNextFireTime()).thenReturn(nextFireTime);

        // When & Then - 多次執行不應該有問題
        assertDoesNotThrow(() -> {
            timeLogJob.execute(jobExecutionContext);
            timeLogJob.execute(jobExecutionContext);
            timeLogJob.execute(jobExecutionContext);
        });

        // 驗證上下文被調用了3次
        verify(jobExecutionContext, times(3)).getNextFireTime();
    }

    /**
     * 測試任務執行的執行緒安全性
     * 
     * 確保任務在並發執行時不會出現問題
     */
    @Test
    void testExecute_ThreadSafety() throws InterruptedException {
        // Given
        Date nextFireTime = new Date();
        when(jobExecutionContext.getNextFireTime()).thenReturn(nextFireTime);

        // When - 並發執行任務
        Thread[] threads = new Thread[5];
        for (int i = 0; i < threads.length; i++) {
            threads[i] = new Thread(() -> {
                try {
                    timeLogJob.execute(jobExecutionContext);
                } catch (JobExecutionException e) {
                    fail("並發執行時不應該拋出異常: " + e.getMessage());
                }
            });
        }

        // 啟動所有執行緒
        for (Thread thread : threads) {
            thread.start();
        }

        // 等待所有執行緒完成
        for (Thread thread : threads) {
            thread.join();
        }

        // Then - 所有執行緒都應該成功執行
        verify(jobExecutionContext, times(5)).getNextFireTime();
    }
}