package idv.tsai.vibecoding.service.schedule;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.quartz.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/**
 * ScheduleService 介面的單元測試類別
 * 
 * 測試排程服務的所有公開方法，確保介面方法 100% 覆蓋率。
 * 包含正常情況、邊界值、異常情況、空值和業務規則測試。
 */
@ExtendWith(MockitoExtension.class)
class ScheduleServiceTest {

    /**
     * 模擬的 Quartz 排程器
     */
    @Mock
    private Scheduler scheduler;

    /**
     * 被測試的排程服務實例
     */
    private ScheduleService scheduleService;

    /**
     * 時間日誌任務的任務鍵值
     */
    private static final JobKey TIME_LOG_JOB_KEY = JobKey.jobKey("timeLogJob", "DEFAULT");

    /**
     * 時間日誌任務的觸發器鍵值
     */
    private static final TriggerKey TIME_LOG_TRIGGER_KEY = TriggerKey.triggerKey("timeLogTrigger", "DEFAULT");

    /**
     * 測試前的初始化設定
     */
    @BeforeEach
    void setUp() {
        scheduleService = new ScheduleServiceImpl(scheduler);
    }

    /**
     * 測試啟動時間日誌任務 - 正常情況
     */
    @Test
    void testStartTimeLogJob_Success() throws Exception {
        // Given
        when(scheduler.checkExists(TIME_LOG_JOB_KEY)).thenReturn(false);

        // When
        scheduleService.startTimeLogJob();

        // Then
        verify(scheduler).checkExists(TIME_LOG_JOB_KEY);
        verify(scheduler).scheduleJob(any(JobDetail.class), any(Trigger.class));
        verify(scheduler, never()).deleteJob(any(JobKey.class));
    }

    /**
     * 測試啟動時間日誌任務 - 任務已存在的情況
     */
    @Test
    void testStartTimeLogJob_JobAlreadyExists() throws Exception {
        // Given
        when(scheduler.checkExists(TIME_LOG_JOB_KEY)).thenReturn(true);
        when(scheduler.deleteJob(TIME_LOG_JOB_KEY)).thenReturn(true);

        // When
        scheduleService.startTimeLogJob();

        // Then
        verify(scheduler).checkExists(TIME_LOG_JOB_KEY);
        verify(scheduler).deleteJob(TIME_LOG_JOB_KEY);
        verify(scheduler).scheduleJob(any(JobDetail.class), any(Trigger.class));
    }

    /**
     * 測試啟動時間日誌任務 - 排程器異常情況
     */
    @Test
    void testStartTimeLogJob_SchedulerException() throws Exception {
        // Given
        when(scheduler.checkExists(TIME_LOG_JOB_KEY)).thenThrow(new SchedulerException("Scheduler error"));

        // When & Then
        assertThrows(SchedulerException.class, () -> scheduleService.startTimeLogJob());
        verify(scheduler).checkExists(TIME_LOG_JOB_KEY);
        verify(scheduler, never()).scheduleJob(any(JobDetail.class), any(Trigger.class));
    }

    /**
     * 測試停止時間日誌任務 - 正常情況
     */
    @Test
    void testStopTimeLogJob_Success() throws Exception {
        // Given
        when(scheduler.checkExists(TIME_LOG_JOB_KEY)).thenReturn(true);
        when(scheduler.deleteJob(TIME_LOG_JOB_KEY)).thenReturn(true);

        // When
        scheduleService.stopTimeLogJob();

        // Then
        verify(scheduler).checkExists(TIME_LOG_JOB_KEY);
        verify(scheduler).deleteJob(TIME_LOG_JOB_KEY);
    }

    /**
     * 測試停止時間日誌任務 - 任務不存在的情況
     */
    @Test
    void testStopTimeLogJob_JobNotExists() throws Exception {
        // Given
        when(scheduler.checkExists(TIME_LOG_JOB_KEY)).thenReturn(false);

        // When
        scheduleService.stopTimeLogJob();

        // Then
        verify(scheduler).checkExists(TIME_LOG_JOB_KEY);
        verify(scheduler, never()).deleteJob(any(JobKey.class));
    }

    /**
     * 測試停止時間日誌任務 - 刪除失敗的情況
     */
    @Test
    void testStopTimeLogJob_DeleteFailed() throws Exception {
        // Given
        when(scheduler.checkExists(TIME_LOG_JOB_KEY)).thenReturn(true);
        when(scheduler.deleteJob(TIME_LOG_JOB_KEY)).thenReturn(false);

        // When & Then
        RuntimeException exception = assertThrows(RuntimeException.class, () -> scheduleService.stopTimeLogJob());
        assertEquals("無法停止時間日誌排程任務", exception.getMessage());
        verify(scheduler).checkExists(TIME_LOG_JOB_KEY);
        verify(scheduler).deleteJob(TIME_LOG_JOB_KEY);
    }

    /**
     * 測試停止時間日誌任務 - 排程器異常情況
     */
    @Test
    void testStopTimeLogJob_SchedulerException() throws Exception {
        // Given
        when(scheduler.checkExists(TIME_LOG_JOB_KEY)).thenThrow(new SchedulerException("Scheduler error"));

        // When & Then
        assertThrows(SchedulerException.class, () -> scheduleService.stopTimeLogJob());
        verify(scheduler).checkExists(TIME_LOG_JOB_KEY);
        verify(scheduler, never()).deleteJob(any(JobKey.class));
    }

    /**
     * 測試檢查任務運行狀態 - 任務正在運行
     */
    @Test
    void testIsTimeLogJobRunning_JobRunning() throws Exception {
        // Given
        when(scheduler.checkExists(TIME_LOG_JOB_KEY)).thenReturn(true);
        when(scheduler.getTriggerState(TIME_LOG_TRIGGER_KEY)).thenReturn(Trigger.TriggerState.NORMAL);

        // When
        boolean result = scheduleService.isTimeLogJobRunning();

        // Then
        assertTrue(result);
        verify(scheduler).checkExists(TIME_LOG_JOB_KEY);
        verify(scheduler).getTriggerState(TIME_LOG_TRIGGER_KEY);
    }

    /**
     * 測試檢查任務運行狀態 - 任務不存在
     */
    @Test
    void testIsTimeLogJobRunning_JobNotExists() throws Exception {
        // Given
        when(scheduler.checkExists(TIME_LOG_JOB_KEY)).thenReturn(false);

        // When
        boolean result = scheduleService.isTimeLogJobRunning();

        // Then
        assertFalse(result);
        verify(scheduler).checkExists(TIME_LOG_JOB_KEY);
        verify(scheduler, never()).getTriggerState(any(TriggerKey.class));
    }

    /**
     * 測試檢查任務運行狀態 - 觸發器處於暫停狀態
     */
    @Test
    void testIsTimeLogJobRunning_TriggerPaused() throws Exception {
        // Given
        when(scheduler.checkExists(TIME_LOG_JOB_KEY)).thenReturn(true);
        when(scheduler.getTriggerState(TIME_LOG_TRIGGER_KEY)).thenReturn(Trigger.TriggerState.PAUSED);

        // When
        boolean result = scheduleService.isTimeLogJobRunning();

        // Then
        assertFalse(result);
        verify(scheduler).checkExists(TIME_LOG_JOB_KEY);
        verify(scheduler).getTriggerState(TIME_LOG_TRIGGER_KEY);
    }

    /**
     * 測試檢查任務運行狀態 - 排程器異常情況
     */
    @Test
    void testIsTimeLogJobRunning_SchedulerException() throws Exception {
        // Given
        when(scheduler.checkExists(TIME_LOG_JOB_KEY)).thenThrow(new SchedulerException("Scheduler error"));

        // When & Then
        assertThrows(SchedulerException.class, () -> scheduleService.isTimeLogJobRunning());
        verify(scheduler).checkExists(TIME_LOG_JOB_KEY);
        verify(scheduler, never()).getTriggerState(any(TriggerKey.class));
    }

    /**
     * 測試立即執行任務 - 正常情況
     */
    @Test
    void testExecuteTimeLogJobNow_Success() throws Exception {
        // Given
        when(scheduler.checkExists(TIME_LOG_JOB_KEY)).thenReturn(true);

        // When
        scheduleService.executeTimeLogJobNow();

        // Then
        verify(scheduler).checkExists(TIME_LOG_JOB_KEY);
        verify(scheduler).triggerJob(TIME_LOG_JOB_KEY);
    }

    /**
     * 測試立即執行任務 - 任務不存在
     */
    @Test
    void testExecuteTimeLogJobNow_JobNotExists() throws Exception {
        // Given
        when(scheduler.checkExists(TIME_LOG_JOB_KEY)).thenReturn(false);

        // When & Then
        IllegalStateException exception = assertThrows(IllegalStateException.class, 
                () -> scheduleService.executeTimeLogJobNow());
        assertEquals("時間日誌任務不存在，請先啟動任務", exception.getMessage());
        verify(scheduler).checkExists(TIME_LOG_JOB_KEY);
        verify(scheduler, never()).triggerJob(any(JobKey.class));
    }

    /**
     * 測試立即執行任務 - 排程器異常情況
     */
    @Test
    void testExecuteTimeLogJobNow_SchedulerException() throws Exception {
        // Given
        when(scheduler.checkExists(TIME_LOG_JOB_KEY)).thenThrow(new SchedulerException("Scheduler error"));

        // When & Then
        assertThrows(SchedulerException.class, () -> scheduleService.executeTimeLogJobNow());
        verify(scheduler).checkExists(TIME_LOG_JOB_KEY);
        verify(scheduler, never()).triggerJob(any(JobKey.class));
    }

    /**
     * 測試觸發任務時的排程器異常
     */
    @Test
    void testExecuteTimeLogJobNow_TriggerException() throws Exception {
        // Given
        when(scheduler.checkExists(TIME_LOG_JOB_KEY)).thenReturn(true);
        doThrow(new SchedulerException("Trigger error")).when(scheduler).triggerJob(TIME_LOG_JOB_KEY);

        // When & Then
        assertThrows(SchedulerException.class, () -> scheduleService.executeTimeLogJobNow());
        verify(scheduler).checkExists(TIME_LOG_JOB_KEY);
        verify(scheduler).triggerJob(TIME_LOG_JOB_KEY);
    }
}