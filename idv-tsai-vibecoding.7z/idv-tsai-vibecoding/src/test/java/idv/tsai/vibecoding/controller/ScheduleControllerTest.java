package idv.tsai.vibecoding.controller;

import idv.tsai.vibecoding.service.schedule.ScheduleService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * ScheduleController 控制器的單元測試
 * 
 * 使用 @WebMvcTest 進行控制器層的集成測試，
 * 測試所有 REST API 端點的正常情況和異常情況。
 */
@WebMvcTest(ScheduleController.class)
class ScheduleControllerTest {

    /**
     * Spring MVC 測試工具
     */
    @Autowired
    private MockMvc mockMvc;

    /**
     * 模擬的排程服務
     */
    @MockitoBean
    private ScheduleService scheduleService;

    /**
     * 測試啟動時間日誌任務 - 成功情況
     */
    @Test
    void testStartTimeLogJob_Success() throws Exception {
        // Given
        doNothing().when(scheduleService).startTimeLogJob();

        // When & Then
        mockMvc.perform(post("/api/schedule/timelog/start")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.message").value("時間日誌排程任務啟動成功"));

        verify(scheduleService).startTimeLogJob();
    }

    /**
     * 測試啟動時間日誌任務 - 失敗情況
     */
    @Test
    void testStartTimeLogJob_Failure() throws Exception {
        // Given
        doThrow(new RuntimeException("排程器錯誤")).when(scheduleService).startTimeLogJob();

        // When & Then
        mockMvc.perform(post("/api/schedule/timelog/start")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isInternalServerError())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.message").value("時間日誌排程任務啟動失敗: 排程器錯誤"));

        verify(scheduleService).startTimeLogJob();
    }

    /**
     * 測試停止時間日誌任務 - 成功情況
     */
    @Test
    void testStopTimeLogJob_Success() throws Exception {
        // Given
        doNothing().when(scheduleService).stopTimeLogJob();

        // When & Then
        mockMvc.perform(post("/api/schedule/timelog/stop")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.message").value("時間日誌排程任務停止成功"));

        verify(scheduleService).stopTimeLogJob();
    }

    /**
     * 測試停止時間日誌任務 - 失敗情況
     */
    @Test
    void testStopTimeLogJob_Failure() throws Exception {
        // Given
        doThrow(new IllegalStateException("任務不存在")).when(scheduleService).stopTimeLogJob();

        // When & Then
        mockMvc.perform(post("/api/schedule/timelog/stop")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isInternalServerError())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.message").value("時間日誌排程任務停止失敗: 任務不存在"));

        verify(scheduleService).stopTimeLogJob();
    }

    /**
     * 測試檢查任務狀態 - 任務正在運行
     */
    @Test
    void testGetTimeLogJobStatus_Running() throws Exception {
        // Given
        when(scheduleService.isTimeLogJobRunning()).thenReturn(true);

        // When & Then
        mockMvc.perform(get("/api/schedule/timelog/status")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.running").value(true))
                .andExpect(jsonPath("$.message").value("時間日誌任務正在運行"));

        verify(scheduleService).isTimeLogJobRunning();
    }

    /**
     * 測試檢查任務狀態 - 任務未運行
     */
    @Test
    void testGetTimeLogJobStatus_NotRunning() throws Exception {
        // Given
        when(scheduleService.isTimeLogJobRunning()).thenReturn(false);

        // When & Then
        mockMvc.perform(get("/api/schedule/timelog/status")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.running").value(false))
                .andExpect(jsonPath("$.message").value("時間日誌任務未運行"));

        verify(scheduleService).isTimeLogJobRunning();
    }

    /**
     * 測試檢查任務狀態 - 異常情況
     */
    @Test
    void testGetTimeLogJobStatus_Exception() throws Exception {
        // Given
        when(scheduleService.isTimeLogJobRunning()).thenThrow(new RuntimeException("無法連接排程器"));

        // When & Then
        mockMvc.perform(get("/api/schedule/timelog/status")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isInternalServerError())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.running").value(false))
                .andExpect(jsonPath("$.message").value("檢查任務狀態失敗: 無法連接排程器"));

        verify(scheduleService).isTimeLogJobRunning();
    }

    /**
     * 測試立即執行任務 - 成功情況
     */
    @Test
    void testExecuteTimeLogJobNow_Success() throws Exception {
        // Given
        doNothing().when(scheduleService).executeTimeLogJobNow();

        // When & Then
        mockMvc.perform(post("/api/schedule/timelog/execute")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.message").value("時間日誌任務已觸發立即執行"));

        verify(scheduleService).executeTimeLogJobNow();
    }

    /**
     * 測試立即執行任務 - 失敗情況
     */
    @Test
    void testExecuteTimeLogJobNow_Failure() throws Exception {
        // Given
        doThrow(new IllegalStateException("任務不存在")).when(scheduleService).executeTimeLogJobNow();

        // When & Then
        mockMvc.perform(post("/api/schedule/timelog/execute")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isInternalServerError())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.message").value("立即執行時間日誌任務失敗: 任務不存在"));

        verify(scheduleService).executeTimeLogJobNow();
    }

    /**
     * 測試獲取排程資訊 - 成功情況
     */
    @Test
    void testGetScheduleInfo_Success() throws Exception {
        // Given
        when(scheduleService.isTimeLogJobRunning()).thenReturn(true);

        // When & Then
        mockMvc.perform(get("/api/schedule/info")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.systemName").value("Spring Quartz 排程管理系統"))
                .andExpect(jsonPath("$.version").value("1.0.0"))
                .andExpect(jsonPath("$.timeLogJobRunning").value(true))
                .andExpect(jsonPath("$.availableOperations").isArray())
                .andExpect(jsonPath("$.availableOperations").isNotEmpty());

        verify(scheduleService).isTimeLogJobRunning();
    }

    /**
     * 測試獲取排程資訊 - 異常情況
     */
    @Test
    void testGetScheduleInfo_Exception() throws Exception {
        // Given
        when(scheduleService.isTimeLogJobRunning()).thenThrow(new RuntimeException("服務不可用"));

        // When & Then
        mockMvc.perform(get("/api/schedule/info")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isInternalServerError())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.message").value("獲取排程資訊失敗: 服務不可用"));

        verify(scheduleService).isTimeLogJobRunning();
    }

    /**
     * 測試不支援的 HTTP 方法
     */
    @Test
    void testUnsupportedHttpMethod() throws Exception {
        // When & Then
        mockMvc.perform(put("/api/schedule/timelog/start")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isMethodNotAllowed());

        verifyNoInteractions(scheduleService);
    }

    /**
     * 測試不存在的端點
     */
    @Test
    void testNonExistentEndpoint() throws Exception {
        // When & Then
        mockMvc.perform(get("/api/schedule/nonexistent")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());

        verifyNoInteractions(scheduleService);
    }
}