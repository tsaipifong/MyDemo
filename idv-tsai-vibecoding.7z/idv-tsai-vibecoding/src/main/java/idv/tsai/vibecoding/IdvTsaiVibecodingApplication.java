package idv.tsai.vibecoding;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * Vibe Coding 示範專案主程式
 * 
 * 這是一個用於展示 AI 輔助開發環境建置的 Spring Boot 應用程式。
 * 整合 VS Code + GitHub Copilot + MCP Tools，實踐現代化的 AI 協作開發流程。
 * 
 * 本專案整合了 Quartz Scheduler 排程管理系統，展示 Spring Boot 與 Quartz 的完整整合。
 */
@SpringBootApplication
@EnableScheduling
public class IdvTsaiVibecodingApplication {

	/**
	 * 應用程式進入點
	 * 
	 * 啟動 Spring Boot 應用程式，包含 Quartz 排程管理系統。
	 * 
	 * @param args 命令列參數
	 */
	public static void main(String[] args) {
		// 啟動 Spring Boot 應用程式
		SpringApplication.run(IdvTsaiVibecodingApplication.class, args);
	}

}
