package idv.tsai.vibecoding.service.schedule;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * 時間日誌任務類別
 * 
 * 實作 Quartz Job 介面，負責執行時間日誌輸出任務。
 * 此類別使用 package-private 可見性，遵循封裝原則。
 * 每次執行會在日誌中輸出當前時間，格式為 24 小時制。
 */
@Component
class TimeLogJob implements Job {

    /**
     * 日誌記錄器
     * 
     * 用於輸出時間日誌資訊
     */
    private static final Logger logger = LoggerFactory.getLogger(TimeLogJob.class);

    /**
     * 時間格式化器
     * 
     * 使用 24 小時制格式：yyyy-MM-dd HH:mm:ss
     */
    private static final DateTimeFormatter TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    /**
     * 執行任務的核心方法
     * 
     * 此方法會被 Quartz 排程器定期呼叫，
     * 負責輸出當前時間到日誌中。
     * 
     * @param context 任務執行上下文，包含任務執行的相關資訊
     * @throws JobExecutionException 當任務執行過程中發生錯誤時拋出
     */
    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        try {
            // 獲取當前時間
            LocalDateTime currentTime = LocalDateTime.now();
            
            // 格式化時間為指定格式
            String formattedTime = currentTime.format(TIME_FORMATTER);
            
            // 輸出時間日誌
            logger.info("Current time: {}", formattedTime);
            
            // 記錄任務執行資訊（調試用）
            logger.debug("時間日誌任務執行完成，下次執行時間: {}", 
                        context.getNextFireTime());
                        
        } catch (Exception e) {
            // 記錄錯誤日誌
            logger.error("時間日誌任務執行失敗", e);
            
            // 包裝為 JobExecutionException 並重新拋出
            throw new JobExecutionException("時間日誌任務執行過程中發生錯誤", e);
        }
    }
}