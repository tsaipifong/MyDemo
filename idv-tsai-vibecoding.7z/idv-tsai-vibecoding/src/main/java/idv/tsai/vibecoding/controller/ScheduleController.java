package idv.tsai.vibecoding.controller;

import idv.tsai.vibecoding.service.schedule.ScheduleService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 * 排程管理控制器
 * 
 * 提供 REST API 來管理排程任務，包括啟動、停止、狀態檢查和立即執行等功能。
 * 此控制器遵循 RESTful 設計原則，提供清晰的 API 介面。
 */
@RestController
@RequestMapping("/api/schedule")
public class ScheduleController {

    /**
     * 日誌記錄器
     * 
     * 用於記錄控制器操作的日誌資訊
     */
    private static final Logger logger = LoggerFactory.getLogger(ScheduleController.class);

    /**
     * 排程服務實例
     * 
     * 透過建構子注入，用於執行排程管理操作
     */
    private final ScheduleService scheduleService;

    /**
     * 建構子注入 ScheduleService
     * 
     * @param scheduleService 排程服務實例
     */
    public ScheduleController(ScheduleService scheduleService) {
        this.scheduleService = scheduleService;
    }

    /**
     * 啟動時間日誌排程任務
     * 
     * @return 操作結果的 ResponseEntity
     */
    @PostMapping("/timelog/start")
    public ResponseEntity<Map<String, Object>> startTimeLogJob() {
        Map<String, Object> response = new HashMap<>();
        
        try {
            logger.info("接收到啟動時間日誌任務的請求");
            
            scheduleService.startTimeLogJob();
            
            response.put("success", true);
            response.put("message", "時間日誌排程任務啟動成功");
            
            logger.info("時間日誌任務啟動成功");
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            logger.error("啟動時間日誌任務失敗", e);
            
            response.put("success", false);
            response.put("message", "時間日誌排程任務啟動失敗: " + e.getMessage());
            
            return ResponseEntity.internalServerError().body(response);
        }
    }

    /**
     * 停止時間日誌排程任務
     * 
     * @return 操作結果的 ResponseEntity
     */
    @PostMapping("/timelog/stop")
    public ResponseEntity<Map<String, Object>> stopTimeLogJob() {
        Map<String, Object> response = new HashMap<>();
        
        try {
            logger.info("接收到停止時間日誌任務的請求");
            
            scheduleService.stopTimeLogJob();
            
            response.put("success", true);
            response.put("message", "時間日誌排程任務停止成功");
            
            logger.info("時間日誌任務停止成功");
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            logger.error("停止時間日誌任務失敗", e);
            
            response.put("success", false);
            response.put("message", "時間日誌排程任務停止失敗: " + e.getMessage());
            
            return ResponseEntity.internalServerError().body(response);
        }
    }

    /**
     * 檢查時間日誌排程任務狀態
     * 
     * @return 任務狀態的 ResponseEntity
     */
    @GetMapping("/timelog/status")
    public ResponseEntity<Map<String, Object>> getTimeLogJobStatus() {
        Map<String, Object> response = new HashMap<>();
        
        try {
            logger.debug("檢查時間日誌任務狀態");
            
            boolean isRunning = scheduleService.isTimeLogJobRunning();
            
            response.put("success", true);
            response.put("running", isRunning);
            response.put("message", isRunning ? "時間日誌任務正在運行" : "時間日誌任務未運行");
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            logger.error("檢查時間日誌任務狀態失敗", e);
            
            response.put("success", false);
            response.put("running", false);
            response.put("message", "檢查任務狀態失敗: " + e.getMessage());
            
            return ResponseEntity.internalServerError().body(response);
        }
    }

    /**
     * 立即執行時間日誌任務
     * 
     * @return 操作結果的 ResponseEntity
     */
    @PostMapping("/timelog/execute")
    public ResponseEntity<Map<String, Object>> executeTimeLogJobNow() {
        Map<String, Object> response = new HashMap<>();
        
        try {
            logger.info("接收到立即執行時間日誌任務的請求");
            
            scheduleService.executeTimeLogJobNow();
            
            response.put("success", true);
            response.put("message", "時間日誌任務已觸發立即執行");
            
            logger.info("時間日誌任務立即執行成功");
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            logger.error("立即執行時間日誌任務失敗", e);
            
            response.put("success", false);
            response.put("message", "立即執行時間日誌任務失敗: " + e.getMessage());
            
            return ResponseEntity.internalServerError().body(response);
        }
    }

    /**
     * 獲取排程管理首頁資訊
     * 
     * @return 系統資訊的 ResponseEntity
     */
    @GetMapping("/info")
    public ResponseEntity<Map<String, Object>> getScheduleInfo() {
        Map<String, Object> response = new HashMap<>();
        
        try {
            boolean timeLogJobRunning = scheduleService.isTimeLogJobRunning();
            
            response.put("success", true);
            response.put("systemName", "Spring Quartz 排程管理系統");
            response.put("version", "1.0.0");
            response.put("timeLogJobRunning", timeLogJobRunning);
            response.put("availableOperations", new String[]{
                "啟動時間日誌任務 (POST /api/schedule/timelog/start)",
                "停止時間日誌任務 (POST /api/schedule/timelog/stop)",
                "檢查任務狀態 (GET /api/schedule/timelog/status)",
                "立即執行任務 (POST /api/schedule/timelog/execute)"
            });
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            logger.error("獲取排程資訊失敗", e);
            
            response.put("success", false);
            response.put("message", "獲取排程資訊失敗: " + e.getMessage());
            
            return ResponseEntity.internalServerError().body(response);
        }
    }
}