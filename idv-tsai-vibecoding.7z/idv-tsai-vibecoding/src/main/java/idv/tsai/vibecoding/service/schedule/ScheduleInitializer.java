package idv.tsai.vibecoding.service.schedule;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

/**
 * 排程初始化服務
 * 
 * 實作 ApplicationRunner 介面，在 Spring Boot 應用程式啟動完成後自動執行。
 * 負責初始化和啟動預設的排程任務，確保系統啟動後排程功能正常運作。
 */
@Component
public class ScheduleInitializer implements ApplicationRunner {

    /**
     * 日誌記錄器
     * 
     * 用於記錄排程初始化過程的日誌資訊
     */
    private static final Logger logger = LoggerFactory.getLogger(ScheduleInitializer.class);

    /**
     * 排程服務實例
     * 
     * 透過建構子注入，用於管理排程任務
     */
    private final ScheduleService scheduleService;

    /**
     * 建構子注入 ScheduleService
     * 
     * @param scheduleService 排程服務實例
     */
    public ScheduleInitializer(ScheduleService scheduleService) {
        this.scheduleService = scheduleService;
    }

    /**
     * 應用程式啟動後執行的初始化方法
     * 
     * 此方法會在 Spring Boot 應用程式完全啟動後自動執行，
     * 負責啟動預設的排程任務。
     * 
     * @param args 應用程式啟動參數
     * @throws Exception 當初始化過程中發生錯誤時拋出
     */
    @Override
    public void run(ApplicationArguments args) throws Exception {
        logger.info("開始初始化排程任務...");

        try {
            // 啟動時間日誌排程任務
            scheduleService.startTimeLogJob();
            
            // 驗證任務是否啟動成功
            if (scheduleService.isTimeLogJobRunning()) {
                logger.info("排程任務初始化完成，時間日誌任務已成功啟動");
            } else {
                logger.warn("排程任務初始化完成，但時間日誌任務狀態異常");
            }
            
        } catch (Exception e) {
            logger.error("排程任務初始化失敗", e);
            // 不重新拋出異常，避免影響應用程式啟動
            // 但記錄錯誤，便於後續排查問題
        }
    }
}