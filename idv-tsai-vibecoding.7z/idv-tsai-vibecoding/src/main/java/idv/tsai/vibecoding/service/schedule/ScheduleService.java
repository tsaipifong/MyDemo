package idv.tsai.vibecoding.service.schedule;

/**
 * 排程服務介面
 * 
 * 定義排程管理系統的核心服務介面，負責管理和控制各種排程任務。
 * 此介面遵循單一職責原則，專注於排程任務的生命週期管理。
 */
public interface ScheduleService {

    /**
     * 啟動時間日誌排程任務
     * 
     * 建立並啟動一個每分鐘執行一次的排程任務，
     * 該任務會在日誌中輸出當前時間。
     * 
     * @throws Exception 當任務建立或啟動失敗時拋出
     */
    void startTimeLogJob() throws Exception;

    /**
     * 停止時間日誌排程任務
     * 
     * 停止正在執行的時間日誌排程任務。
     * 
     * @throws Exception 當任務停止失敗時拋出
     */
    void stopTimeLogJob() throws Exception;

    /**
     * 檢查時間日誌排程任務是否正在運行
     * 
     * @return 如果任務正在運行則返回 true，否則返回 false
     * @throws Exception 當檢查任務狀態失敗時拋出
     */
    boolean isTimeLogJobRunning() throws Exception;

    /**
     * 立即執行時間日誌任務
     * 
     * 不等待排程時間，立即觸發執行時間日誌任務。
     * 用於測試或手動觸發任務執行。
     * 
     * @throws Exception 當任務執行失敗時拋出
     */
    void executeTimeLogJobNow() throws Exception;
}