package idv.tsai.vibecoding.config;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.quartz.SchedulerFactoryBean;
import org.springframework.scheduling.quartz.SpringBeanJobFactory;

/**
 * Quartz 排程器配置類別
 * 
 * 負責配置 Quartz 排程器的核心元件，包括任務工廠和排程器工廠。
 * 此配置類別確保 Quartz 任務可以使用 Spring 的依賴注入功能。
 */
@Configuration
public class QuartzConfig {

    /**
     * Spring 應用程式上下文
     * 
     * 用於在 Quartz 任務中獲取 Spring Bean 的參考
     */
    private final ApplicationContext applicationContext;

    /**
     * 建構子注入 ApplicationContext
     * 
     * @param applicationContext Spring 應用程式上下文
     */
    public QuartzConfig(ApplicationContext applicationContext) {
        this.applicationContext = applicationContext;
    }

    /**
     * 建立支援自動裝配的 Spring Bean 任務工廠
     * 
     * 此工廠允許 Quartz 任務使用 Spring 的依賴注入功能，
     * 讓任務類別可以注入其他 Spring Bean。
     * 
     * @return 配置好的 SpringBeanJobFactory 實例
     */
    @Bean
    public SpringBeanJobFactory springBeanJobFactory() {
        // 建立自訂任務工廠，支援自動裝配
        AutoWiringSpringBeanJobFactory jobFactory = new AutoWiringSpringBeanJobFactory();
        // 設定應用程式上下文，讓任務可以存取 Spring Bean
        jobFactory.setApplicationContext(applicationContext);
        return jobFactory;
    }

    /**
     * 建立排程器工廠 Bean
     * 
     * 配置 Quartz 排程器的主要工廠，負責建立和管理排程器實例。
     * 使用自訂的任務工廠來支援 Spring 依賴注入。
     * 
     * @param springBeanJobFactory 支援自動裝配的任務工廠
     * @return 配置好的 SchedulerFactoryBean 實例
     */
    @Bean
    public SchedulerFactoryBean schedulerFactoryBean(SpringBeanJobFactory springBeanJobFactory) {
        // 建立排程器工廠
        SchedulerFactoryBean schedulerFactory = new SchedulerFactoryBean();
        
        // 設定自訂任務工廠，支援 Spring 依賴注入
        schedulerFactory.setJobFactory(springBeanJobFactory);
        
        // 設定排程器名稱
        schedulerFactory.setSchedulerName("QuartzScheduler");
        
        // 應用程式關閉時等待任務完成
        schedulerFactory.setWaitForJobsToCompleteOnShutdown(true);
        
        // 覆寫現有的任務定義
        schedulerFactory.setOverwriteExistingJobs(true);
        
        // 自動啟動排程器
        schedulerFactory.setAutoStartup(true);
        
        return schedulerFactory;
    }
}