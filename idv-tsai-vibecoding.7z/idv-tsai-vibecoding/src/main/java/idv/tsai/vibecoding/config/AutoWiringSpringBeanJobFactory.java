package idv.tsai.vibecoding.config;

import org.quartz.spi.TriggerFiredBundle;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.lang.NonNull;
import org.springframework.lang.NonNull;
import org.springframework.scheduling.quartz.SpringBeanJobFactory;

/**
 * 支援自動裝配的 Spring Bean 任務工廠
 * 
 * 擴展 SpringBeanJobFactory，加入對 Spring 依賴注入的完整支援。
 * 此類別確保 Quartz 任務可以使用 @Autowired 等 Spring 註解來注入依賴。
 */
public class AutoWiringSpringBeanJobFactory extends SpringBeanJobFactory {

    /**
     * Spring 應用程式上下文
     * 
     * 用於獲取 AutowireCapableBeanFactory 來執行依賴注入
     */
    private ApplicationContext applicationContext;

    /**
     * 設定 Spring 應用程式上下文
     * 
     * 覆寫父類別的方法來設定 ApplicationContext。
     * 
     * @param applicationContext Spring 應用程式上下文
     */
    @Override
    public void setApplicationContext(@NonNull ApplicationContext applicationContext) {
        super.setApplicationContext(applicationContext);
        this.applicationContext = applicationContext;
    }

    /**
     * 建立任務實例並執行自動裝配
     * 
     * 覆寫父類別的方法，在建立任務實例後，
     * 使用 Spring 的 AutowireCapableBeanFactory 來執行依賴注入。
     * 
     * @param bundle 觸發器觸發包，包含任務執行的相關資訊
     * @return 已完成依賴注入的任務實例
     * @throws Exception 當任務建立或依賴注入失敗時拋出
     */
    @Override
    @NonNull
    protected Object createJobInstance(@NonNull TriggerFiredBundle bundle) throws Exception {
        // 使用父類別方法建立任務實例
        Object jobInstance = super.createJobInstance(bundle);
        
        // 獲取自動裝配能力的 Bean 工廠
        AutowireCapableBeanFactory beanFactory = applicationContext.getAutowireCapableBeanFactory();
        
        // 對任務實例執行依賴注入
        beanFactory.autowireBean(jobInstance);
        
        // 返回已完成依賴注入的任務實例
        return jobInstance;
    }
}