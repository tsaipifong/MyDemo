package idv.tsai.vibecoding.service.schedule;

import org.quartz.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import static org.quartz.JobBuilder.newJob;
import static org.quartz.TriggerBuilder.newTrigger;
import static org.quartz.CronScheduleBuilder.cronSchedule;

/**
 * 排程服務實作類別
 * 
 * 實作 ScheduleService 介面，提供排程任務的具體管理功能。
 * 此類別使用 package-private 可見性，遵循封裝原則。
 * 負責管理 Quartz 排程任務的建立、啟動、停止和執行。
 */
@Service
class ScheduleServiceImpl implements ScheduleService {

    /**
     * 日誌記錄器
     * 
     * 用於記錄排程服務的操作日誌和錯誤資訊
     */
    private static final Logger logger = LoggerFactory.getLogger(ScheduleServiceImpl.class);

    /**
     * 時間日誌任務的任務鍵值
     * 
     * 用於識別和管理時間日誌任務的唯一標識符
     */
    private static final JobKey TIME_LOG_JOB_KEY = JobKey.jobKey("timeLogJob", "DEFAULT");

    /**
     * 時間日誌任務的觸發器鍵值
     * 
     * 用於識別和管理時間日誌任務觸發器的唯一標識符
     */
    private static final TriggerKey TIME_LOG_TRIGGER_KEY = TriggerKey.triggerKey("timeLogTrigger", "DEFAULT");

    /**
     * Quartz 排程器實例
     * 
     * 透過建構子注入，用於管理所有排程任務
     */
    private final Scheduler scheduler;

    /**
     * 建構子注入 Scheduler
     * 
     * @param scheduler Quartz 排程器實例
     */
    public ScheduleServiceImpl(Scheduler scheduler) {
        this.scheduler = scheduler;
    }

    /**
     * 啟動時間日誌排程任務
     * 
     * 建立一個每分鐘執行一次的 Cron 排程任務，
     * 使用 TimeLogJob 類別來執行具體的任務邏輯。
     * 
     * @throws Exception 當任務建立或啟動失敗時拋出
     */
    @Override
    public void startTimeLogJob() throws Exception {
        logger.info("開始啟動時間日誌排程任務");

        // 檢查任務是否已經存在
        if (scheduler.checkExists(TIME_LOG_JOB_KEY)) {
            logger.warn("時間日誌任務已存在，將先刪除舊任務");
            scheduler.deleteJob(TIME_LOG_JOB_KEY);
        }

        // 建立任務詳細資訊
        JobDetail jobDetail = newJob(TimeLogJob.class)
                .withIdentity(TIME_LOG_JOB_KEY)
                .withDescription("每分鐘輸出當前時間到日誌的排程任務")
                .storeDurably()
                .build();

        // 建立 Cron 觸發器 - 每分鐘執行一次
        Trigger trigger = newTrigger()
                .withIdentity(TIME_LOG_TRIGGER_KEY)
                .withDescription("每分鐘觸發時間日誌任務")
                .withSchedule(cronSchedule("0 * * * * ?"))  // 每分鐘的第0秒執行
                .build();

        // 排程任務
        scheduler.scheduleJob(jobDetail, trigger);
        
        logger.info("時間日誌排程任務啟動成功，將每分鐘執行一次");
    }

    /**
     * 停止時間日誌排程任務
     * 
     * 從排程器中移除時間日誌任務，停止其執行。
     * 
     * @throws Exception 當任務停止失敗時拋出
     */
    @Override
    public void stopTimeLogJob() throws Exception {
        logger.info("開始停止時間日誌排程任務");

        // 檢查任務是否存在
        if (!scheduler.checkExists(TIME_LOG_JOB_KEY)) {
            logger.warn("時間日誌任務不存在，無需停止");
            return;
        }

        // 刪除任務
        boolean deleted = scheduler.deleteJob(TIME_LOG_JOB_KEY);
        if (deleted) {
            logger.info("時間日誌排程任務停止成功");
        } else {
            logger.error("時間日誌排程任務停止失敗");
            throw new RuntimeException("無法停止時間日誌排程任務");
        }
    }

    /**
     * 檢查時間日誌排程任務是否正在運行
     * 
     * @return 如果任務存在且正在運行則返回 true，否則返回 false
     * @throws Exception 當檢查任務狀態失敗時拋出
     */
    @Override
    public boolean isTimeLogJobRunning() throws Exception {
        // 檢查任務是否存在
        boolean jobExists = scheduler.checkExists(TIME_LOG_JOB_KEY);
        
        if (!jobExists) {
            return false;
        }

        // 檢查觸發器狀態
        Trigger.TriggerState triggerState = scheduler.getTriggerState(TIME_LOG_TRIGGER_KEY);
        
        // 只有在 NORMAL 狀態下才認為任務正在運行
        boolean isRunning = triggerState == Trigger.TriggerState.NORMAL;
        
        logger.debug("時間日誌任務運行狀態: 任務存在={}, 觸發器狀態={}, 正在運行={}", 
                    jobExists, triggerState, isRunning);
        
        return isRunning;
    }

    /**
     * 立即執行時間日誌任務
     * 
     * 不等待排程時間，立即觸發執行時間日誌任務。
     * 
     * @throws Exception 當任務執行失敗時拋出
     */
    @Override
    public void executeTimeLogJobNow() throws Exception {
        logger.info("立即執行時間日誌任務");

        // 檢查任務是否存在
        if (!scheduler.checkExists(TIME_LOG_JOB_KEY)) {
            logger.error("時間日誌任務不存在，無法立即執行");
            throw new IllegalStateException("時間日誌任務不存在，請先啟動任務");
        }

        // 立即觸發任務執行
        scheduler.triggerJob(TIME_LOG_JOB_KEY);
        
        logger.info("時間日誌任務已被觸發立即執行");
    }
}