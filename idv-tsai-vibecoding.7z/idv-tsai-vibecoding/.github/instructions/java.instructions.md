---
applyTo: '**/*.java'
---
# Java 專案程式碼標準
## 📝 開發慣例

- **命名規則**: 使用駝峰式命名法（camelCase）為變數和方法命名，類別名稱使用大駝峰式命名法（PascalCase）。
- **註解**: 所有類別、方法、變數都必須加上完整的繁體中文註解，解釋其目的和邏輯，嚴禁使用行末註解。
- **格式化**: 使用一致的程式碼格式，包括縮排、空白行和大括號位置。
- **錯誤處理**: 盡量使用例外處理機制（try-catch）來處理可能的錯誤情況。
- **測試**: 為所有公開介面方法撰寫單元測試，確保程式碼的正確性和穩定性。

## 🏗️ SOLID 原則與封裝要求

### 封裝原則基礎
- **public 類別限制**: 只有介面、控制器、配置類別、工具類別、例外類別、實體類別才可宣告為 public
- **package-private 優先**: 所有服務實作、DAO 實作、內部 Bean 都應使用 package-private
- **介面導向設計**: 所有服務層和共用 DAO 必須使用介面 + 實作的方式
- **依賴注入**: 依賴物件透過建構子注入，宣告為 private final

### SOLID 原則遵循
- **單一職責原則 (SRP)**: 每個類別只負責一項職責，避免職責混雜
- **開放封閉原則 (OCP)**: 對擴展開放，對修改封閉，使用抽象化和策略模式
- **里氏替換原則 (LSP)**: 衍生類別必須能夠替換其基底類別
- **介面隔離原則 (ISP)**: 客戶端不應該依賴它不需要的介面
- **依賴反轉原則 (DIP)**: 依賴抽象而非具體實作

## 🧪 測試要求

### 測試覆蓋率強制要求
- **介面方法覆蓋率**: 100% (每個 public interface 中的方法都必須測試)
- **業務邏輯覆蓋率**: 90% 以上
- **整體程式碼覆蓋率**: 80% 以上

### 測試用例要求
每個介面方法至少包含以下測試用例：
- 正常情況測試 (Happy Path)
- 邊界值測試 (Boundary)
- 異常情況測試 (Exception)
- 空值測試 (Null Safety)
- 業務規則測試 (Business Rules)

## 🏛️ 套件結構規範

### 基本套件約定
- **根套件**: `idv.tsai.vibecoding`
- **控制器套件**: `idv.tsai.vibecoding.controller` - 所有控制器類別
- **配置套件**: `idv.tsai.vibecoding.config` - 所有配置類別

### 模組化服務套件結構
- **服務套件**: `idv.tsai.vibecoding.service.{模組名稱}` - 按功能模組組織
  - 例如：`idv.tsai.vibecoding.service.schedule`
  - 例如：`idv.tsai.vibecoding.service.job`
  - 例如：`idv.tsai.vibecoding.service.quartz`

### DAO 組織原則
- **共用 DAO**: `idv.tsai.vibecoding.dao.common` - 多服務共用，必須有介面
- **Repository**: `idv.tsai.vibecoding.dao.repository` - Spring Data JPA Repository
- **服務專用 DAO**: 放在各服務模組的 `dao` 子套件中，package-private，無需介面

### 其他套件
- **實體套件**: `idv.tsai.vibecoding.entity` - 所有 JPA 實體（加 Entity 後綴）
- **工具套件**: `idv.tsai.vibecoding.util` - 公用工具類別（final class + static methods）
- **例外套件**: `idv.tsai.vibecoding.exception` - 自定義例外類別 