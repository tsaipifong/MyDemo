# GitHub Copilot 指令檔案 - Vibe Coding 環境建置專案

## 🎯 專案使命

這是一個 **Vibe Coding** 示範專案，透過開發 **Quartz + Spring Scheduler 排程管理系統**來示範建置完整的 AI 輔助開發環境。整合 VS Code + GitHub Copilot + MCP Tools，展示現代化的 AI 協作開發流程。

## 🏗️ 環境架構

### 核心技術棧
- **基礎框架**: Spring Boot 3.5.5 + Java 21
- **AI 工具鏈**: GitHub Copilot + Model Context Protocol (MCP)
- **開發環境**: VS Code + 多種 AI 代理工具整合

### 🏗️ 設計原則與架構規範

#### SOLID 原則遵循
嚴格遵守 SOLID 原則，確保程式碼的可維護性、可擴展性和可測試性：
- **單一職責原則 (SRP)**: 每個類別只負責一項職責
- **開放封閉原則 (OCP)**: 對擴展開放，對修改封閉
- **里氏替換原則 (LSP)**: 衍生類別必須能夠替換其基底類別
- **介面隔離原則 (ISP)**: 客戶端不應該依賴它不需要的介面
- **依賴反轉原則 (DIP)**: 依賴抽象而非具體實作

#### 封裝和可見性控制
- **public 類別限制**: 只有介面、控制器、配置類別、工具類別、例外類別、實體類別才可宣告為 public
- **package-private 優先**: 所有服務實作、DAO 實作、內部 Bean 都應使用 package-private
- **介面導向設計**: 服務層和共用 DAO 必須使用介面 + 實作的方式
- **依賴注入**: 依賴物件透過建構子注入，宣告為 private final

#### 分層架構設計
- **模組化服務**: 按功能模組組織服務層，避免單一巨大服務套件
- **DAO 組織**: 區分服務專用 DAO（package-private，無介面）和共用 DAO（有介面）
- **Bean 分層隔離**: 不同層次的 Bean 不混用，避免層間耦合

### 🧪 測試策略要求

#### 測試覆蓋率強制標準
- **介面方法覆蓋率**: 100% (每個 public interface 中的方法都必須測試)
- **業務邏輯覆蓋率**: 90% 以上
- **整體程式碼覆蓋率**: 80% 以上

#### 測試用例完整性
每個介面方法至少包含：正常情況、邊界值、異常情況、空值、業務規則等測試用例

### 專案結構約定
```
.github/
├── copilot-instructions.md     # 本檔案 - AI 代理指令
├── instructions/               # 程式碼標準規範
│   └── java.instructions.md   # Java 程式碼標準
└── prompts/                    # AI 任務腳本集合
    └── *.prompt.md             # 結構化任務指令檔案

src/main/java/idv/tsai/vibecoding/
├── IdvTsaiVibecodingApplication.java    # Spring Boot 主程式
├── config/                              # 配置類別
├── controller/                          # 控制器層
├── service/                            # 服務層（模組化組織）
│   ├── {模組名稱}/                     # 按功能模組組織
│   │   ├── {Service}.java              # 服務介面
│   │   ├── {Service}Impl.java          # 服務實作 (package-private)
│   │   ├── request/                    # 服務層請求 Bean
│   │   ├── response/                   # 服務層回應 Bean
│   │   └── dao/                        # 服務專用 DAO (package-private)
├── dao/                                # 共用資料存取層
│   ├── common/                         # 共用 DAO (介面 + 實作)
│   └── repository/                     # Spring Data JPA Repository
├── entity/                             # JPA 實體類別
├── util/                               # 公用工具類別
└── exception/                          # 例外處理

.{tool-name}-mcp/               # 各種 MCP 工具追蹤目錄
```

## 🔄 Vibe Coding 工作流程

### AI 代理協作模式
1. **需求表達**: 使用自然語言描述功能需求
2. **智能建議**: Copilot 提供程式碼建議和架構方案
3. **工具整合**: 透過 MCP 協議整合外部工具
4. **迭代優化**: AI 輔助重構和改進程式碼品質
 
### 指令檔案模式
- `.github/prompts/` 包含結構化的 AI 任務指令
- 每個 `.prompt.md` 檔案定義特定的自動化任務
- 支援多種 MCP 工具鏈整合（Playwright、資料庫、API 等）

## 📝 開發慣例

### 套件命名特殊約定
- **根套件**: `idv.tsai.vibecoding`
- **簡潔結構**: 避免不必要的深層套件嵌套
- 在 `application.properties` 中應用程式名稱保持連字符格式 `idv-tsai-vibecoding`

### 註解與文檔標準
- **類別註解**: 描述類別用途和職責
- **方法註解**: 說明功能、參數、回傳值
- **變數註解**: 解釋變數用途和資料型態
- **行內註解**: 解釋複雜邏輯，避免行末註解
- **語言**: 使用繁體中文撰寫所有註解

### AI 提示工程
- Prompt 檔案使用 YAML front matter + Markdown 格式
- 包含明確的 `mode`、`model`、`tools` 定義
- 步驟化描述任務流程，便於 AI 理解執行

## 🔧 建置與執行

```bash
# 標準 Spring Boot 開發流程
./mvnw clean compile          # 編譯專案
./mvnw spring-boot:run        # 執行應用程式
./mvnw test                   # 執行測試

# AI 工具整合驗證
# MCP 工具追蹤檔案會自動產生在對應目錄
```

## 🎨 Vibe Coding 最佳實踐

1. **直覺式開發**: 用自然語言表達需求，讓 AI 轉換為程式碼
2. **工具生態**: 善用 MCP 協議整合各種外部工具和服務
3. **迭代思維**: 快速原型 → AI 優化 → 功能完善的循環開發
4. **文檔驅動**: Prompt 檔案即文檔，確保 AI 任務可重現性
5. **版本演進**: 隨專案發展逐步擴充 AI 工具鏈配置