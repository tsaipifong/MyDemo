---
mode: 'agent'
model: 'Claude Sonnet 4'
tools: [
  'edit',
  'fetch', 
  'new',
  'runCommands',
  'runTasks',
  'runTests',
  'search',
  'usages',
  'vscodeAPI',
  'context7',
  'markitdown',
  'playwright',
  'sequentialthinking'
]
description: '排程管理網站建置專案 - 整合 Quartz Scheduler 和 Spring Scheduler'
---

# 排程管理網站建置專案提示詞

**重要**: 本專案必須遵循 `.github/copilot-instructions.md` 和 `.github/instructions/java.instructions.md` 中定義的基礎開發規範，包括 SOLID 原則、封裝要求、套件結構規範和測試標準。

**環境說明**: 本專案在 Windows PowerShell 環境下開發，所有 Maven wrapper 命令使用 `.\mvnw` 格式執行。

## 🎯 專案目標

請在現有的 `idv-tsai-vibecoding` 專案中，整合 Spring Quartz 技術，完成 Spring Quartz 系統配置，確保系統能正確啟動，並運行一個排程任務，每分鐘執行一次，輸出當前時間到log，格式為 `Current time: 2024-01-01 12:00:00`，24小時制。

## 🛠️ MCP 工具使用指引

**重要**: 在開發過程中，請適時使用以下 MCP 工具來確保專案品質和開發效率。這些工具的正確使用是專案成功的關鍵要素。

### 📋 開發規劃工具 - sequentialthinking
**使用時機**: 專案開始前和複雜功能開發前
- **目的**: 制定詳細的開發程序和步驟規劃
- **使用方法**: 使用 `sequentialthinking` 工具進行深度思考和規劃
- **應用場景**:
  - 專案開始時，規劃整體開發順序和里程碑
  - 實作複雜功能前，分析設計架構和實作步驟
  - 遇到技術難題時，系統性分析解決方案
  - 重構程式碼前，評估影響範圍和實作策略

### 📚 技術文檔查詢工具 - fetch & context7
**使用時機**: 需要確認任何技術 API 用法或實作細節時
- **context7 工具**:
  - 獲取任何程式庫的特定版本使用範例和最佳實踐
  - 獲取 Spring Boot 3.5.5、Quartz 2.5.0、H2、JPA、Thymeleaf 等框架的對應版本用法
  - 查詢各種技術在專案使用版本下的常見問題解決方案
  - 取得與專案版本相符的技術規範和配置資訊
  - 確認特定版本的 API 參數、方法簽名、配置選項等技術細節
  - 確認 Maven、Java 21 等工具的對應版本配置方式
  **fetch 工具**:
  - 查詢所有相關技術的官方文檔和對應版本資訊
  - 獲取 Spring Boot 3.5.5、Quartz 2.5.0、H2、JPA、Thymeleaf 等框架的對應版本用法
  - 查詢 Bootstrap 5、jQuery、JavaScript API 的對應版本文檔
  - 確認 Maven、Java 21 等工具的對應版本配置方式
- **應用場景**:
  - 實作任何新功能前，先查詢相關技術在專案版本下的正確用法
  - 配置任何框架或程式庫時，確認專案版本對應的配置參數
  - 使用任何 API 時，查詢專案版本下正確的調用方式和參數
  - 解決技術問題時，獲取適用於專案版本的解決方案和最佳實踐

### 🎯 工具使用最佳實踐
1. **開發前規劃**: 使用 `sequentialthinking` 制定詳細開發計畫
2. **技術確認**: 使用 `fetch`/`context7` 確保技術實作正確性
3. **設計視覺化**: 使用 `mermaid` 工具繪製系統設計圖
4. **功能驗證**: 使用 `playwright` 測試 UI 功能完整性
5. **持續改進**: 在開發過程中反覆使用這些工具進行驗證和優化

**強調**: 這些工具不是可選的輔助工具，而是確保專案品質的必要程序。請在相應的開發階段主動使用，而不是等到問題出現才使用。

