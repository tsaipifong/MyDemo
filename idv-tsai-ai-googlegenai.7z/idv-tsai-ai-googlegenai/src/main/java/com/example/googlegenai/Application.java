package com.example.googlegenai;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Spring Boot 應用程式主類別
 * 
 * 此類別是整個 Spring Boot 應用程式的入口點，
 * 使用 @SpringBootApplication 註解啟用自動配置、組件掃描和配置屬性。
 */
@SpringBootApplication
public class Application {

    /**
     * 應用程式主方法
     * 
     * @param args 命令列參數
     */
    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }
}
