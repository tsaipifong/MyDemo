package com.example.googlegenai;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * Spring Boot 應用程式測試類別
 * 
 * 此類別用於測試 Spring Boot 應用程式的基本啟動功能。
 */
@SpringBootTest
class ApplicationTests {

    /**
     * 測試應用程式上下文載入
     * 
     * 此測試方法驗證 Spring 應用程式上下文是否能夠正確載入。
     */
    @Test
    void contextLoads() {
        // 如果應用程式上下文載入成功，此測試將通過
    }

}
