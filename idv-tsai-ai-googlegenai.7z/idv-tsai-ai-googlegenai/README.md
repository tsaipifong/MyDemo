# IDV Tsai AI Google Generative AI

這是一個基於 Spring Boot 框架開發的 Maven 專案，整合 Google Generative AI 功能。

## 專案描述

本專案提供一個標準的 Spring Boot 應用程式架構，包含完整的分層設計和配置管理，可作為整合 Google Generative AI 服務的基礎框架。

## 技術棧

- **Java**: 17
- **Spring Boot**: 3.2.0
- **Maven**: 專案管理與建置工具
- **H2 Database**: 嵌入式記憶體資料庫（開發測試用）
- **Lombok**: 簡化 Java 程式碼
- **Spring Data JPA**: 資料持久層框架

## 專案目錄結構

```
idv-tsai-ai-googlegenai/
├── src/
│   ├── main/
│   │   ├── java/
│   │   │   └── com/
│   │   │       └── example/
│   │   │           └── googlegenai/
│   │   │               ├── Application.java           # Spring Boot 主程式
│   │   │               ├── config/                    # 配置類別目錄
│   │   │               ├── controller/                # 控制器層目錄
│   │   │               ├── service/                   # 服務層目錄
│   │   │               ├── repository/                # 資料訪問層目錄
│   │   │               └── model/                     # 資料模型目錄
│   │   └── resources/
│   │       ├── application.yml                        # 主配置檔案
│   │       ├── application-dev.yml                    # 開發環境配置
│   │       └── application-prod.yml                   # 生產環境配置
│   └── test/
│       └── java/
│           └── com/
│               └── example/
│                   └── googlegenai/
│                       └── ApplicationTests.java      # 測試類別
├── pom.xml                                            # Maven 專案配置檔
├── .gitignore                                         # Git 忽略檔案配置
└── README.md                                          # 專案說明文件
```

## 快速開始

### 環境需求

- JDK 17 或以上版本
- Maven 3.6 或以上版本

### 建置專案

```powershell
mvn clean install
```

### 執行應用程式

```powershell
mvn spring-boot:run
```

應用程式將在 `http://localhost:8080` 啟動。

### 使用特定環境配置

開發環境：
```powershell
mvn spring-boot:run -Dspring-boot.run.profiles=dev
```

生產環境：
```powershell
mvn spring-boot:run -Dspring-boot.run.profiles=prod
```

### 執行測試

```powershell
mvn test
```

## H2 資料庫控制台

應用程式啟動後，可以透過以下網址訪問 H2 資料庫的 Web 控制台：

```
http://localhost:8080/h2-console
```

連線資訊：
- JDBC URL: `jdbc:h2:mem:testdb`
- 使用者名稱: `sa`
- 密碼: （留空）

## 專案架構說明

### 分層架構

- **Controller 層**: 處理 HTTP 請求和回應，負責與前端互動
- **Service 層**: 包含業務邏輯處理
- **Repository 層**: 資料訪問層，與資料庫互動
- **Model 層**: 定義資料實體和 DTO 物件
- **Config 層**: 應用程式配置類別

## 開發指南

### 新增 REST API

1. 在 `model` 目錄下建立資料實體類別
2. 在 `repository` 目錄下建立資料訪問介面
3. 在 `service` 目錄下建立服務類別實作業務邏輯
4. 在 `controller` 目錄下建立控制器類別處理 HTTP 請求

### 配置管理

- `application.yml`: 共用配置
- `application-dev.yml`: 開發環境專用配置
- `application-prod.yml`: 生產環境專用配置
