package com.momo.ltsre.jarvis.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ai.chat.memory.ChatMemory;
import org.springframework.ai.chat.memory.InMemoryChatMemoryRepository;
import org.springframework.ai.chat.memory.MessageWindowChatMemory;
import org.springframework.stereotype.Service;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

/**
 * 聊天會話服務類別
 * <p>
 * 負責管理聊天會話的記憶體儲存，提供會話上下文的持久化功能。
 * 每個會話最多保留 30 條訊息記錄，超出時自動移除較早的訊息。
 * </p>
 *
 * @author JARVIS AI Assistant
 * @version 1.0
 * @since 2025-08-07
 */
@Service
public class ChatMemoryService {

    /** 日誌記錄器 */
    private static final Logger log = LoggerFactory.getLogger(ChatMemoryService.class);
    
    /** 每個會話保留的最大訊息數量 */
    private static final int MAX_MESSAGES_PER_CONVERSATION = 30;
    
    /** 會話記憶體快取，key為會話ID，value為對應的ChatMemory實例 */
    private final ConcurrentMap<String, ChatMemory> conversationMemories = new ConcurrentHashMap<>();

    /**
     * 獲取指定會話ID的聊天記憶體實例
     * <p>
     * 如果會話不存在，將自動建立新的會話記憶體實例
     * </p>
     *
     * @param conversationId 會話唯一識別碼
     * @return ChatMemory 會話記憶體實例
     */
    public ChatMemory getOrCreateConversationMemory(String conversationId) {
        // 使用 computeIfAbsent 確保執行緒安全的獲取或建立操作
        return conversationMemories.computeIfAbsent(conversationId, this::createNewChatMemory);
    }

    /**
     * 建立新的聊天記憶體實例
     * <p>
     * 使用 MessageWindowChatMemory 實現滑動窗口記憶體管理，
     * 自動維護最近的訊息記錄，超出限制時移除較早的訊息
     * </p>
     *
     * @param conversationId 會話唯一識別碼
     * @return ChatMemory 新建立的會話記憶體實例
     */
    private ChatMemory createNewChatMemory(String conversationId) {
        log.debug("建立新的會話記憶體，會話ID: {}", conversationId);
        
        // 建立記憶體儲存庫實例
        InMemoryChatMemoryRepository repository = new InMemoryChatMemoryRepository();
        
        // 建立具有訊息窗口限制的會話記憶體
        ChatMemory chatMemory = MessageWindowChatMemory.builder()
                .chatMemoryRepository(repository)
                .maxMessages(MAX_MESSAGES_PER_CONVERSATION)
                .build();
        
        log.info("已建立會話記憶體，會話ID: {}，最大訊息數: {}", conversationId, MAX_MESSAGES_PER_CONVERSATION);
        
        return chatMemory;
    }

    /**
     * 移除指定會話的記憶體
     * <p>
     * 從記憶體中清除指定會話的所有訊息記錄，釋放相關資源
     * </p>
     *
     * @param conversationId 要移除的會話唯一識別碼
     * @return boolean 是否成功移除會話記憶體
     */
    public boolean removeConversationMemory(String conversationId) {
        ChatMemory removed = conversationMemories.remove(conversationId);
        boolean success = removed != null;
        
        if (success) {
            log.info("已移除會話記憶體，會話ID: {}", conversationId);
        } else {
            log.warn("嘗試移除不存在的會話記憶體，會話ID: {}", conversationId);
        }
        
        return success;
    }

    /**
     * 獲取當前活躍會話數量
     * <p>
     * 返回目前在記憶體中維護的會話總數
     * </p>
     *
     * @return int 活躍會話數量
     */
    public int getActiveConversationCount() {
        int count = conversationMemories.size();
        log.debug("當前活躍會話數量: {}", count);
        return count;
    }

    /**
     * 清除所有會話記憶體
     * <p>
     * 清空所有會話的記憶體資料，通常用於系統重置或維護
     * </p>
     */
    public void clearAllConversations() {
        int previousCount = conversationMemories.size();
        conversationMemories.clear();
        log.info("已清除所有會話記憶體，清除數量: {}", previousCount);
    }

    /**
     * 檢查指定會話是否存在
     * <p>
     * 判斷指定會話ID是否已在記憶體中建立
     * </p>
     *
     * @param conversationId 會話唯一識別碼
     * @return boolean 會話是否存在
     */
    public boolean hasConversation(String conversationId) {
        boolean exists = conversationMemories.containsKey(conversationId);
        log.debug("檢查會話是否存在，會話ID: {}，結果: {}", conversationId, exists);
        return exists;
    }
}
