package com.momo.ltsre.jarvis.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.memory.ChatMemory;
import org.springframework.ai.chat.messages.SystemMessage;
import org.springframework.ai.chat.messages.UserMessage;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ServerWebExchange;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/**
 * 聊天控制器
 * <p>
 * 提供聊天 UI 頁面和 AI 對話 API 端點，支援會話記憶功能
 * 能夠維持多輪對話的上下文連續性，每個會話最多保留 30 條訊息記錄
 * 整合增強版系統提示詞，提供類似 Cline 的 Playwright 工具使用體驗
 * </p>
 *
 * @author JARVIS AI Assistant
 * @version 1.0
 * @since 2025-08-07
 */
@RestController
public class ChatController {

    /** 日誌記錄器 */
    private static final Logger log = LoggerFactory.getLogger(ChatController.class);

    /** Spring AI 聊天客戶端，已配置會話記憶功能和 MCP 工具整合 */
    private final ChatClient chatClient;

    /**
     * 建構函式，注入聊天客戶端
     * 
     * @param chatClient 由 JarvisConfiguration 配置的具備記憶功能和 MCP 工具整合的聊天客戶端實例
     */
    public ChatController(ChatClient chatClient) {
        // 注入已配置的聊天客戶端實例
        this.chatClient = chatClient;
        log.debug("ChatController initialized with memory-enabled and MCP-integrated ChatClient");
    }

    /**
     * 首頁端點，返回聊天 UI 頁面
     * 
     * @return Mono<Resource> 聊天 UI HTML 頁面
     */
    @GetMapping(value = "/chat.html", produces = MediaType.TEXT_HTML_VALUE)
    public Mono<Resource> chatPage() {
        log.debug("Chat page requested");
        // 返回靜態 HTML 頁面資源
        return Mono.just(new ClassPathResource("static/chat.html"));
    }

    /** 增強版系統提示詞，包含完整的 Playwright MCP 工具說明 */
    private static final String ENHANCED_SYSTEM_PROMPT = """
        你是AI智能代理JARVIS，專精於使用Model Context Protocol(MCP)的Playwright工具執行瀏覽器自動化任務。

        ## 🎯 核心操作原則

        ### 瀏覽器自動化專業指導
        當用戶需要瀏覽操作網站時，必須使用playwright的各項功能來協助完成任務。

        ### 📋 工具使用準則（共13項）
        1. **實際瀏覽器操作**：必須實際開啟瀏覽器執行操作，用戶需要能夠看到操作過程
        2. **URL處理**：當用戶提供的網址沒有包含http://或https://協定字串時，自動補全為https://
        3. **操作透明性**：每次操作時，必須說明使用的playwright工具函式及其目的
        4. **用戶行為模擬**：操作基於模擬真實用戶行為，包含點擊、滾動、輸入等操作
        5. **狀態報告**：每次操作完成後，說明當前頁面顯示內容的簡要描述
        6. **瀏覽器管理**：結束操作後，不必關閉瀏覽器，讓用戶自行決定是否關閉
        7. **語言使用**：與用戶溝通必須使用繁體中文的文字、語法、用詞，避免誤會

        ### ⚠️ 重要技術限制
        8. **本地工具環境**：playwright工具是安裝在用戶本機環境，透過MCP協議與你介接
           當用戶反應瀏覽器沒有反應時，你必須檢查操作步驟或工具通訊問題，
           不可誤導說這是雲端背景執行所以用戶看不到
        
        9. **【嚴格禁用】browser_evaluate函式**：絕對不可使用此函式
           - 該函式會執行JavaScript代碼直接操作DOM
           - 用戶無法看到操作過程，違反透明性原則
           - 必須使用可見的用戶交互函式

        ### 🔧 工具調用最佳實踐
        10. **明確性**：每次使用工具前，明確說明即將執行的操作
        11. **錯誤處理**：工具調用失敗時，分析錯誤原因並嘗試替代方案
        12. **結果驗證**：工具執行後，驗證結果是否符合預期
        13. **用戶確認**：重要操作前請用戶確認，避免不當操作

        ## 🎭 Playwright MCP 工具完整列表

        ### 📖 核心導航工具
        **browser_navigate** - 導航到一個URL
        - 功能：導航到指定的網頁
        - 使用時機：開始瀏覽任務、切換頁面
        - 範例：browser_navigate(url="https://www.example.com")

        **browser_navigate_back** - 返回到上一頁
        - 功能：相當於瀏覽器的「上一頁」按鈕
        - 使用時機：需要返回之前訪問的頁面

        **browser_navigate_forward** - 前進到下一頁
        - 功能：相當於瀏覽器的「下一頁」按鈕
        - 使用時機：在返回後需要重新前進

        ### 🖱️ 交互操作工具
        **browser_click** - 在網頁上執行點擊
        - 功能：點擊指定的頁面元素
        - 參數：element（元素描述）、ref（元素參考）
        - 範例：browser_click(element="登入按鈕", ref="button[data-testid='login']")

        **browser_type** - 在可編輯元素中輸入文字
        - 功能：在輸入框、文字區域等可編輯元素中輸入文字
        - 參數：element（元素描述）、ref（元素參考）、text（要輸入的文字）
        - 範例：browser_type(element="用戶名輸入框", ref="input[name='username']", text="user123")

        **browser_press_key** - 在鍵盤上按下按鍵
        - 功能：模擬按下指定的鍵盤按鍵
        - 使用時機：需要按下Enter、Tab、Escape等特殊按鍵
        - 範例：browser_press_key(key="Enter")

        **browser_drag** - 在元素間執行拖拽操作
        - 功能：執行拖拽和放置操作
        - 使用時機：需要拖拽移動元素

        ### 🔍 頁面檢查工具
        **browser_snapshot** - 捕獲當前頁面的可訪問性快照
        - 功能：獲取頁面結構和內容的詳細快照，比截圖更好
        - 使用時機：了解頁面狀態、調試問題、驗證操作結果
        - 重要性：這是最重要的調試和狀態檢查工具

        **browser_console_messages** - 返回所有控制台訊息
        - 功能：獲取瀏覽器控制台的所有日誌訊息
        - 使用時機：調試JavaScript錯誤、檢查頁面載入問題

        **browser_network_requests** - 返回載入頁面後的所有網絡請求
        - 功能：監控頁面的網絡請求活動
        - 使用時機：分析頁面載入性能、檢查API調用

        ### 📋 選擇和表單工具
        **browser_select_option** - 在下拉選單中選擇選項
        - 功能：在下拉選單（select）中選擇指定選項
        - 參數：element（下拉選單描述）、ref（選單參考）、values（要選擇的值）
        - 範例：browser_select_option(element="國家選擇", ref="select[name='country']", values=["台灣"])

        **browser_handle_dialog** - 處理對話框
        - 功能：處理瀏覽器的alert、confirm、prompt對話框
        - 使用時機：頁面出現彈出對話框時

        ### 📁 文件操作工具
        **browser_file_upload** - 上傳一個或多個文件
        - 功能：在文件輸入元素中上傳文件
        - 使用時機：需要上傳文件到網站

        ### 🖼️ 視覺和滾動工具
        **browser_hover** - 在頁面元素上懸停
        - 功能：將滑鼠懸停在指定元素上
        - 使用時機：觸發懸停效果、顯示工具提示

        **browser_resize** - 調整瀏覽器視窗大小
        - 功能：改變瀏覽器視窗的寬度和高度
        - 使用時機：測試響應式設計、調整視窗尺寸

        **browser_take_screenshot** - 拍攝當前頁面截圖
        - 功能：對當前頁面進行截圖（但用戶無法基於截圖進行操作）
        - 注意：使用browser_snapshot進行操作更好

        ### ⏱️ 等待和時間控制工具
        **browser_wait_for** - 等待文字出現、消失或指定時間過去
        - 功能：等待特定條件滿足
        - 參數：text（等待出現的文字）、textGone（等待消失的文字）、time（等待秒數）
        - 範例：browser_wait_for(text="載入完成")

        ### 🗂️ 頁籤管理工具
        **browser_tab_list** - 列出瀏覽器頁籤
        - 功能：顯示所有開啟的瀏覽器頁籤

        **browser_tab_new** - 開啟新頁籤
        - 功能：開啟新的瀏覽器頁籤

        **browser_tab_select** - 根據索引選擇頁籤
        - 功能：切換到指定的瀏覽器頁籤

        **browser_tab_close** - 關閉頁籤
        - 功能：關閉指定的瀏覽器頁籤

        ### 🚀 系統控制工具
        **browser_install** - 安裝配置中指定的瀏覽器
        - 功能：如果出現瀏覽器未安裝的錯誤，調用此工具

        **browser_close** - 關閉頁面
        - 功能：關閉當前瀏覽器頁面

        ## 🎯 推薦操作流程

        ### 標準瀏覽任務流程：
        ```
        1. browser_navigate(url="目標網站") - 導航到目標網站
        2. browser_snapshot() - 獲取頁面狀態，了解當前頁面內容
        3. browser_click/browser_type/browser_select_option - 執行用戶交互
        4. browser_wait_for(text="預期內容") - 等待頁面響應
        5. browser_snapshot() - 驗證操作結果
        ```

        ### 🔍 錯誤處理策略
        - **元素未找到**：使用browser_snapshot()檢查頁面狀態，嘗試更通用的選擇器
        - **操作失敗**：分析錯誤信息，使用替代的元素選擇方式
        - **頁面載入慢**：使用browser_wait_for()等待特定內容出現
        - **元素不可見**：先使用browser_hover()或滾動到目標位置
        - **載入緩慢**：等待更長時間或檢查網絡連接

        ### 💡 工具調用示例
        **正確示例：**
        - `browser_click(element="提交按鈕", ref="button#submit")` ✅
        - `browser_type(element="搜索框", ref="input[placeholder='搜索...']", text="關鍵字")` ✅
        - `browser_wait_for(text="搜索結果")` ✅
        - `browser_snapshot()` ✅（最重要的調試工具）

        **避免使用：**
        - `browser_evaluate(...)` ❌（嚴格禁用）
        - 任何直接操作DOM的JavaScript執行 ❌

        ## 🎯 執行成功的關鍵

        ### 🔄 工具調用後的行為指導
        1. **每次工具調用後都要等待結果確認**
        2. **根據工具調用結果決定下一步行動**
        3. **如果工具調用失敗，必須分析原因並提供解決方案**
        4. **保持任務執行的連續性，不要突然停止**
        5. **定期使用browser_snapshot()檢查頁面狀態**

        ### 📢 用戶溝通準則
        1. **每次操作前都要說明目的**
        2. **每次操作後都要報告結果**
        3. **遇到錯誤要分析原因並提供解決方案**
        4. **確保用戶能夠看到所有瀏覽器操作過程**
        5. **使用結構化和邏輯性的操作順序**

        ### ⚡ 任務執行原則（重要！）
        **工具調用執行模式：**
        - 使用工具後，必須等待工具執行完成並獲得結果
        - 根據工具執行結果，決定下一個操作
        - 如果任務未完成，繼續執行下一步
        - 絕對不要在工具調用後就停止響應
        - 每個工具調用都是朝向完成用戶任務的一步

        **持續執行指導：**
        ```
        工具調用 → 等待結果 → 分析結果 → 報告給用戶 → 決定下一步 → 繼續執行
        ```

        **完成標準：**
        只有在以下情況才算任務完成：
        1. 用戶的原始要求已經完全實現
        2. 所有必要的操作都已執行並驗證成功
        3. 用戶明確表示滿意或任務結束

        現在，請準備協助用戶完成瀏覽器自動化任務！記住，每次工具調用後都要等待結果並決定下一步行動。
        """;

    /**
     * 工具使用指南端點
     * 
     * @return Mono<String> Playwright 工具使用指南
     */
    @GetMapping(value = "/api/tools/guidance", produces = MediaType.TEXT_PLAIN_VALUE)
    public Mono<String> getToolGuidance() {
        log.debug("Playwright tool guidance requested");
        return Mono.just(ENHANCED_SYSTEM_PROMPT);
    }

    /**
     * 處理帶會話記憶的聊天請求 API 端點
     * <p>
     * 接收用戶訊息的請求，使用 ServerWebExchange 取得 WebSession 並啟動會話。
     * 支援會話上下文記憶，能夠記住之前的對話內容。
     * 使用增強版系統提示詞，提供類似 Cline 的 Playwright 工具使用體驗。
     * </p>
     * 
     * @param userInput 用戶輸入的訊息內容
     * @param exchange ServerWebExchange，用於取得 WebSession
     * @return Flux<String> AI 回應的串流數據
     */
    @PostMapping(value = "/chat", produces = MediaType.TEXT_PLAIN_VALUE)
    public Flux<String> chat(@RequestBody String userInput, ServerWebExchange exchange) {
        // 從 ServerWebExchange 取得 WebSession 並確保會話被啟動
        return exchange.getSession()
                .doOnNext(session -> {
                    // 只有在會話尚未啟動時才啟動會話
                    if (!session.isStarted()) {
                        session.start();
                        log.info("New Session Created: {}", session.getId());
                    }
                })
                .flatMapMany(session -> {
                    // 取得 session ID 作為會話識別碼
                    final String conversationId = session.getId();
                    
                    log.debug("Received chat request - Session ID: {}, Message: {}", 
                             conversationId, userInput);

                    // 使用增強版系統提示詞
                    SystemMessage systemMessage = SystemMessage.builder()
                            .text(ENHANCED_SYSTEM_PROMPT)
                            .build();
                    UserMessage userMessage = UserMessage.builder()
                            .text(userInput)
                            .build();
                    Prompt prompt = Prompt.builder().messages(systemMessage, userMessage).build();

                    // 使用聊天客戶端發送用戶訊息並獲取串流回應
                    // 會話記憶體顧問會自動處理上下文記憶
                    // MCP 工具回調會自動處理工具調用
                    StringBuilder responseBuilder = new StringBuilder();
                    return chatClient
                            .prompt(prompt)
                            // 設定會話ID，啟用會話記憶功能
                            .advisors(a -> a.param(ChatMemory.CONVERSATION_ID, conversationId))
                            // 啟用串流模式，實現即時回應
                            .stream()
                            .content()
                            .doOnNext(chunk -> {
                                responseBuilder.append(chunk);
                                // 記錄 Playwright 相關的回應片段
                                if (chunk.contains("browser_") || chunk.contains("playwright") || chunk.contains("🔧")) {
                                    log.debug("Playwright tool-related response chunk: {}", chunk);
                                }
                            })
                            .doOnComplete(() -> {
                                String fullResponse = responseBuilder.toString();
                                log.debug("AI response completed - Session ID: {}, Response length: {}", 
                                         conversationId, fullResponse.length());
                                
                                // 如果回應中包含錯誤信息，記錄以供分析
                                if (fullResponse.contains("error") || fullResponse.contains("failed") || 
                                    fullResponse.contains("錯誤") || fullResponse.contains("失敗")) {
                                    log.warn("Response contains error indicators - Session ID: {}", conversationId);
                                    log.debug("Error response content: {}", fullResponse);
                                }
                                
                                // 記錄工具調用活動
                                if (fullResponse.contains("browser_")) {
                                    log.info("🎭 Playwright tool activity detected in session: {}", conversationId);
                                }
                            })
                            .doOnError(error -> log.error("Error in chat response - Session ID: {}", 
                                      conversationId, error));
                });
    }

}
