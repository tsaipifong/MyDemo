package com.momo.ltsre.jarvis.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ai.mcp.AsyncMcpToolCallbackProvider;
import org.springframework.stereotype.Service;

/**
 * 動態系統提示詞服務
 * <p>
 * 負責動態生成包含 MCP 工具詳細信息的系統提示詞
 * 模仿 Cline 的工具發現和文檔注入機制，提高 AI 對工具的理解和使用準確性
 * </p>
 *
 * @author JARVIS AI Assistant
 * @version 1.0
 * @since 2025-08-11
 */
@Service
public class DynamicSystemPromptService {

    /** 日誌記錄器 */
    private static final Logger log = LoggerFactory.getLogger(DynamicSystemPromptService.class);

    /** MCP 工具回調提供者 */
    @SuppressWarnings("unused")
    private final AsyncMcpToolCallbackProvider mcpProvider;

    /**
     * 建構函式注入依賴
     *
     * @param mcpProvider MCP 工具回調提供者
     */
    public DynamicSystemPromptService(AsyncMcpToolCallbackProvider mcpProvider) {
        this.mcpProvider = mcpProvider;
    }

    /**
     * 生成增強版系統提示詞
     * <p>
     * 包含基礎指導原則和動態工具文檔，讓 AI 更準確地使用 MCP 工具
     * </p>
     *
     * @return String 完整的系統提示詞
     */
    public String generateEnhancedSystemPrompt() {
        StringBuilder promptBuilder = new StringBuilder();

        // 基礎系統提示詞
        promptBuilder.append("""
            你是智能AI代理人JARVIS，專精於使用Model Context Protocol(MCP)工具執行各種任務。

            ## 核心操作原則

            ### 瀏覽器自動化任務
            當用戶需要瀏覽操作網站時，必須使用playwright的各項功能來協助完成任務。

            ### 工具使用準則
            1. **實際瀏覽器操作**：必須實際開啟瀏覽器執行操作，用戶需要能夠看到操作過程
            2. **URL處理**：當用戶提供的網址沒有包含http://或https://協定字串時，自動補全為https://
            3. **操作透明性**：每次操作時，必須說明使用的playwright工具函式及其目的
            4. **用戶行為模擬**：操作基於模擬真實用戶行為，包含點擊、滾動、輸入等操作
            5. **狀態報告**：每次操作完成後，說明當前頁面顯示內容的簡要描述
            6. **瀏覽器管理**：結束操作後，不必關閉瀏覽器，讓用戶自行決定是否關閉
            7. **語言使用**：與用戶溝通必須使用繁體中文的文字、語法、用詞，避免誤會

            ### 重要技術限制
            8. **本地工具環境**：playwright工具是安裝在用戶本機環境，透過MCP協議與你介接
               當用戶反應瀏覽器沒有反應時，你必須檢查操作步驟或工具通訊問題，
               不可誤導說這是雲端背景執行所以用戶看不到
            
            9. **【嚴格禁用】**：絕對不可使用 browser_evaluate 函式
               - 該函式會執行JavaScript代碼直接操作DOM
               - 用戶無法看到操作過程，違反透明性原則
               - 必須使用可見的用戶交互函式：browser_click, browser_type, browser_scroll 等

            ### 工具調用最佳實踐
            10. **明確性**：每次使用工具前，明確說明即將執行的操作
            11. **錯誤處理**：工具調用失敗時，分析錯誤原因並嘗試替代方案
            12. **結果驗證**：工具執行後，驗證結果是否符合預期
            13. **用戶確認**：重要操作前請用戶確認，避免不當操作

            """);

        // 添加工具使用示例
        promptBuilder.append("""
            
            ## Playwright 工具使用示例

            ### 基本瀏覽操作
            ```
            1. 導航到網站：browser_navigate(url="https://example.com")
            2. 點擊元素：browser_click(element="登入按鈕", ref="button[data-testid='login']")
            3. 輸入文字：browser_type(element="用戶名輸入框", ref="input[name='username']", text="user123")
            4. 捲動頁面：browser_scroll(direction="down", amount=3)
            5. 等待元素：browser_wait_for(text="載入完成")
            ```

            ### 錯誤恢復策略
            - 元素未找到：使用 browser_snapshot() 檢查頁面狀態
            - 操作失敗：嘗試使用不同的元素選擇器
            - 頁面載入慢：使用 browser_wait_for() 等待特定內容出現

            """);

        // TODO: 在未來版本中，這裡可以動態查詢 MCP 工具並添加詳細的工具 schema
        // 目前 Spring AI 的 AsyncMcpToolCallbackProvider 沒有公開獲取工具清單的 API
        // 可以考慮實現自定義的工具發現機制

        log.debug("Generated enhanced system prompt with {} characters", promptBuilder.length());

        return promptBuilder.toString();
    }

    /**
     * 獲取工具調用指導
     * <p>
     * 提供具體的工具調用指導和錯誤處理建議
     * </p>
     *
     * @param toolCategory 工具類別（如 "browser", "file", "api" 等）
     * @return String 該類別工具的使用指導
     */
    public String getToolGuidance(String toolCategory) {
        switch (toolCategory.toLowerCase()) {
            case "browser":
            case "playwright":
                return """
                    ## Playwright 瀏覽器工具指導
                    
                    ### 推薦使用順序
                    1. browser_navigate - 導航到目標網站
                    2. browser_snapshot - 獲取頁面狀態
                    3. browser_click/browser_type - 執行用戶交互
                    4. browser_wait_for - 等待頁面響應
                    5. browser_snapshot - 驗證操作結果
                    
                    ### 常見錯誤處理
                    - 元素不可見：先使用 browser_scroll 滾動到目標位置
                    - 載入緩慢：使用 browser_wait_for 等待特定文字或元素
                    - 操作失敗：檢查元素 ref 是否正確，考慮使用更通用的選擇器
                    """;
            default:
                return "未知工具類別，請參考基礎工具使用原則。";
        }
    }

}
