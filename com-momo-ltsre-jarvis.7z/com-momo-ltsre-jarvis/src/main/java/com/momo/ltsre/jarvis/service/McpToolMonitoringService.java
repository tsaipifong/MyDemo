package com.momo.ltsre.jarvis.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 * MCP 工具調用監控服務
 * <p>
 * 監控和記錄 MCP 工具的調用情況，提供調用統計和錯誤分析
 * 幫助診斷和優化工具調用效果，提供類似 Cline 的工具調用透明度
 * </p>
 *
 * @author JARVIS AI Assistant
 * @version 1.0
 * @since 2025-08-11
 */
@Service
public class McpToolMonitoringService {

    /** 日誌記錄器 */
    private static final Logger log = LoggerFactory.getLogger(McpToolMonitoringService.class);

    /** 成功調用計數 */
    private long successfulCalls = 0;

    /** 失敗調用計數 */
    private long failedCalls = 0;

    /** 最後調用的工具 */
    private String lastCalledTool = "";

    /**
     * 記錄工具調用開始
     *
     * @param toolName 工具名稱
     * @param arguments 工具參數
     */
    public void logToolCallStart(String toolName, Object arguments) {
        lastCalledTool = toolName;
        log.info("🔧 工具調用開始 - 工具: {}, 參數: {}", toolName, arguments);
    }

    /**
     * 記錄工具調用成功
     *
     * @param toolName 工具名稱
     * @param result 調用結果
     */
    public void logToolCallSuccess(String toolName, Object result) {
        successfulCalls++;
        log.info("✅ 工具調用成功 - 工具: {}, 結果: {}", toolName, result);
    }

    /**
     * 記錄工具調用失敗
     *
     * @param toolName 工具名稱
     * @param error 錯誤信息
     */
    public void logToolCallFailure(String toolName, String error) {
        failedCalls++;
        log.warn("❌ 工具調用失敗 - 工具: {}, 錯誤: {}", toolName, error);
        
        // 提供錯誤處理建議
        String guidance = getErrorGuidance(toolName, error);
        if (!guidance.isEmpty()) {
            log.info("💡 錯誤處理建議: {}", guidance);
        }
    }

    /**
     * 獲取調用統計
     *
     * @return String 調用統計摘要
     */
    public String getCallStatistics() {
        long totalCalls = successfulCalls + failedCalls;
        double successRate = totalCalls > 0 ? (double) successfulCalls / totalCalls * 100 : 0;
        
        return String.format(
            "工具調用統計 - 總計: %d, 成功: %d, 失敗: %d, 成功率: %.1f%%",
            totalCalls, successfulCalls, failedCalls, successRate
        );
    }

    /**
     * 獲取最後調用的工具
     *
     * @return String 最後調用的工具名稱
     */
    public String getLastCalledTool() {
        return lastCalledTool;
    }

    /**
     * 根據工具名稱和錯誤信息提供處理建議
     *
     * @param toolName 工具名稱
     * @param error 錯誤信息
     * @return String 處理建議
     */
    private String getErrorGuidance(String toolName, String error) {
        // Playwright 相關錯誤處理建議
        if (toolName.startsWith("browser_")) {
            if (error.contains("element not found") || error.contains("元素未找到")) {
                return "建議使用 browser_snapshot 檢查頁面狀態，或嘗試更通用的元素選擇器";
            } else if (error.contains("timeout") || error.contains("超時")) {
                return "建議使用 browser_wait_for 等待頁面載入完成，或增加等待時間";
            } else if (error.contains("not clickable") || error.contains("無法點擊")) {
                return "建議先使用 browser_scroll 將元素滾動到可見區域";
            }
        }
        
        // 通用錯誤處理建議
        if (error.contains("connection") || error.contains("連接")) {
            return "檢查 MCP 服務器連接狀態，確認工具服務正常運行";
        } else if (error.contains("permission") || error.contains("權限")) {
            return "檢查工具執行權限，確認必要的系統權限已授予";
        }
        
        return "";
    }

    /**
     * 重置統計計數
     */
    public void resetStatistics() {
        successfulCalls = 0;
        failedCalls = 0;
        lastCalledTool = "";
        log.info("工具調用統計已重置");
    }

    /**
     * 檢查工具調用健康狀態
     *
     * @return boolean 如果成功率低於 60% 則返回 false
     */
    public boolean isToolCallHealthy() {
        long totalCalls = successfulCalls + failedCalls;
        if (totalCalls < 5) {
            return true; // 調用次數太少，不足以判斷
        }
        
        double successRate = (double) successfulCalls / totalCalls;
        return successRate >= 0.6; // 成功率至少 60%
    }
}
