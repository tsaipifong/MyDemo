package com.momo.ltsre.jarvis.controller;

import com.momo.ltsre.jarvis.service.DocumentService;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * RAG (檢索增強生成) 控制器
 * <p>
 * 處理文檔管理和智慧檢索相關的 API 端點
 * </p>
 * 
 * <h3>API 端點：</h3>
 * <ul>
 *   <li>POST /api/documents - 上傳文檔</li>
 *   <li>GET /api/documents/search - 搜尋文檔</li>
 *   <li>DELETE /api/documents/{id} - 刪除文檔</li>
 *   <li>GET /api/documents/stats - 文檔統計</li>
 * </ul>
 *
 * @author JARVIS AI Assistant  
 * @version 1.0
 * @since 2025-08-07
 */
@RestController
@RequestMapping("/api/documents")
@CrossOrigin(origins = "*")  // 允許前端跨域存取
public class DocumentController {

    /** 文檔服務依賴注入 */
    private final DocumentService documentService;

    /**
     * 建構子注入
     *
     * @param documentService 文檔服務實例
     */
    public DocumentController(DocumentService documentService) {
        this.documentService = documentService;
    }

    /**
     * 上傳文檔 API
     * <p>
     * 接收文檔內容並儲存到向量資料庫中
     * </p>
     *
     * @param request 上傳請求，包含文檔內容和元數據
     * @return 上傳結果
     */
    @PostMapping
    public Map<String, Object> uploadDocument(@RequestBody DocumentUploadRequest request) {
        try {
            // 添加文檔到向量儲存
            String documentId = documentService.addDocument(
                request.getContent(), 
                request.getMetadata()
            );
            
            // 回傳成功結果
            return Map.of(
                "success", true,
                "message", "文檔上傳成功",
                "documentId", documentId
            );
        } catch (Exception e) {
            // 回傳錯誤結果
            return Map.of(
                "success", false,
                "message", "文檔上傳失敗: " + e.getMessage()
            );
        }
    }

    /**
     * 搜尋文檔 API
     * <p>
     * 根據查詢文字搜尋相關的文檔片段
     * </p>
     *
     * @param query 搜尋查詢文字
     * @param topK 回傳結果數量 (預設 5)
     * @return 搜尋結果
     */
    @GetMapping("/search")
    public Map<String, Object> searchDocuments(
            @RequestParam String query,
            @RequestParam(defaultValue = "5") int topK) {
        try {
            // 執行文檔搜尋
            var results = documentService.searchDocuments(query, topK);
            
            // 回傳搜尋結果
            return Map.of(
                "success", true,
                "query", query,
                "results", results,
                "count", results.size()
            );
        } catch (Exception e) {
            // 回傳錯誤結果
            return Map.of(
                "success", false,
                "message", "搜尋失敗: " + e.getMessage()
            );
        }
    }

    /**
     * 刪除文檔 API
     * <p>
     * 從向量儲存中刪除指定的文檔
     * </p>
     *
     * @param documentId 文檔 ID
     * @return 刪除結果
     */
    @DeleteMapping("/{documentId}")
    public Map<String, Object> deleteDocument(@PathVariable String documentId) {
        try {
            // 刪除文檔
            boolean success = documentService.deleteDocument(documentId);
            
            if (success) {
                return Map.of(
                    "success", true,
                    "message", "文檔刪除成功",
                    "documentId", documentId
                );
            } else {
                return Map.of(
                    "success", false,
                    "message", "文檔不存在或刪除失敗"
                );
            }
        } catch (Exception e) {
            return Map.of(
                "success", false,
                "message", "刪除失敗: " + e.getMessage()
            );
        }
    }

    /**
     * 文檔統計 API
     * <p>
     * 獲取向量儲存的統計資訊
     * </p>
     *
     * @return 統計資訊
     */
    @GetMapping("/stats")
    public Map<String, Object> getStats() {
        try {
            // 獲取統計資訊
            var stats = documentService.getDocumentStats();
            
            return Map.of(
                "success", true,
                "stats", stats
            );
        } catch (Exception e) {
            return Map.of(
                "success", false,
                "message", "獲取統計失敗: " + e.getMessage()
            );
        }
    }

    /**
     * 文檔上傳請求類別
     * <p>
     * 用於接收前端上傳的文檔數據
     * </p>
     */
    public static class DocumentUploadRequest {
        /** 文檔內容 */
        private String content;
        
        /** 文檔元數據 */
        private Map<String, Object> metadata;

        // 建構子
        public DocumentUploadRequest() {}

        public DocumentUploadRequest(String content, Map<String, Object> metadata) {
            this.content = content;
            this.metadata = metadata;
        }

        // Getter 和 Setter
        public String getContent() { return content; }
        public void setContent(String content) { this.content = content; }

        public Map<String, Object> getMetadata() { return metadata; }
        public void setMetadata(Map<String, Object> metadata) { this.metadata = metadata; }
    }

}
