package com.momo.ltsre.jarvis.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * JARVIS 嵌入模型配置屬性類別
 * <p>
 * 定義嵌入模型的限制參數和文檔處理配置，確保系統不會超出模型能力範圍
 * </p>
 *
 * <h3>配置來源</h3>
 * <ul>
 *   <li>基於 Google Gemini embedding-001 模型規格</li>
 *   <li>Token 限制：2048 tokens/輸入</li>
 *   <li>批次限制：250 輸入/請求，20000 tokens/批次</li>
 *   <li>向量維度：768 維（推薦設置）</li>
 * </ul>
 *
 * @author JARVIS AI Assistant
 * @version 1.0
 * @since 2025-08-07
 */
@ConfigurationProperties(prefix = "jarvis")
public class JarvisEmbeddingProperties {

    /** 嵌入模型相關配置 */
    private final Embedding embedding = new Embedding();
    
    /** 文檔處理相關配置 */
    private final Document document = new Document();

    // Getter 方法
    public Embedding getEmbedding() { return embedding; }
    public Document getDocument() { return document; }

    /**
     * 嵌入模型限制配置
     * <p>
     * 基於 gemini-embedding-001 模型的官方規格設定
     * </p>
     */
    public static class Embedding {
        /** 每個輸入的最大 token 數量 */
        private int maxTokensPerInput = 2048;
        
        /** 每個請求的最大輸入數量 */
        private int maxInputsPerRequest = 250;
        
        /** 批次處理的最大 token 總數 */
        private int maxBatchTokens = 20000;
        
        /** 向量維度大小 */
        private int vectorDimensions = 768;
        
        /** 是否自動截斷超出的內容 */
        private boolean autoTruncate = true;

        // Getter 和 Setter 方法
        public int getMaxTokensPerInput() { return maxTokensPerInput; }
        public void setMaxTokensPerInput(int maxTokensPerInput) { this.maxTokensPerInput = maxTokensPerInput; }

        public int getMaxInputsPerRequest() { return maxInputsPerRequest; }
        public void setMaxInputsPerRequest(int maxInputsPerRequest) { this.maxInputsPerRequest = maxInputsPerRequest; }

        public int getMaxBatchTokens() { return maxBatchTokens; }
        public void setMaxBatchTokens(int maxBatchTokens) { this.maxBatchTokens = maxBatchTokens; }

        public int getVectorDimensions() { return vectorDimensions; }
        public void setVectorDimensions(int vectorDimensions) { this.vectorDimensions = vectorDimensions; }

        public boolean isAutoTruncate() { return autoTruncate; }
        public void setAutoTruncate(boolean autoTruncate) { this.autoTruncate = autoTruncate; }
    }

    /**
     * 文檔分塊處理配置
     * <p>
     * 基於嵌入模型 token 限制設計的文檔分塊策略
     * </p>
     */
    public static class Document {
        /** 每個文檔塊的最大 token 數量（預留緩衝區） */
        private int maxChunkTokens = 1800;
        
        /** 文檔塊之間的重疊 token 數量 */
        private int chunkOverlapTokens = 200;
        
        /** 預估每個 token 對應的字符數 */
        private int estimatedCharsPerToken = 4;
        
        /** 每個文檔塊的最大字符數 */
        private int maxChunkChars = 1500;
        
        /** 文檔塊之間的重疊字符數 */
        private int overlapChars = 200;

        // Getter 和 Setter 方法
        public int getMaxChunkTokens() { return maxChunkTokens; }
        public void setMaxChunkTokens(int maxChunkTokens) { this.maxChunkTokens = maxChunkTokens; }

        public int getChunkOverlapTokens() { return chunkOverlapTokens; }
        public void setChunkOverlapTokens(int chunkOverlapTokens) { this.chunkOverlapTokens = chunkOverlapTokens; }

        public int getEstimatedCharsPerToken() { return estimatedCharsPerToken; }
        public void setEstimatedCharsPerToken(int estimatedCharsPerToken) { this.estimatedCharsPerToken = estimatedCharsPerToken; }

        public int getMaxChunkChars() { return maxChunkChars; }
        public void setMaxChunkChars(int maxChunkChars) { this.maxChunkChars = maxChunkChars; }

        public int getOverlapChars() { return overlapChars; }
        public void setOverlapChars(int overlapChars) { this.overlapChars = overlapChars; }
    }

}
