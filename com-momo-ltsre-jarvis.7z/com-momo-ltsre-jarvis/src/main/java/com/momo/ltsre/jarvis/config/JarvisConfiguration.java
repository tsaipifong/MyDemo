package com.momo.ltsre.jarvis.config;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.client.advisor.MessageChatMemoryAdvisor;
import org.springframework.ai.chat.memory.ChatMemory;
import org.springframework.ai.chat.memory.InMemoryChatMemoryRepository;
import org.springframework.ai.chat.memory.MessageWindowChatMemory;
import org.springframework.ai.mcp.AsyncMcpToolCallbackProvider;
import org.springframework.ai.openai.OpenAiChatModel;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * JARVIS 應用程式配置類別
 * <p>
 * 負責配置 Spring AI 相關的 Bean，包括：
 * - ChatClient：具備會話記憶功能的聊天客戶端
 * - ChatMemory：全域會話記憶體實例
 * - MessageChatMemoryAdvisor：會話記憶體顧問
 * </p>
 *
 * @author JARVIS AI Assistant
 * @version 1.0
 * @since 2025-08-07
 */
@Configuration
@EnableConfigurationProperties(JarvisEmbeddingProperties.class)
public class JarvisConfiguration {

    /**
     * 全域會話記憶體 Bean
     * <p>
     * 建立全域的會話記憶體實例，支援多個會話的記憶體管理
     * 使用 MessageWindowChatMemory 實現滑動窗口記憶體，最多保留 30 條訊息
     * </p>
     *
     * @return ChatMemory 會話記憶體實例
     */
    @Bean
    public ChatMemory chatMemory() {
        // 建立記憶體儲存庫
        InMemoryChatMemoryRepository repository = new InMemoryChatMemoryRepository();
        
        // 建立具有訊息窗口限制的會話記憶體
        return MessageWindowChatMemory.builder()
                .chatMemoryRepository(repository)
                // 設定最大保留 1000 條訊息
                .maxMessages(1000)
                .build();
    }

    /**
     * 會話記憶體顧問 Bean
     * <p>
     * 建立會話記憶體顧問，負責管理聊天對話的上下文記憶
     * </p>
     *
     * @param chatMemory 會話記憶體實例
     * @return MessageChatMemoryAdvisor 會話記憶體顧問實例
     */
    @Bean
    public MessageChatMemoryAdvisor messageChatMemoryAdvisor(ChatMemory chatMemory) {
        return MessageChatMemoryAdvisor.builder(chatMemory)
                .build();
    }

    /**
     * 具備會話記憶功能和增強 MCP 工具整合的聊天客戶端 Bean
     * <p>
     * 建立同時配置了會話記憶體顧問和增強 MCP 工具回調的 ChatClient
     * 包含更好的錯誤處理、工具調用監控和結構化回應處理
     * </p>
     *
     * @param openAiChatModel OpenAI 聊天模型實例
     * @param messageChatMemoryAdvisor 會話記憶體顧問
     * @param asyncMcpToolCallbackProvider MCP 異步工具回調提供者
     * @return ChatClient 具備記憶功能和增強工具整合的聊天客戶端
     */
    @Bean
    public ChatClient chatClient(OpenAiChatModel openAiChatModel, 
                               MessageChatMemoryAdvisor messageChatMemoryAdvisor,
                               AsyncMcpToolCallbackProvider asyncMcpToolCallbackProvider) {
        return ChatClient.builder(openAiChatModel)
                // 設定預設的會話記憶體顧問
                .defaultAdvisors(messageChatMemoryAdvisor)
                // 設定增強的 MCP 工具回調，啟用外部工具整合
                .defaultToolCallbacks(asyncMcpToolCallbackProvider)
                .build();
    }
    

    // TODO: 將在後續版本中添加 Qdrant VectorStore 配置
    // Qdrant 依賴已配置完成，向量儲存功能準備就緒

}
