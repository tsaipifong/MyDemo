package com.momo.ltsre.jarvis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * 主應用程式啟動類別
 * <p>
 * 這是Spring Boot應用程式的主要入口點，負責啟動整個Jarvis AI聊天系統。
 * 該應用程式整合了Google Gemini模型和Qdrant向量資料庫，提供完整的RAG功能。
 * </p>
 *
 * @author Jarvis AI Team
 * @since 1.0.0
 */
@SpringBootApplication
public class ComMomoLtsreJarvisApplication {

	/**
	 * 應用程式主要入口方法
	 * <p>
	 * 啟動Spring Boot應用程式，初始化所有必要的bean和配置。
	 * 包括AI客戶端、向量資料庫連接和Web服務器設定。
	 * </p>
	 *
	 * @param args 命令列參數
	 */
	public static void main(String[] args) {
		SpringApplication.run(ComMomoLtsreJarvisApplication.class, args);
	}

}
