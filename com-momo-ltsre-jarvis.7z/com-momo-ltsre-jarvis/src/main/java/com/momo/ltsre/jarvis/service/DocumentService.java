package com.momo.ltsre.jarvis.service;

import com.momo.ltsre.jarvis.config.JarvisEmbeddingProperties;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * 文檔管理服務類別
 * <p>
 * 負責處理文檔的向量化、儲存和檢索功能，為 RAG 功能提供基礎支援
 * </p>
 * 
 * <h3>主要功能：</h3>
 * <ul>
 *   <li>文檔上傳和預處理</li>
 *   <li>文本向量化</li>
 *   <li>向量儲存到 Qdrant</li>
 *   <li>相似性搜尋</li>
 *   <li>文檔管理</li>
 * </ul>
 *
 * @author JARVIS AI Assistant
 * @version 1.0
 * @since 2025-08-07
 */
@Service
public class DocumentService {

    /** JARVIS 嵌入配置屬性 */
    private final JarvisEmbeddingProperties properties;

    /** 暫時的模擬數據儲存，後續將替換為 Qdrant 向量儲存 */
    private static final String QDRANT_COLLECTION = "jarvis-documents";

    /**
     * 建構子注入配置屬性
     *
     * @param properties JARVIS 嵌入配置
     */
    public DocumentService(JarvisEmbeddingProperties properties) {
        this.properties = properties;
    }

    /**
     * 添加文檔到向量儲存
     * <p>
     * 將文檔內容向量化並儲存到 Qdrant 資料庫中
     * 會根據配置的限制進行文檔分塊處理
     * </p>
     *
     * @param documentContent 文檔內容
     * @param metadata 文檔元數據（如標題、類型、來源等）
     * @return 文檔 ID
     */
    public String addDocument(String documentContent, Map<String, Object> metadata) {
        // 檢查文檔長度並進行分塊處理
        List<String> chunks = splitDocumentIntoChunks(documentContent);
        
        System.out.println("文檔總長度: " + documentContent.length() + " 字符");
        System.out.println("分塊後數量: " + chunks.size() + " 塊");
        System.out.println("最大塊大小限制: " + properties.getDocument().getMaxChunkChars() + " 字符");
        System.out.println("塊重疊大小: " + properties.getDocument().getOverlapChars() + " 字符");
        
        for (int i = 0; i < chunks.size(); i++) {
            String chunk = chunks.get(i);
            System.out.println("塊 " + (i + 1) + " 長度: " + chunk.length() + " 字符");
            System.out.println("預估 Token 數: " + estimateTokenCount(chunk));
        }
        
        // TODO: 實作向量化和儲存邏輯
        // 1. 對每個文檔塊進行向量化
        // 2. 儲存到 Qdrant
        
        // 暫時回傳模擬 ID
        return "doc_" + System.currentTimeMillis();
    }

    /**
     * 將文檔分割成符合模型限制的塊
     * <p>
     * 根據配置的最大塊大小和重疊大小進行智慧分割
     * </p>
     *
     * @param content 原始文檔內容
     * @return 分割後的文檔塊列表
     */
    private List<String> splitDocumentIntoChunks(String content) {
        // TODO: 實作智慧文檔分塊邏輯
        // 您可以在這裡實作您想要的分塊策略
        
        int maxChunkSize = properties.getDocument().getMaxChunkChars();
        int overlapSize = properties.getDocument().getOverlapChars();
        
        // 簡單的分塊實作（暫時）
        List<String> chunks = new java.util.ArrayList<>();
        
        if (content.length() <= maxChunkSize) {
            // 文檔小於最大塊大小，不需要分塊
            chunks.add(content);
        } else {
            // 需要分塊處理
            int start = 0;
            while (start < content.length()) {
                int end = Math.min(start + maxChunkSize, content.length());
                
                // 尋找適當的分割點（避免切斷單詞）
                if (end < content.length()) {
                    // 向後尋找空白字符作為分割點
                    int lastSpace = content.lastIndexOf(' ', end);
                    int lastNewline = content.lastIndexOf('\n', end);
                    int splitPoint = Math.max(lastSpace, lastNewline);
                    
                    if (splitPoint > start) {
                        end = splitPoint;
                    }
                }
                
                chunks.add(content.substring(start, end).trim());
                start = Math.max(start + maxChunkSize - overlapSize, end);
            }
        }
        
        return chunks;
    }

    /**
     * 預估文本的 Token 數量
     * <p>
     * 基於配置的字符/Token 比例進行預估
     * </p>
     *
     * @param text 文本內容
     * @return 預估的 Token 數量
     */
    private int estimateTokenCount(String text) {
        return text.length() / properties.getDocument().getEstimatedCharsPerToken();
    }

    /**
     * 搜尋相關文檔
     * <p>
     * 根據查詢文字搜尋最相關的文檔片段
     * </p>
     *
     * @param query 查詢文字
     * @param topK 回傳的最佳結果數量
     * @return 相關文檔片段列表
     */
    public List<String> searchDocuments(String query, int topK) {
        // 檢查查詢長度是否超出限制
        int queryTokens = estimateTokenCount(query);
        int maxTokens = properties.getEmbedding().getMaxTokensPerInput();
        
        if (queryTokens > maxTokens) {
            System.out.println("警告：查詢長度 (" + queryTokens + " tokens) 超出限制 (" + maxTokens + " tokens)");
            if (properties.getEmbedding().isAutoTruncate()) {
                // 截斷查詢
                int maxChars = maxTokens * properties.getDocument().getEstimatedCharsPerToken();
                query = query.substring(0, Math.min(maxChars, query.length()));
                System.out.println("已自動截斷查詢至: " + query.length() + " 字符");
            }
        }
        
        System.out.println("搜尋查詢: " + query);
        System.out.println("預估 Token 數: " + estimateTokenCount(query));
        System.out.println("請求 " + topK + " 個結果");
        
        // TODO: 實作向量相似性搜尋
        // 1. 將查詢文字向量化
        // 2. 在 Qdrant 中執行相似性搜尋
        // 3. 回傳最相關的文檔片段
        
        // 暫時回傳模擬結果
        return List.of(
            "這是一個相關的文檔片段範例...",
            "另一個可能相關的內容..."
        );
    }

    /**
     * 刪除文檔
     * <p>
     * 從向量儲存中移除指定的文檔
     * </p>
     *
     * @param documentId 文檔 ID
     * @return 是否成功刪除
     */
    public boolean deleteDocument(String documentId) {
        // TODO: 實作文檔刪除邏輯
        System.out.println("準備刪除文檔: " + documentId);
        return true;
    }

    /**
     * 獲取文檔統計資訊
     * <p>
     * 回傳向量儲存中的文檔統計資訊
     * </p>
     *
     * @return 統計資訊
     */
    public Map<String, Object> getDocumentStats() {
        // TODO: 實作統計功能
        return Map.of(
            "totalDocuments", 0,
            "collectionName", QDRANT_COLLECTION,
            "maxTokensPerInput", properties.getEmbedding().getMaxTokensPerInput(),
            "maxChunkSize", properties.getDocument().getMaxChunkChars(),
            "vectorDimensions", properties.getEmbedding().getVectorDimensions(),
            "status", "配置就緒"
        );
    }

}
