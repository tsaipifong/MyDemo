package com.momo.ltsre.jarvis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * 主應用程式測試類別
 * <p>
 * 驗證Spring Boot應用程式能正常載入所有配置和bean
 * </p>
 *
 * @author Jarvis AI Team
 * @since 1.0.0
 */
@SpringBootTest
class ComMomoLtsreJarvisApplicationTests {

	/**
	 * 測試應用程式上下文載入
	 * <p>
	 * 確保所有bean都能正確初始化，包括AI配置和向量資料庫連接
	 * </p>
	 */
	@Test
	void contextLoads() {
		// 這個測試確保Spring Boot應用程式能夠正常啟動
		// 並且所有的bean都能正確初始化
	}

}
