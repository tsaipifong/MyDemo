# GitHub Copilot 指令

## 代碼撰寫標準

使用繁體中文撰寫專案README.md檔案，只針對專案內容說明，且必須包含專案目錄結構；不要無中生有的內容，例如「授權資訊」、「聯絡資訊」。

撰寫專案README.md檔案時，請使用Markdown語法，並且使用標題、清單、程式碼區塊等格式化內容。

程式碼建議或生成都必須包含註解；Java類別必須有類別註解；Java方法必須有方法註解；Java變數必須有變數註解；Java程式碼必須有行內註解；properties屬性必須有屬性註解；不要使用行末註解，改為使用上行註解。

## JARVIS 專案特定指引

### Java 開發規範

1. **註解語言**: 統一使用繁體中文撰寫所有註解
2. **類別註解**: 必須包含功能說明、職責描述和使用場景
3. **方法註解**: 必須說明功能、參數、回傳值和可能的異常
4. **變數註解**: 必須說明變數用途和意義
5. **行內註解**: 解釋關鍵邏輯，不要使用行末註解，改為使用上行註解

### 架構設計原則

1. **分層架構**: Controller → Service → Configuration
2. **響應式程式設計**: 使用 Spring WebFlux 和 Reactor
3. **Spring AI 整合**: 統一的 ChatClient 使用模式
4. **錯誤處理**: 使用統一的 GlobalExceptionHandler
5. **API 設計**: 遵循 RESTful 規範和統一回應格式

### 程式碼範例模板

#### Controller 類別範本
```java
/**
 * [功能]控制器
 * <p>
 * 負責處理[具體功能]相關的HTTP請求
 * </p>
 *
 * @author JARVIS AI Assistant
 * @version 1.0
 * @since 2025-08-07
 */
@RestController
@RequestMapping("/api/[resource]")
public class [Name]Controller {
    
    /** 日誌記錄器 */
    private static final Logger log = LoggerFactory.getLogger([Name]Controller.class);
    
    /** [服務功能]服務依賴 */
    private final [Name]Service [name]Service;
    
    /**
     * 建構子注入依賴
     *
     * @param [name]Service [服務功能]服務實例
     */
    public [Name]Controller([Name]Service [name]Service) {
        this.[name]Service = [name]Service;
    }
}
```

#### Service 類別範本
```java
/**
 * [功能]服務類別
 * <p>
 * 負責處理[具體業務]相關的業務邏輯
 * </p>
 *
 * @author JARVIS AI Assistant
 * @version 1.0
 * @since 2025-08-07
 */
@Service
public class [Name]Service {
    
    /** 日誌記錄器 */
    private static final Logger log = LoggerFactory.getLogger([Name]Service.class);
    
    /** 配置屬性 */
    private final JarvisEmbeddingProperties properties;
    
    /**
     * 建構子注入配置
     *
     * @param properties JARVIS 配置屬性
     */
    public [Name]Service(JarvisEmbeddingProperties properties) {
        this.properties = properties;
    }
}
```

### API 回應格式

所有 API 都應使用統一的回應格式：
```java
public class ApiResponse<T> {
    /** 操作是否成功 */
    private boolean success = true;
    
    /** 回應訊息 */
    private String message = "";
    
    /** 資料內容 */
    private T data;
}
```

### 響應式程式設計模式

- 使用 `Mono<T>` 處理單一結果
- 使用 `Flux<T>` 處理串流資料
- 加上適當的錯誤處理和日誌記錄：
  - `.doOnSuccess()` 成功時記錄
  - `.doOnError()` 錯誤時記錄
  - `.doOnComplete()` 完成時記錄

### 日誌記錄規範

- ERROR: 系統錯誤、異常狀況
- WARN: 業務警告、非預期但可處理的情況
- INFO: 重要業務流程、系統狀態變更
- DEBUG: 詳細執行過程、開發偵錯資訊
- TRACE: 最詳細的執行軌跡

### 配置管理

使用 `@ConfigurationProperties` 進行屬性綁定，並加上完整的屬性註解說明用途、預設值和影響範圍。

### 測試規範

測試方法命名規則: `should_ExpectedBehavior_When_StateUnderTest`

## Spring WebFlux 響應式程式設計最佳實務

### 核心原則

1. **非阻塞 I/O**: 避免任何阻塞操作，包括同步資料庫呼叫、檔案 I/O 或網路請求
2. **響應式流**: 正確使用 `Mono<T>` 和 `Flux<T>` 處理異步資料流
3. **背壓處理**: 適當處理背壓（backpressure）問題，避免記憶體溢出
4. **錯誤處理**: 在響應式鏈中進行錯誤處理，不中斷整個流

### ServerWebExchange 使用模式

#### ✅ 正確的 WebSession 使用方式
```java
@PostMapping("/api/data")
public Flux<String> handleRequest(@RequestBody String request, ServerWebExchange exchange) {
    return exchange.getSession()
        .doOnNext(session -> {
            // 安全檢查，避免重複啟動會話
            if (!session.isStarted()) {
                session.start();
            }
        })
        .flatMapMany(session -> {
            // 取得會話ID用於業務邏輯
            String sessionId = session.getId();
            log.debug("Processing request for session: {}", sessionId);
            
            // 返回響應式流
            return processBusinessLogic(request, sessionId);
        })
        .doOnError(error -> log.error("Request processing failed", error));
}
```

#### ❌ 錯誤的阻塞方式
```java
// 不要這樣做 - 阻塞操作
@PostMapping("/api/data")
public Flux<String> handleRequest(@RequestBody String request, ServerWebExchange exchange) {
    WebSession session = exchange.getSession().block(); // 阻塞！
    String sessionId = session.getId();
    return processBusinessLogic(request, sessionId);
}
```

### 響應式類型選擇指南

#### Mono<T> - 單一結果
```java
/**
 * 處理單一實體的建立
 */
@PostMapping("/api/users")
public Mono<ResponseEntity<User>> createUser(@RequestBody Mono<User> userMono) {
    return userMono
        .flatMap(user -> {
            // 驗證使用者資料
            return validateUser(user);
        })
        .flatMap(user -> {
            // 儲存使用者（非阻塞）
            return userRepository.save(user);
        })
        .map(savedUser -> {
            // 建立成功回應
            return ResponseEntity.status(HttpStatus.CREATED).body(savedUser);
        })
        .onErrorResume(ValidationException.class, ex -> {
            // 處理驗證錯誤
            return Mono.just(ResponseEntity.badRequest().build());
        })
        .doOnSuccess(response -> log.info("User created successfully"))
        .doOnError(error -> log.error("Failed to create user", error));
}
```

#### Flux<T> - 串流資料
```java
/**
 * 處理串流資料查詢
 */
@GetMapping(value = "/api/events", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
public Flux<ServerSentEvent<String>> streamEvents() {
    return eventService.getEventStream()
        .map(event -> {
            // 轉換事件格式
            return ServerSentEvent.<String>builder()
                .id(event.getId())
                .event("data-update")
                .data(event.getData())
                .build();
        })
        .doOnNext(event -> log.debug("Sending event: {}", event.id()))
        .doOnComplete(() -> log.info("Event stream completed"))
        .onErrorResume(error -> {
            // 錯誤處理 - 發送錯誤事件
            log.error("Error in event stream", error);
            return Flux.just(
                ServerSentEvent.<String>builder()
                    .event("error")
                    .data("Stream error occurred")
                    .build()
            );
        });
}
```

### 錯誤處理策略

#### 全域錯誤處理器
```java
/**
 * WebFlux 全域異常處理器
 */
@Component
@Order(-2)
public class GlobalWebExceptionHandler extends AbstractErrorWebExceptionHandler {
    
    public GlobalWebExceptionHandler(ErrorAttributes errorAttributes,
                                   WebProperties webProperties,
                                   ApplicationContext applicationContext) {
        super(errorAttributes, webProperties.getResources(), applicationContext);
    }
    
    @Override
    protected RouterFunction<ServerResponse> getRoutingFunction(ErrorAttributes errorAttributes) {
        return RouterFunctions.route(RequestPredicates.all(), this::renderErrorResponse);
    }
    
    private Mono<ServerResponse> renderErrorResponse(ServerRequest request) {
        Throwable error = getError(request);
        
        if (error instanceof ValidationException) {
            return ServerResponse.badRequest()
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(createErrorResponse("驗證失敗", error.getMessage()));
        }
        
        return ServerResponse.status(HttpStatus.INTERNAL_SERVER_ERROR)
            .contentType(MediaType.APPLICATION_JSON)
            .bodyValue(createErrorResponse("系統錯誤", "請稍後再試"));
    }
    
    private ErrorResponse createErrorResponse(String error, String message) {
        return new ErrorResponse(false, error, message, Instant.now());
    }
}
```

#### 響應式鏈中的錯誤處理
```java
/**
 * 在響應式鏈中處理多種錯誤情況
 */
public Mono<ApiResponse<String>> processWithErrorHandling(String input) {
    return Mono.fromCallable(() -> input)
        .flatMap(this::validateInput)
        .flatMap(this::processBusinessLogic)
        .map(result -> new ApiResponse<>(true, "處理成功", result))
        .onErrorResume(ValidationException.class, ex -> {
            log.warn("輸入驗證失敗: {}", ex.getMessage());
            return Mono.just(new ApiResponse<>(false, "輸入驗證失敗", null));
        })
        .onErrorResume(BusinessException.class, ex -> {
            log.error("業務邏輯錯誤: {}", ex.getMessage());
            return Mono.just(new ApiResponse<>(false, "業務處理失敗", null));
        })
        .onErrorResume(Exception.class, ex -> {
            log.error("系統錯誤", ex);
            return Mono.just(new ApiResponse<>(false, "系統錯誤，請稍後再試", null));
        })
        .doOnSuccess(response -> log.debug("處理完成: {}", response.isSuccess()))
        .doOnError(error -> log.error("未處理的錯誤", error));
}
```

### 記憶體管理和效能最佳化

#### DataBuffer 資源管理
```java
/**
 * 正確處理 DataBuffer 資源
 */
@PostMapping("/api/upload")
public Mono<String> handleFileUpload(@RequestBody Flux<DataBuffer> dataBuffers) {
    return dataBuffers
        .collectList()
        .flatMap(buffers -> {
            try {
                // 處理資料
                String result = processBuffers(buffers);
                return Mono.just(result);
            } finally {
                // 確保釋放資源
                buffers.forEach(DataBufferUtils::release);
            }
        })
        .onErrorResume(error -> {
            log.error("檔案處理失敗", error);
            return Mono.just("處理失敗");
        });
}
```

#### 背壓處理
```java
/**
 * 處理大量資料流的背壓
 */
@GetMapping("/api/data/stream")
public Flux<String> streamLargeDataset() {
    return dataRepository.findAll()
        .buffer(100) // 批次處理，減少記憶體壓力
        .flatMap(batch -> {
            return Flux.fromIterable(batch)
                .map(this::transformData)
                .onBackpressureBuffer(1000) // 設定背壓緩衝區
                .subscribeOn(Schedulers.boundedElastic()); // 使用適當的調度器
        })
        .doOnNext(data -> log.trace("Processed data: {}", data))
        .onErrorResume(error -> {
            log.error("資料流處理錯誤", error);
            return Flux.just("ERROR: 資料流中斷");
        });
}
```

### WebFlux 配置最佳實務

#### Codec 和緩衝區配置
```java
/**
 * WebFlux 自定義配置
 */
@Configuration
@EnableWebFlux
public class WebFluxConfig implements WebFluxConfigurer {
    
    @Override
    public void configureHttpMessageCodecs(ServerCodecConfigurer configurer) {
        // 設定記憶體緩衝區限制
        configurer.defaultCodecs().maxInMemorySize(1024 * 1024); // 1MB
        
        // 啟用敏感資料記錄（僅開發環境）
        configurer.defaultCodecs().enableLoggingRequestDetails(true);
        
        // 自定義 Jackson 配置
        configurer.defaultCodecs().jackson2JsonDecoder(
            new Jackson2JsonDecoder(objectMapper())
        );
    }
    
    @Bean
    public ObjectMapper objectMapper() {
        return JsonMapper.builder()
            .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
            .configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false)
            .build();
    }
    
    @Override
    public void configureBlockingExecution(BlockingExecutionConfigurer configurer) {
        // 配置阻塞操作的執行器（如果必須使用阻塞程式碼）
        configurer.setExecutor(Executors.newVirtualThreadPerTaskExecutor());
    }
}
```

### 測試策略

#### WebTestClient 整合測試
```java
/**
 * WebFlux 控制器整合測試
 */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class ChatControllerTest {
    
    @Autowired
    private WebTestClient webTestClient;
    
    @Test
    void should_ReturnStreamResponse_When_ValidChatRequest() {
        String testMessage = "Hello, AI!";
        
        webTestClient
            .post()
            .uri("/chat")
            .contentType(MediaType.TEXT_PLAIN)
            .bodyValue(testMessage)
            .exchange()
            .expectStatus().isOk()
            .expectHeader().contentType(MediaType.TEXT_PLAIN)
            .returnResult(String.class)
            .getResponseBody()
            .as(StepVerifier::create)
            .expectNextMatches(response -> !response.isEmpty())
            .thenCancel()
            .verify();
    }
    
    @Test
    void should_HandleError_When_InvalidRequest() {
        webTestClient
            .post()
            .uri("/chat")
            .contentType(MediaType.TEXT_PLAIN)
            .bodyValue("")
            .exchange()
            .expectStatus().isBadRequest();
    }
}
```

#### 響應式服務單元測試
```java
/**
 * 響應式服務測試
 */
class ReactiveServiceTest {
    
    @Test
    void should_ProcessSuccessfully_When_ValidInput() {
        ReactiveService service = new ReactiveService();
        String input = "test input";
        
        StepVerifier.create(service.processAsync(input))
            .expectNextMatches(result -> result.contains("processed"))
            .verifyComplete();
    }
    
    @Test
    void should_HandleError_When_InvalidInput() {
        ReactiveService service = new ReactiveService();
        String invalidInput = "";
        
        StepVerifier.create(service.processAsync(invalidInput))
            .expectError(ValidationException.class)
            .verify();
    }
}
```

### 監控和可觀測性

#### Actuator 整合
```java
/**
 * 自定義健康檢查
 */
@Component
public class ReactiveHealthIndicator implements ReactiveHealthIndicator {
    
    @Override
    public Mono<Health> health() {
        return checkExternalService()
            .map(isHealthy -> {
                if (isHealthy) {
                    return Health.up()
                        .withDetail("external-service", "可用")
                        .build();
                } else {
                    return Health.down()
                        .withDetail("external-service", "不可用")
                        .build();
                }
            })
            .timeout(Duration.ofSeconds(5))
            .onErrorReturn(Health.down()
                .withDetail("error", "健康檢查超時")
                .build());
    }
    
    private Mono<Boolean> checkExternalService() {
        // 實作外部服務健康檢查邏輯
        return Mono.just(true);
    }
}
```

---

遵循以上指引確保 JARVIS 專案保持一致的高品質代碼標準和響應式程式設計最佳實務。
