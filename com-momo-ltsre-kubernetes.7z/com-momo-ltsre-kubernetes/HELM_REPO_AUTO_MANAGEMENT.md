# Helm 倉庫自動管理功能

## 更新日期
2025-11-18

## 問題發現
用戶在使用 `helmInstall` 時,如果使用類似 `bitnami/nginx` 這樣的 chart 名稱,但系統中沒有添加過 `bitnami` 倉庫,會導致安裝失敗。

## 解決方案
新增自動 Helm 倉庫管理功能,在安裝 chart 前自動檢查並添加所需的倉庫。

## 新增功能

### 1. ensureHelmRepo(String repoName)
**功能**: 確保指定的 Helm 倉庫已添加

**支持的倉庫**:
```java
Map<String, String> repoUrls = new HashMap<>();
repoUrls.put("bitnami", "https://charts.bitnami.com/bitnami");
repoUrls.put("prometheus-community", "https://prometheus-community.github.io/helm-charts");
repoUrls.put("grafana", "https://grafana.github.io/helm-charts");
repoUrls.put("stable", "https://charts.helm.sh/stable");
repoUrls.put("ingress-nginx", "https://kubernetes.github.io/ingress-nginx");
repoUrls.put("jetstack", "https://charts.jetstack.io");
repoUrls.put("elastic", "https://helm.elastic.co");
```

**工作流程**:
1. 檢查倉庫是否已存在 (`helm repo list`)
2. 如果不存在,添加倉庫 (`helm repo add <name> <url>`)
3. 更新倉庫索引 (`helm repo update <name>`)

**錯誤處理**:
- 如果添加失敗,僅記錄警告,不中斷安裝流程
- 允許用戶使用本地 chart 或未知倉庫

### 2. extractRepoName(String chart)
**功能**: 從 chart 名稱中提取倉庫前綴

**範例**:
- `bitnami/nginx` → `bitnami`
- `prometheus-community/prometheus` → `prometheus-community`
- `./my-chart` → `null` (本地 chart)
- `mychart` → `null` (無倉庫前綴)

### 3. helmInstall 增強
在原有的 `helmInstall` 方法中,添加了自動倉庫檢查:

```java
// 如果 chart 包含倉庫前綴(例如:bitnami/nginx),自動添加該倉庫
String repoName = extractRepoName(chart);
if (repoName != null) {
    log.info("檢測到倉庫前綴: {}, 自動添加倉庫", repoName);
    ensureHelmRepo(repoName);
}
```

## 使用範例

### 範例 1: 首次使用 bitnami chart
```java
// 用戶請求
helmInstall("my-nginx", "bitnami/nginx", "web", "");

// 系統自動執行:
// 1. 檢測到 bitnami 倉庫前綴
// 2. 執行: helm repo list (檢查是否已存在)
// 3. 執行: helm repo add bitnami https://charts.bitnami.com/bitnami
// 4. 執行: helm repo update bitnami
// 5. 執行: helm install my-nginx bitnami/nginx -n web --create-namespace
```

### 範例 2: 使用已存在的倉庫
```java
// 用戶請求
helmInstall("my-mysql", "bitnami/mysql", "database", "");

// 系統自動執行:
// 1. 檢測到 bitnami 倉庫前綴
// 2. 執行: helm repo list (發現已存在)
// 3. 跳過添加,直接安裝
// 4. 執行: helm install my-mysql bitnami/mysql -n database --create-namespace
```

### 範例 3: 使用本地 chart
```java
// 用戶請求
helmInstall("my-app", "./my-custom-chart", "default", "");

// 系統自動執行:
// 1. 檢測無倉庫前綴
// 2. 跳過倉庫檢查
// 3. 執行: helm install my-app ./my-custom-chart -n default --create-namespace
```

### 範例 4: 使用 prometheus-community
```java
// 用戶請求
helmInstall("monitoring", "prometheus-community/prometheus", "monitoring", "");

// 系統自動執行:
// 1. 檢測到 prometheus-community 倉庫前綴
// 2. 執行: helm repo add prometheus-community https://prometheus-community.github.io/helm-charts
// 3. 執行: helm repo update prometheus-community
// 4. 執行: helm install monitoring prometheus-community/prometheus -n monitoring --create-namespace
```

## 日誌輸出

### 成功添加倉庫
```
[INFO] 檢測到倉庫前綴: bitnami, 自動添加倉庫
[INFO] 添加 Helm 倉庫: bitnami -> https://charts.bitnami.com/bitnami
[INFO] 更新 Helm 倉庫: bitnami
[INFO] Helm 倉庫 bitnami 添加成功
[INFO] 執行 Helm install: helm install my-nginx bitnami/nginx -n web --create-namespace --output json
```

### 倉庫已存在
```
[INFO] 檢測到倉庫前綴: bitnami, 自動添加倉庫
[DEBUG] Helm 倉庫 bitnami 已存在
[INFO] 執行 Helm install: helm install my-nginx bitnami/nginx -n web --create-namespace --output json
```

### 未知倉庫
```
[DEBUG] 未知的倉庫名稱: my-custom-repo, 跳過自動添加
[INFO] 執行 Helm install: helm install my-app my-custom-repo/chart -n default --create-namespace --output json
```

## 優點

### 1. 用戶體驗改善
- ✅ 無需手動執行 `helm repo add` 命令
- ✅ 首次使用 chart 時自動配置
- ✅ 減少配置步驟,降低使用門檻

### 2. 錯誤預防
- ✅ 避免 "chart not found" 錯誤
- ✅ 自動處理倉庫依賴
- ✅ 提供清晰的日誌追蹤

### 3. 智能化
- ✅ 自動識別 chart 格式
- ✅ 區分遠程倉庫和本地 chart
- ✅ 支持常見的 Helm 倉庫

### 4. 容錯性
- ✅ 添加失敗不中斷流程
- ✅ 支持未知倉庫
- ✅ 兼容現有功能

## 支持的常用倉庫

| 倉庫名稱 | URL | 常用 Charts |
|---------|-----|------------|
| bitnami | https://charts.bitnami.com/bitnami | nginx, mysql, postgresql, redis, mongodb, kafka |
| prometheus-community | https://prometheus-community.github.io/helm-charts | prometheus, alertmanager, kube-state-metrics |
| grafana | https://grafana.github.io/helm-charts | grafana, loki, tempo |
| stable | https://charts.helm.sh/stable | 舊版官方穩定倉庫 |
| ingress-nginx | https://kubernetes.github.io/ingress-nginx | ingress-nginx |
| jetstack | https://charts.jetstack.io | cert-manager |
| elastic | https://helm.elastic.co | elasticsearch, kibana, filebeat |

## 擴展性

要添加新的倉庫,只需在 `ensureHelmRepo` 方法中添加映射:

```java
repoUrls.put("新倉庫名", "https://新倉庫URL");
```

範例:
```java
repoUrls.put("hashicorp", "https://helm.releases.hashicorp.com");
repoUrls.put("gitlab", "https://charts.gitlab.io");
```

## 測試建議

### 測試 1: 首次使用倉庫
```bash
# 清理所有倉庫
helm repo remove bitnami

# 安裝 chart (應自動添加倉庫)
installMyK8sHelmChart(
  releaseName: "test-nginx",
  chart: "bitnami/nginx",
  namespace: "test",
  values: ""
)

# 驗證倉庫已添加
helm repo list
```

### 測試 2: 多個倉庫
```bash
# 安裝不同倉庫的 charts
installMyK8sHelmChart("test-nginx", "bitnami/nginx", "test", "")
installMyK8sHelmChart("test-prometheus", "prometheus-community/prometheus", "monitoring", "")
installMyK8sHelmChart("test-grafana", "grafana/grafana", "monitoring", "")

# 驗證所有倉庫都已添加
helm repo list
```

### 測試 3: 本地 chart
```bash
# 使用本地 chart (不應添加倉庫)
installMyK8sHelmChart("test-local", "./my-chart", "test", "")

# 驗證沒有新增倉庫
helm repo list
```

## 已知限制

1. **未知倉庫**: 如果用戶使用不在預定義列表中的倉庫(例如: `my-private-repo/chart`),需要用戶手動添加
2. **倉庫認證**: 目前不支持需要認證的私有倉庫
3. **倉庫別名**: 用戶自定義的倉庫別名無法自動識別

## 未來改進建議

1. **私有倉庫支持**: 添加用戶名/密碼或 token 認證
2. **倉庫配置文件**: 允許用戶自定義倉庫映射
3. **倉庫健康檢查**: 檢查倉庫 URL 是否可訪問
4. **倉庫緩存**: 避免重複的倉庫檢查

## 總結

✅ **功能完成**: Helm 倉庫自動管理
✅ **編譯成功**: BUILD SUCCESS
✅ **用戶友好**: 無需手動配置倉庫
✅ **智能化**: 自動識別和處理
✅ **容錯性**: 失敗不中斷流程
✅ **可擴展**: 易於添加新倉庫

---

**開發完成時間**: 2025-11-18 11:39
**編譯狀態**: BUILD SUCCESS
