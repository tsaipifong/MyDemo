# Kubernetes MCP Server

基於 Spring AI MCP Server 框架和 Kubernetes Java Client 的 Kubernetes 操作服務。

## 專案說明

這是一個 Model Context Protocol (MCP) 服務器,提供透過 MCP 協議操作 Kubernetes 集群的能力。使用 Spring Boot 3.4.10 和 Spring AI 1.0.3 構建,整合 Kubernetes Java Client 22.0.0 實現完整的 Kubernetes 操作支援,包括資源監控、日誌查詢、命令執行、Helm 管理等功能。

### 核心功能

- ✅ **Pod 管理**: 列表、詳情、日誌、刪除、命令執行、運行新 Pod
- ✅ **Deployment 管理**: 列表、詳情、刪除、縮放
- ✅ **資源監控**: Pod/Node Metrics (CPU/Memory 使用率)
- ✅ **事件查詢**: 集群事件監控
- ✅ **節點管理**: 節點列表、狀態查詢、Metrics 統計、系統日誌
- ✅ **通用資源操作**: 支援任意 Kubernetes 資源類型 (CRUD)
- ✅ **配置管理**: Kubeconfig 查看、上下文列表
- ✅ **Helm 支援**: Chart 安裝/卸載/列表,自動倉庫管理

## 專案目錄結構

```text
com-momo-ltsre-kubernetes/
├── src/
│   ├── main/
│   │   ├── java/com/momo/ltsre/kubernetes/
│   │   │   ├── config/                           # 配置層
│   │   │   │   ├── KubernetesClientConfig.java   # Kubernetes 客戶端配置
│   │   │   │   └── McpServerConfig.java          # MCP Server 配置
│   │   │   ├── service/                          # 服務層 (業務邏輯)
│   │   │   │   └── K8sOperationService.java      # Kubernetes 操作服務
│   │   │   ├── mcp/                              # MCP 層 (@Tool 註解)
│   │   │   │   └── McpK8sToolsService.java       # MCP 工具服務 (58 個工具)
│   │   │   └── KubernetesMcpServerApplication.java # 主程式
│   │   └── resources/
│   │       └── application.properties            # 應用配置
│   └── test/java/                                # 測試代碼
├── pom.xml                                       # Maven 配置
└── README.md                                     # 本文件
```

## 架構設計

### 三層架構

1. **Infrastructure 層** (`config/KubernetesClientConfig.java`)
   - 負責初始化 Kubernetes Java Client
   - 提供 CoreV1Api, AppsV1Api, BatchV1Api, NetworkingV1Api 等 Bean
   - 支援多種認證方式 (kubeconfig, in-cluster, default)

2. **Service 層** (`service/K8sOperationService.java`)
   - 封裝 Kubernetes API 調用的業務邏輯
   - 處理數據轉換 (V1Pod → PodInfo, V1Deployment → DeploymentInfo)
   - 實現錯誤處理和日誌記錄

3. **MCP 層** (`mcp/McpK8sToolsService.java`)
   - 使用 `@Tool` 註解暴露 MCP 工具
   - 將 Service 層方法包裝為 MCP 協議可調用的工具
   - 返回 JSON 格式的統一響應

### 數據流

MCP Client (VS Code Copilot)
  ↓ MCP Protocol
McpK8sToolsService (@Tool methods)
  ↓ Java Method Call
K8sOperationService (Business Logic)
  ↓ Kubernetes API
Kubernetes Java Client (CoreV1Api, AppsV1Api)
  ↓ HTTP/REST
Kubernetes API Server

## 技術棧

| 組件 | 版本 | 用途 |
|------|------|------|
| Java | 21 | 開發語言 |
| Spring Boot | 3.4.11 | 應用框架 |
| Spring AI | 1.0.3 | MCP Server 支援 |
| Kubernetes Java Client | 22.0.0 ⭐ | Kubernetes API 客戶端 (支援 K8s 1.31) |
| Lombok | Latest | 簡化代碼 |
| Jackson | Latest | JSON 處理 |

**重要版本說明**:

- Kubernetes Client 22.0.0 支援 Kubernetes 1.31 API,包括 `userNamespaces` 等新特性
- 升級原因: 21.0.1 版本在反序列化 K8s 1.31 資源時會拋出 UnrecognizedPropertyException

## 功能列表

### Pod 操作

- ✅ `listPods` - 列出指定命名空間的 Pod
- ✅ `listAllPods` - 列出所有命名空間的 Pod
- ✅ `getPodLogs` - 獲取 Pod 日誌
- ✅ `deletePod` - 刪除 Pod

### Deployment 操作

- ✅ `listDeployments` - 列出 Deployment
- ✅ `getDeployment` - 獲取 Deployment 詳情
- ✅ `deleteDeployment` - 刪除 Deployment
- ✅ `scaleDeployment` - 縮放 Deployment 副本數

### 命名空間操作

- ✅ `listNamespaces` - 列出所有命名空間

### 🆕 Patch 資源操作

- ✅ `patchResource` - 部分更新 Kubernetes 資源
  - 支援三種 Patch 格式: JSON Patch, Merge Patch, Strategic Merge Patch
  - 範例: `patchResource("v1", "Pod", "default", "nginx", "{\"metadata\":{\"labels\":{\"env\":\"prod\"}}}", "application/merge-patch+json")`

### 🆕 Service 操作

- ✅ `listServices` - 列出指定命名空間的 Service
- ✅ `listAllServices` - 列出所有命名空間的 Service
- ✅ `getService` - 獲取 Service 詳情 (包含 ClusterIP, Ports, Endpoints)
- ✅ `deleteService` - 刪除 Service

### 🆕 檔案複製操作

- ✅ `copyFromPod` - 從 Pod 複製檔案到本地
  - 範例: `copyFromPod("default", "nginx-pod", "nginx", "/var/log/nginx/access.log", "C:/logs/")`
  - 支援下載日誌、配置檔案、備份等
  
- ✅ `copyToPod` - 從本地複製檔案到 Pod
  - 範例: `copyToPod("C:/config/app.conf", "default", "app-pod", "app", "/etc/app/config/")`
  - 支援上傳配置、腳本、資料檔案等

### 🆕 ConfigMap 操作

- ✅ `listConfigMaps` - 列出 ConfigMap (支援標籤選擇器)
- ✅ `getConfigMap` - 獲取 ConfigMap 詳情 (含所有 key-value 數據)
- ✅ `createConfigMap` - 創建 ConfigMap
- ✅ `deleteConfigMap` - 刪除 ConfigMap

### 🆕 Secret 操作

- ✅ `listSecrets` - 列出 Secret (支援標籤選擇器)
- ✅ `getSecret` - 獲取 Secret 詳情 (含 base64 編碼數據)
- ✅ `createSecret` - 創建 Secret (自動 base64 編碼)
- ✅ `deleteSecret` - 刪除 Secret

### 🆕 Job 操作

- ✅ `listJobs` - 列出 Job (支援標籤選擇器)
- ✅ `getJob` - 獲取 Job 詳情 (含執行狀態、完成時間)
- ✅ `deleteJob` - 刪除 Job

### 🆕 CronJob 操作

- ✅ `listCronJobs` - 列出 CronJob
- ✅ `getCronJob` - 獲取 CronJob 詳情 (含排程、最後執行時間)
- ✅ `deleteCronJob` - 刪除 CronJob

### 🆕 Ingress 操作

- ✅ `listIngresses` - 列出 Ingress (HTTP/HTTPS 路由規則)
- ✅ `getIngress` - 獲取 Ingress 詳情 (含 Rules, TLS 配置)
- ✅ `deleteIngress` - 刪除 Ingress

### 🆕 PersistentVolumeClaim 操作

- ✅ `listPVCs` - 列出 PVC (持久化存儲聲明)
- ✅ `getPVC` - 獲取 PVC 詳情 (含容量、狀態、綁定的 PV)
- ✅ `deletePVC` - 刪除 PVC

### 🆕 StatefulSet 操作

- ✅ `listStatefulSets` - 列出 StatefulSet (有狀態應用)
- ✅ `getStatefulSet` - 獲取 StatefulSet 詳情 (含副本狀態)
- ✅ `deleteStatefulSet` - 刪除 StatefulSet
- ✅ `scaleStatefulSet` - 縮放 StatefulSet 副本數

### 🆕 通用資源操作 (Dynamic Client)

> 基於 DynamicKubernetesApi 實作,支援操作任意 Kubernetes 資源類型

- ✅ `listResources` - 列出任意類型資源 (支援 label selector)
  - 範例: `listResources("v1", "Service", "default", "app=nginx")`
  - 支援 namespaced 和 cluster-scoped 資源
  - 自動處理 apiVersion 解析 (例如: "v1", "apps/v1", "networking.k8s.io/v1")

- ✅ `getResource` - 獲取單個資源詳情
  - 範例: `getResource("v1", "ConfigMap", "default", "my-config")`
  - 返回完整 YAML 內容和元數據

- ✅ `createOrUpdateResource` - 創建或更新資源 (從 YAML)
  - 自動檢測資源是否存在
  - 存在則更新,否則創建
  - 支援所有標準 Kubernetes 資源和 CRD

- ✅ `deleteResource` - 刪除任意資源
  - 範例: `deleteResource("v1", "Secret", "default", "my-secret")`
  - 支援 cluster-scoped 資源刪除

**支援的資源類型:**

- 核心資源: Pod, Service, ConfigMap, Secret, Namespace, Node 等
- 應用資源: Deployment, StatefulSet, DaemonSet, ReplicaSet 等
- 網路資源: Ingress, NetworkPolicy 等
- 儲存資源: PersistentVolume, PersistentVolumeClaim 等
- RBAC資源: Role, ClusterRole, RoleBinding, ClusterRoleBinding 等
- **自定義資源 (CRD):** 完整支援

詳細說明請參閱: [動態資源操作文檔](../docs/DYNAMIC_RESOURCE_OPERATIONS.md)

### 🆕 節點日誌與統計 (Kubelet API Proxy)

> 通過 Kubernetes API Server 代理訪問 Kubelet API,獲取節點級別的系統信息

- ✅ `getNodeLog` - 獲取節點系統日誌
  - 範例: `getNodeLog("worker-node-1", "kubelet", 100)`
  - 支援路徑: kubelet, syslog, /var/log/kubelet.log 等
  - 支援 tailLines 參數限制返回行數

- ✅ `getNodeStats` - 獲取節點詳細統計信息
  - 範例: `getNodeStats("worker-node-1")`
  - 返回 JSON 格式的完整統計數據
  - 包含: CPU、內存、文件系統、網絡、Runtime 等指標

**功能特性:**

- 直接訪問 Kubelet API (通過 API Server 代理)
- 獲取比 Metrics Server 更詳細的節點信息
- 支援日誌查詢和統計數據獲取
- 適用於故障診斷和性能分析

## 環境要求

### 必要條件

- Java 21 或更高版本
- Maven 3.6+ 或 Gradle 7+
- 可訪問的 Kubernetes 集群
- Kubeconfig 文件 (通常位於 `~/.kube/config`)

### 可選條件

- Docker (用於容器化部署)
- Kubernetes 集群管理權限 (用於完整功能測試)

## 快速開始

### 1. 編譯專案

```bash
# 使用 Maven 編譯
mvn clean package

# 或使用 Maven Wrapper
./mvnw clean package
```

### 2. 配置 Kubernetes

確保您的 kubeconfig 文件配置正確：

```powershell
# 檢查當前上下文
kubectl config current-context

# 檢查集群連接
kubectl cluster-info

# 測試 API 訪問
kubectl get nodes
```

### 3. 運行服務

```powershell
# 方式 1: 使用 Maven
mvn spring-boot:run

# 方式 2: 運行 JAR
java -jar target/kubernetes-mcp-server-1.0.0.jar

# 方式 3: 指定自定義配置
java -jar target/kubernetes-mcp-server-1.0.0.jar --kubernetes.config.path=/path/to/kubeconfig
```

### 4. 驗證服務

服務啟動後，訪問以下端點：

- **MCP SSE 端點**: `http://localhost:8080/sse`
- **健康檢查**: `http://localhost:8080/actuator/health` (如果啟用了 Actuator)

## 配置說明

### application.properties

```properties
# 服務器端口
server.port=8080

# MCP Server 配置
spring.ai.mcp.server.enabled=true
spring.ai.mcp.server.name=Kubernetes Remote Command Execution Server
spring.ai.mcp.server.capabilities.tool=true

# Kubernetes 配置
# kubernetes.config.path=${user.home}/.kube/config  # 可選：自定義 kubeconfig 路徑
kubernetes.default.namespace=default
kubernetes.request.timeout=30
```

### 認證配置

支援三種認證方式：

1. **Kubeconfig 文件** (推薦)

   ```properties
   kubernetes.config.path=/path/to/kubeconfig
   ```

2. **默認配置** (自動檢測 `~/.kube/config`)

   ```properties
   # 不設置 kubernetes.config.path
   ```

3. **In-Cluster 配置** (運行在 Pod 內)
   - 自動使用 ServiceAccount Token
   - 自動檢測 Kubernetes API Server 地址

## 使用範例

### 在 VS Code 中使用

1. 在 `mcp.json` 中添加配置：

```json
{
  "mcpServers": {
    "kubernetes-mcp-server": {
      "type": "sse",
      "url": "http://localhost:8080/sse",
      "description": "Kubernetes operations via MCP"
    }
  }
}
```

1. 重新載入 VS Code 配置

1. 在 Copilot Chat 中使用：

   ```text
   @workspace 列出 default 命名空間的所有 Pod

   @workspace 獲取 nginx-deployment 的日誌

   @workspace 將 nginx-deployment 縮放到 5 個副本
   ```

### 工具調用範例

#### 列出 Pod

```json
{
  "tool": "listPods",
  "parameters": {
    "namespace": "default",
    "labelSelector": "app=nginx"
  }
}
```

#### 獲取日誌

```json
{
  "tool": "getPodLogs",
  "parameters": {
    "namespace": "default",
    "podName": "nginx-pod-12345",
    "containerName": "nginx",
    "tailLines": 100
  }
}
```

#### 縮放 Deployment

```json
{
  "tool": "scaleDeployment",
  "parameters": {
    "namespace": "default",
    "deploymentName": "nginx-deployment",
    "replicas": 3
  }
}
```

#### 獲取 Node Metrics ⭐ NEW

```json
{
  "tool": "topMyK8sNodes",
  "parameters": {}
}
```

**輸出範例**:

```text
🖥️ Node Metrics:

myvm001
  CPU: 0m (0%)
  Memory: 2171Mi (44%)

myvm002
  CPU: 0m (0%)
  Memory: 1926Mi (39%)

myvm003
  CPU: 0m (0%)
  Memory: 1996Mi (40%)
...
```

#### 獲取 Pod Metrics ⭐ NEW

```json
{
  "tool": "topMyK8sPods",
  "parameters": {
    "namespace": "kube-system"
  }
}
```

**輸出範例**:

```text
📊 Pod Metrics (kube-system):

calico-kube-controllers-5d9d444584-p889h
  CPU: 0m
  Memory: 20Mi

metrics-server-99c95ff74-lw7qh
  CPU: 0m
  Memory: 21Mi
...
```

### Metrics 功能先決條件

要使用 `topMyK8sNodes` 和 `topMyK8sPods` 工具,必須:

1. ✅ 在 Kubernetes 集群中部署 Metrics Server
2. ✅ 確保節點 IP 配置正確 (每個節點 INTERNAL-IP 唯一)

**詳細指南**: 參考 [Metrics Server 部署指南](../docs/METRICS_SERVER_SETUP.md) 和 [基礎設施故障排除](../docs/INFRASTRUCTURE_TROUBLESHOOTING.md)

## 開發指南

### 添加新工具

1. 在 `K8sOperationService` 中添加業務邏輯方法
2. 在 `McpK8sToolsService` 中添加 `@Tool` 註解的方法
3. 重新編譯並運行

範例：

```java
// 1. Service 層
public List<ServiceInfo> listServices(String namespace) throws ApiException {
    // 實現邏輯
}

// 2. MCP 層
@Tool(description = "列出 Service")
public String listServices(
    @ToolParam(description = "命名空間") String namespace
) {
    // 調用 Service 層並返回 JSON
}
```

### 調試技巧

```properties
# 啟用詳細日誌
logging.level.com.momo.ltsre.kubernetes=DEBUG
logging.level.io.kubernetes.client=DEBUG
logging.level.org.springframework.ai=DEBUG
```

## 故障排查

### 常見問題

1. **無法連接到 Kubernetes 集群**
   - 檢查 kubeconfig 文件路徑
   - 驗證集群網絡連接
   - 確認認證憑證有效

2. **工具調用失敗**
   - 檢查日誌中的詳細錯誤信息
   - 驗證參數格式是否正確
   - 確認有足夠的 RBAC 權限

3. **MCP 客戶端無法連接**
   - 確認服務運行在正確的端口 (10011)
   - 檢查防火牆設置
   - 驗證 MCP 端點 URL 配置

### 日誌查看

```powershell
# 查看應用日誌
tail -f logs/kubernetes-mcp-server.log

# 查看 Spring Boot 日誌
# 輸出在控制台
```

## 版本歷史

### v1.1.0 (2024-11-19)

- ✅ 支援 Node/Pod Metrics (CPU/Memory 使用率)
- ✅ 升級 Kubernetes Java Client 至 22.0.0 (支援 K8s 1.31)
- ✅ 新增 `topMyK8sNodes` 工具 (獲取所有節點或單一節點指標)
- ✅ 新增 `topMyK8sPods` 工具 (獲取 Pod 資源使用率)
- ✅ 新增 Service 操作 (list, listAll, get, delete)
- ✅ 新增檔案複製操作 (copyFromPod, copyToPod)
- ✅ 新增 ConfigMap/Secret 管理 (CRUD 操作)
- ✅ 新增 Job/CronJob 操作
- ✅ 新增 Ingress/PVC/StatefulSet 管理
- ✅ 新增通用資源操作 (Dynamic Client)
- ✅ 新增節點日誌與統計功能
- 📝 完善基礎設施文檔 (節點 IP 配置問題)

### v1.0.0 (2024-11-17)

- ✅ 初始版本發布
- ✅ 支援 Pod 基本操作 (list, logs, delete)
- ✅ 支援 Deployment 操作 (list, get, delete, scale)
- ✅ 支援命名空間列舉
- ✅ 完整的三層架構實現
- ✅ MCP 協議集成

## 技術支援

### 相關資源

- [Spring AI MCP Server 文檔](https://github.com/spring-projects/spring-ai)
- [Kubernetes Java Client](https://github.com/kubernetes-client/java)
- [Model Context Protocol](https://modelcontextprotocol.io/)

### 團隊

- pf2tsai
- 版本: 1.0.0
- 日期: 2024-11-19
