# Node Log 和 Stats 功能實作說明

## 概述

本文檔說明 `getNodeLog()` 和 `getNodeStats()` 兩個方法的實作細節。這兩個方法通過 **Kubernetes API Server 代理** 訪問 **Kubelet API**,提供節點級別的日誌查詢和詳細統計信息。

## 技術背景

### 為何需要代理訪問?

Kubelet API 是 Kubernetes 節點代理的 API 接口,提供以下功能:
- 節點系統日誌 (`/logs` 端點)
- 節點統計信息 (`/stats/summary` 端點)
- Pod metrics 和容器 metrics

然而,Kubelet API 通常不直接對外暴露。Kubernetes API Server 提供了 **代理機制**,允許通過 API Server 間接訪問 Kubelet API。

### 代理路徑格式

```
/api/v1/nodes/{nodeName}/proxy/{kubelet-endpoint}
```

範例:
- 獲取日誌: `/api/v1/nodes/worker-1/proxy/logs/kubelet`
- 獲取統計: `/api/v1/nodes/worker-1/proxy/stats/summary`

## 實作細節

### 1. getNodeLog() 方法

#### 功能描述

獲取節點上的系統日誌檔案,如 kubelet.log、syslog 等。

#### 方法簽名

```java
public String getNodeLog(String nodeName, String query, Integer tailLines) throws ApiException
```

#### 參數說明

- `nodeName`: 節點名稱 (必需)
- `query`: 日誌路徑或名稱 (可選,預設為 "kubelet")
  - 支援: `kubelet`, `syslog`, `/var/log/kubelet.log` 等
- `tailLines`: 返回最後 N 行 (可選)

#### 實作邏輯

```java
// 1. 構建代理路徑
String logPath = query != null && !query.isEmpty() ? query : "kubelet";
if (!logPath.startsWith("/")) {
    logPath = "/" + logPath;
}
String proxyPath = "/api/v1/nodes/" + nodeName + "/proxy/logs" + logPath;

// 2. 添加查詢參數
String fullUrl = apiClient.getBasePath() + proxyPath;
if (tailLines != null && tailLines > 0) {
    fullUrl += "?tailLines=" + tailLines;
}

// 3. 構建 HTTP 請求
okhttp3.Request request = new okhttp3.Request.Builder()
    .url(fullUrl)
    .get()
    .build();

// 4. 執行請求
okhttp3.Response response = apiClient.getHttpClient().newCall(request).execute();

// 5. 處理響應
if (!response.isSuccessful()) {
    throw new ApiException(response.code(), "無法獲取節點日誌");
}
return response.body().string();
```

#### 使用範例

```java
// 獲取 kubelet 日誌的最後 100 行
String logs = k8sOperationService.getNodeLog("worker-1", "kubelet", 100);

// 獲取 syslog
String syslog = k8sOperationService.getNodeLog("worker-1", "syslog", null);

// 獲取特定路徑的日誌
String customLog = k8sOperationService.getNodeLog("worker-1", "/var/log/messages", 50);
```

### 2. getNodeStats() 方法

#### 功能描述

獲取節點的詳細資源統計信息,比 Metrics Server 提供的數據更加豐富。

#### 方法簽名

```java
public String getNodeStats(String nodeName) throws ApiException
```

#### 參數說明

- `nodeName`: 節點名稱 (必需)

#### 返回數據結構

返回 JSON 格式的統計數據,包含:

```json
{
  "node": {
    "nodeName": "worker-1",
    "cpu": {
      "time": "2024-01-17T10:30:00Z",
      "usageNanoCores": 500000000,
      "usageCoreNanoSeconds": 12345678900000
    },
    "memory": {
      "time": "2024-01-17T10:30:00Z",
      "usageBytes": 2147483648,
      "workingSetBytes": 1879048192,
      "rssBytes": 1610612736,
      "pageFaults": 1000,
      "majorPageFaults": 50
    },
    "network": {
      "time": "2024-01-17T10:30:00Z",
      "interfaces": [...]
    },
    "fs": {
      "time": "2024-01-17T10:30:00Z",
      "availableBytes": 107374182400,
      "capacityBytes": 214748364800,
      "usedBytes": 107374182400
    },
    "runtime": {
      "imageFs": {
        "time": "2024-01-17T10:30:00Z",
        "availableBytes": 53687091200,
        "capacityBytes": 107374182400,
        "usedBytes": 53687091200
      }
    }
  },
  "pods": [...]
}
```

#### 實作邏輯

```java
// 1. 構建代理路徑
String proxyPath = "/api/v1/nodes/" + nodeName + "/proxy/stats/summary";
String fullUrl = apiClient.getBasePath() + proxyPath;

// 2. 構建 HTTP 請求 (設置 Accept 為 application/json)
okhttp3.Request request = new okhttp3.Request.Builder()
    .url(fullUrl)
    .get()
    .addHeader("Accept", "application/json")
    .build();

// 3. 執行請求
okhttp3.Response response = apiClient.getHttpClient().newCall(request).execute();

// 4. 處理響應
if (!response.isSuccessful()) {
    throw new ApiException(response.code(), "無法獲取節點統計信息");
}
return response.body().string();
```

#### 使用範例

```java
// 獲取節點統計信息
String statsJson = k8sOperationService.getNodeStats("worker-1");

// 解析 JSON (使用 Jackson 或其他 JSON 庫)
ObjectMapper mapper = new ObjectMapper();
JsonNode stats = mapper.readTree(statsJson);

// 提取 CPU 使用率
long cpuUsage = stats.get("node").get("cpu").get("usageNanoCores").asLong();

// 提取內存使用量
long memoryUsage = stats.get("node").get("memory").get("usageBytes").asLong();
```

## 關鍵技術要點

### 1. 使用 OkHttp 客戶端

Java Kubernetes Client 內部使用 OkHttp,我們直接利用其 `HttpClient`:

```java
apiClient.getHttpClient().newCall(request).execute();
```

### 2. 錯誤處理

- HTTP 4xx/5xx 錯誤轉換為 `ApiException`
- IO 異常包裝為 `ApiException`
- 提供詳細的錯誤訊息和 HTTP 狀態碼

### 3. 查詢參數處理

Node Log 支援 `tailLines` 參數:
```
/api/v1/nodes/worker-1/proxy/logs/kubelet?tailLines=100
```

### 4. 無官方範例的挑戰

Kubernetes Java Client 官方文檔中沒有提供 Node Log/Stats 的直接範例,因為:
- 這些功能屬於 Kubelet API,不是標準 K8s API
- 需要使用代理模式訪問
- 需要自行構建 HTTP 請求

## 限制與注意事項

### 1. 權限要求

訪問 Node Proxy 需要適當的 RBAC 權限:

```yaml
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRole
metadata:
  name: node-proxy-reader
rules:
- apiGroups: [""]
  resources: ["nodes/proxy"]
  verbs: ["get"]
```

### 2. 日誌路徑依賴系統

不同 Kubernetes 發行版和節點 OS 的日誌路徑可能不同:
- 標準 Linux: `/var/log/kubelet.log`
- systemd 系統: 可能使用 `journalctl`
- 某些託管 K8s (如 GKE): 可能限制訪問

### 3. Stats API 版本

Kubelet Stats API 有多個版本:
- `/stats/summary` - 摘要統計 (本實作使用)
- `/stats/{pod}/{container}` - 特定容器統計
- `/metrics/cadvisor` - cAdvisor metrics (Prometheus 格式)

### 4. 性能考量

- Node Log 可能返回大量數據,建議使用 `tailLines` 限制
- Stats 數據即時獲取,頻繁調用可能影響性能
- 建議添加結果緩存機制

## 與 Metrics Server 的差異

| 特性 | Metrics Server | Kubelet Stats API |
|------|----------------|-------------------|
| CPU 數據 | ✅ 核心數 | ✅ 納秒級使用率 |
| 內存數據 | ✅ 使用量 | ✅ 詳細分類 (RSS, Working Set 等) |
| 文件系統 | ❌ | ✅ 完整統計 |
| 網絡統計 | ❌ | ✅ 接口級別 |
| Runtime 信息 | ❌ | ✅ Image FS 等 |
| 日誌訪問 | ❌ | ✅ 系統日誌 |

## 測試建議

### 單元測試

```java
@Test
void testGetNodeLog() throws ApiException {
    String logs = k8sOperationService.getNodeLog("test-node", "kubelet", 10);
    assertNotNull(logs);
    assertTrue(logs.length() > 0);
}

@Test
void testGetNodeStats() throws ApiException {
    String stats = k8sOperationService.getNodeStats("test-node");
    assertNotNull(stats);
    assertTrue(stats.contains("\"node\""));
}
```

### 集成測試

需要實際的 Kubernetes 集群環境:

```bash
# 確認節點存在
kubectl get nodes

# 手動測試代理訪問
kubectl get --raw /api/v1/nodes/<node-name>/proxy/logs/kubelet | tail -n 10
kubectl get --raw /api/v1/nodes/<node-name>/proxy/stats/summary | jq .
```

## 總結

這兩個方法填補了 Kubernetes Java Client 在節點診斷功能上的空白:
- ✅ 提供節點日誌訪問能力
- ✅ 提供詳細的節點統計信息
- ✅ 使用標準的 API Server 代理機制
- ✅ 完整的錯誤處理和日誌記錄

這些功能對於:
- 故障診斷
- 性能分析
- 監控系統集成
- 運維自動化

都具有重要的實用價值。

## 參考資源

- [Kubernetes API Server Proxy](https://kubernetes.io/docs/tasks/access-application-cluster/access-cluster/#manually-constructing-apiserver-proxy-urls)
- [Kubelet API Documentation](https://kubernetes.io/docs/reference/command-line-tools-reference/kubelet/)
- [Resource Metrics API](https://kubernetes.io/docs/reference/instrumentation/metrics/)
- [Kubernetes Java Client](https://github.com/kubernetes-client/java)
