package com.momo.ltsre.kubernetes;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Kubernetes MCP Server 主應用程式
 * 
 * 這是一個基於 Spring AI MCP Server 框架的 Kubernetes 操作服務，
 * 提供透過 MCP 協議操作 Kubernetes 集群的能力。
 * 
 * @author pf2tsai
 * @version 1.0.0
 */
@Slf4j
@SpringBootApplication
public class KubernetesMcpServerApplication {

    /**
     * 主程式入口
     * 
     * @param args 命令列參數
     */
    public static void main(String[] args) {
        log.info("============================================");
        log.info("正在啟動 Kubernetes MCP Server...");
        log.info("============================================");
        
        SpringApplication.run(KubernetesMcpServerApplication.class, args);
        
        log.info("============================================");
        log.info("Kubernetes MCP Server 啟動完成");
        log.info("MCP 端點: http://localhost:8080/sse");
        log.info("============================================");
    }
}
