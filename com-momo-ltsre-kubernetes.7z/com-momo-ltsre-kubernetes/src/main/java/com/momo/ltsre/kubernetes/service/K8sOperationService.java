package com.momo.ltsre.kubernetes.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import io.kubernetes.client.Copy;
import io.kubernetes.client.Exec;
import io.kubernetes.client.Metrics;
import io.kubernetes.client.custom.ContainerMetrics;
import io.kubernetes.client.custom.NodeMetrics;
import io.kubernetes.client.custom.NodeMetricsList;
import io.kubernetes.client.custom.PodMetrics;
import io.kubernetes.client.custom.PodMetricsList;
import io.kubernetes.client.custom.Quantity;
import io.kubernetes.client.custom.V1Patch;
import io.kubernetes.client.openapi.ApiClient;
import io.kubernetes.client.openapi.ApiException;
import io.kubernetes.client.openapi.apis.AppsV1Api;
import io.kubernetes.client.openapi.apis.CoreV1Api;
import io.kubernetes.client.openapi.models.*;
import io.kubernetes.client.util.generic.dynamic.DynamicKubernetesApi;
import io.kubernetes.client.util.generic.dynamic.DynamicKubernetesObject;
import io.kubernetes.client.util.generic.dynamic.DynamicKubernetesListObject;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

/**
 * Kubernetes 操作服務
 * 
 * 這是服務層的核心類別，負責實現所有與 Kubernetes 集群交互的業務邏輯。
 * 它封裝了 Kubernetes Java Client 的底層 API 調用，
 * 並將結果轉換為統一的數據格式。
 * 
 * 架構層次：
 * - Infrastructure 層: KubernetesClientConfig (CoreV1Api, AppsV1Api)
 * - Service 層: K8sOperationService (本類別 - 業務邏輯)
 * - MCP 層: McpK8sToolsService (@Tool 註解方法)
 * 
 * @author pf2tsai
 * @version 1.0.0
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class K8sOperationService {

    /**
     * Kubernetes API Client
     * 用於創建 Metrics API 等其他 API 實例
     */
    private final ApiClient apiClient;

    /**
     * Kubernetes Core V1 API 實例
     * 用於操作 Pod, Service, ConfigMap, Namespace 等核心資源
     */
    private final CoreV1Api coreV1Api;

    /**
     * Kubernetes Apps V1 API 實例
     * 用於操作 Deployment, StatefulSet, DaemonSet 等應用資源
     */
    private final AppsV1Api appsV1Api;

    /**
     * Kubernetes Batch V1 API 實例
     * 用於操作 Job, CronJob 等批處理資源
     */
    private final io.kubernetes.client.openapi.apis.BatchV1Api batchV1Api;

    /**
     * Kubernetes Networking V1 API 實例
     * 用於操作 Ingress, NetworkPolicy 等網絡資源
     */
    private final io.kubernetes.client.openapi.apis.NetworkingV1Api networkingV1Api;

    /**
     * JSON 序列化工具
     * 用於將 API 響應轉換為 JSON 字符串
     * 註冊 JavaTimeModule 以支援 Java 8 日期時間類型
     */
    private final ObjectMapper objectMapper = new ObjectMapper().registerModule(new JavaTimeModule());

    /**
     * 默認命名空間
     */
    @Value("${kubernetes.default.namespace:default}")
    private String defaultNamespace;

    /**
     * 列出指定命名空間中的所有 Pod
     * 
     * 支援通過標籤選擇器過濾 Pod，例如：
     * - "app=nginx"
     * - "app=nginx,env=prod"
     * - "app in (nginx,httpd)"
     * 
     * @param namespace 命名空間名稱，如果為 null 則使用默認命名空間
     * @param labelSelector 標籤選擇器（可選），例如 "app=nginx"
     * @return Pod 列表的 JSON 字符串
     * @throws ApiException 如果 Kubernetes API 調用失敗
     */
    public String listPods(String namespace, String labelSelector) throws ApiException {
        String ns = namespace != null ? namespace : defaultNamespace;
        
        log.debug("正在列出 Pod - namespace: {}, labelSelector: {}", ns, labelSelector);
        
        // 調用 Kubernetes API 列出 Pod (使用 Fluent API)
        V1PodList podList = coreV1Api.listNamespacedPod(ns)
            .labelSelector(labelSelector)
            .execute();
        
        log.info("成功列出 {} 個 Pod (namespace: {})", podList.getItems().size(), ns);
        
        // 直接將 API 響應轉為 JSON 字符串
        try {
            return objectMapper.writeValueAsString(podList);
        } catch (Exception e) {
            log.error("序列化 Pod 列表失敗", e);
            throw new ApiException("序列化響應失敗: " + e.getMessage());
        }
    }

    /**
     * 列出所有命名空間中的 Pod
     * 
     * @param labelSelector 標籤選擇器（可選）
     * @return Pod 列表的 JSON 字符串
     * @throws ApiException 如果 Kubernetes API 調用失敗
     */
    public String listAllPods(String labelSelector) throws ApiException {
        log.debug("正在列出所有命名空間的 Pod - labelSelector: {}", labelSelector);
        
        // 調用 Kubernetes API 列出所有 Pod（使用 Fluent API）
        V1PodList podList = coreV1Api.listPodForAllNamespaces()
            .labelSelector(labelSelector)
            .execute();
        
        log.info("成功列出所有命名空間的 {} 個 Pod", podList.getItems().size());
        
        // 直接將 API 響應轉為 JSON 字符串
        try {
            return objectMapper.writeValueAsString(podList);
        } catch (Exception e) {
            log.error("序列化 Pod 列表失敗", e);
            throw new ApiException("序列化響應失敗: " + e.getMessage());
        }
    }

    /**
     * 獲取 Pod 日誌
     * 
     * @param namespace 命名空間名稱
     * @param podName Pod 名稱
     * @param containerName 容器名稱（可選，如果 Pod 只有一個容器則可省略）
     * @param tailLines 返回最後 N 行日誌（可選）
     * @return Pod 日誌內容（純文本）
     * @throws ApiException 如果 Kubernetes API 調用失敗
     */
    public String getPodLogs(String namespace, String podName, String containerName, Integer tailLines) throws ApiException {
        String ns = namespace != null ? namespace : defaultNamespace;
        
        log.debug("正在獲取 Pod 日誌 - pod: {}/{}, container: {}, tailLines: {}", 
                  ns, podName, containerName, tailLines);
        
        // 調用 Kubernetes API 讀取日誌（使用 Fluent API）
        var request = coreV1Api.readNamespacedPodLog(podName, ns);
        
        if (containerName != null && !containerName.isBlank()) {
            request = request.container(containerName);
        }
        
        if (tailLines != null && tailLines > 0) {
            request = request.tailLines(tailLines);
        }
        
        String logs = request.execute();
        
        log.info("成功獲取 Pod 日誌 - pod: {}/{}, 日誌長度: {} 字符", ns, podName, logs.length());
        return logs;
    }

    /**
     * 刪除 Pod
     * 
     * @param namespace 命名空間名稱
     * @param podName Pod 名稱
     * @throws ApiException 如果 Kubernetes API 調用失敗
     */
    public String deletePod(String namespace, String podName) throws ApiException {
        String ns = namespace != null ? namespace : defaultNamespace;
        
        log.debug("正在刪除 Pod - pod: {}/{}", ns, podName);
        
        // 調用 Kubernetes API 刪除 Pod（使用 Fluent API）
        coreV1Api.deleteNamespacedPod(podName, ns).execute();
        
        log.info("成功刪除 Pod - pod: {}/{}", ns, podName);
        
        // 返回成功訊息
        Map<String, Object> result = new HashMap<>();
        result.put("success", true);
        result.put("message", String.format("成功刪除 Pod: %s/%s", ns, podName));
        result.put("namespace", ns);
        result.put("pod", podName);
        
        try {
            return objectMapper.writeValueAsString(result);
        } catch (Exception e) {
            log.error("JSON 序列化失敗", e);
            throw new ApiException("序列化回應失敗: " + e.getMessage());
        }
    }

    /**
     * 列出指定命名空間中的所有 Deployment
     * 
     * @param namespace 命名空間名稱，如果為 null 則使用默認命名空間
     * @param labelSelector 標籤選擇器（可選）
     * @return Deployment 列表的 JSON 字符串
     * @throws ApiException 如果 Kubernetes API 調用失敗
     */
    public String listDeployments(String namespace, String labelSelector) throws ApiException {
        String ns = namespace != null ? namespace : defaultNamespace;
        
        log.debug("正在列出 Deployment - namespace: {}, labelSelector: {}", ns, labelSelector);
        
        // 調用 Kubernetes API 列出 Deployment（使用 Fluent API）
        V1DeploymentList deploymentList = appsV1Api.listNamespacedDeployment(ns)
            .labelSelector(labelSelector)
            .execute();
        
        log.info("成功列出 {} 個 Deployment (namespace: {})", deploymentList.getItems().size(), ns);
        
        // 直接將 API 響應轉為 JSON 字符串
        try {
            return objectMapper.writeValueAsString(deploymentList);
        } catch (Exception e) {
            log.error("序列化 Deployment 列表失敗", e);
            throw new ApiException("序列化響應失敗: " + e.getMessage());
        }
    }

    /**
     * 獲取特定 Deployment 的詳細信息
     * 
     * @param namespace 命名空間名稱
     * @param deploymentName Deployment 名稱
     * @return Deployment 的 JSON 字符串
     * @throws ApiException 如果 Kubernetes API 調用失敗
     */
    public String getDeployment(String namespace, String deploymentName) throws ApiException {
        String ns = namespace != null ? namespace : defaultNamespace;
        
        log.debug("正在獲取 Deployment - deployment: {}/{}", ns, deploymentName);
        
        // 調用 Kubernetes API 讀取 Deployment（使用 Fluent API）
        V1Deployment deployment = appsV1Api.readNamespacedDeployment(deploymentName, ns).execute();
        
        log.info("成功獲取 Deployment - deployment: {}/{}", ns, deploymentName);
        
        // 直接將 API 響應轉為 JSON 字符串
        try {
            return objectMapper.writeValueAsString(deployment);
        } catch (Exception e) {
            log.error("序列化 Deployment 失敗", e);
            throw new ApiException("序列化響應失敗: " + e.getMessage());
        }
    }

    /**
     * 刪除 Deployment
     * 
     * @param namespace 命名空間名稱
     * @param deploymentName Deployment 名稱
     * @throws ApiException 如果 Kubernetes API 調用失敗
     */
    public String deleteDeployment(String namespace, String deploymentName) throws ApiException {
        String ns = namespace != null ? namespace : defaultNamespace;
        
        log.debug("正在刪除 Deployment - deployment: {}/{}", ns, deploymentName);
        
        // 調用 Kubernetes API 刪除 Deployment（使用 Fluent API）
        appsV1Api.deleteNamespacedDeployment(deploymentName, ns).execute();
        
        log.info("成功刪除 Deployment - deployment: {}/{}", ns, deploymentName);
        
        // 返回成功訊息
        Map<String, Object> result = new HashMap<>();
        result.put("success", true);
        result.put("message", String.format("成功刪除 Deployment: %s/%s", ns, deploymentName));
        result.put("namespace", ns);
        result.put("deployment", deploymentName);
        
        try {
            return objectMapper.writeValueAsString(result);
        } catch (Exception e) {
            log.error("JSON 序列化失敗", e);
            throw new ApiException("序列化回應失敗: " + e.getMessage());
        }
    }

    /**
     * 縮放 Deployment
     * 
     * @param namespace 命名空間名稱
     * @param deploymentName Deployment 名稱
     * @param replicas 目標副本數
     * @return 操作結果的 JSON 字符串
     * @throws ApiException 如果 Kubernetes API 調用失敗
     */
    public String scaleDeployment(String namespace, String deploymentName, int replicas) throws ApiException {
        String ns = namespace != null ? namespace : defaultNamespace;
        
        log.debug("正在縮放 Deployment - deployment: {}/{}, replicas: {}", ns, deploymentName, replicas);
        
        // 獲取當前 Deployment
        V1Deployment deployment = appsV1Api.readNamespacedDeployment(deploymentName, ns).execute();
        
        // 更新副本數
        deployment.getSpec().setReplicas(replicas);
        
        // 應用更新（使用 Fluent API）
        appsV1Api.replaceNamespacedDeployment(deploymentName, ns, deployment).execute();
        
        log.info("成功縮放 Deployment - deployment: {}/{}, replicas: {}", ns, deploymentName, replicas);
        
        // 返回成功訊息
        Map<String, Object> result = new HashMap<>();
        result.put("success", true);
        result.put("message", String.format("成功將 Deployment %s/%s 縮放至 %d 個副本", ns, deploymentName, replicas));
        result.put("namespace", ns);
        result.put("deployment", deploymentName);
        result.put("replicas", replicas);
        
        try {
            return objectMapper.writeValueAsString(result);
        } catch (Exception e) {
            log.error("JSON 序列化失敗", e);
            throw new ApiException("序列化回應失敗: " + e.getMessage());
        }
    }

    /**
     * 獲取單個 Pod 的詳細信息
     * 
     * @param namespace 命名空間名稱
     * @param podName Pod 名稱
     * @return Pod 詳細信息的 JSON 字符串
     * @throws ApiException 如果 Kubernetes API 調用失敗
     */
    public String getPod(String namespace, String podName) throws ApiException {
        String ns = namespace != null ? namespace : defaultNamespace;
        
        log.debug("正在獲取 Pod 詳細信息 - pod: {}/{}", ns, podName);
        
        // 調用 Kubernetes API 獲取 Pod
        V1Pod pod = coreV1Api.readNamespacedPod(podName, ns).execute();
        
        log.info("成功獲取 Pod 詳細信息: {}/{}", ns, podName);
        
        // 直接將 API 響應轉為 JSON 字符串
        try {
            return objectMapper.writeValueAsString(pod);
        } catch (Exception e) {
            log.error("序列化 Pod 失敗", e);
            throw new ApiException("序列化響應失敗: " + e.getMessage());
        }
    }

    /**
     * 在 Pod 中執行命令
     * 
     * @param namespace 命名空間名稱
     * @param podName Pod 名稱
     * @param containerName 容器名稱（可選）
     * @param command 要執行的命令列表
     * @return 命令執行結果（stdout + stderr）
     * @throws ApiException 如果 Kubernetes API 調用失敗
     */
    public String execPod(String namespace, String podName, String containerName, List<String> command) throws ApiException {
        String ns = namespace != null ? namespace : defaultNamespace;
        
        log.debug("正在執行 Pod 命令 - pod: {}/{}, container: {}, command: {}", 
                 ns, podName, containerName, command);
        
        try {
            // 創建 Exec 實例
            Exec exec = new Exec();
            
            // 準備輸出緩衝區
            ByteArrayOutputStream stdout = new ByteArrayOutputStream();
            ByteArrayOutputStream stderr = new ByteArrayOutputStream();
            
            // 如果沒有指定容器名稱，獲取第一個容器
            String container = containerName;
            if (container == null || container.isBlank()) {
                V1Pod pod = coreV1Api.readNamespacedPod(podName, ns).execute();
                if (pod.getSpec() != null && 
                    pod.getSpec().getContainers() != null && 
                    !pod.getSpec().getContainers().isEmpty()) {
                    container = pod.getSpec().getContainers().get(0).getName();
                    log.debug("使用第一個容器: {}", container);
                }
            }
            
            // 執行命令
            // 參數說明:
            // - ns: 命名空間
            // - podName: Pod 名稱
            // - command.toArray(new String[0]): 要執行的命令數組
            // - container: 容器名稱
            // - stdin: 是否啟用標準輸入 (false)
            // - tty: 是否分配 TTY (false)
            Process proc = exec.exec(
                ns, 
                podName, 
                command.toArray(new String[0]), 
                container,
                false,  // stdin
                false   // tty
            );
            
            // 複製輸出流到緩衝區
            try (InputStream stdoutStream = proc.getInputStream();
                 InputStream stderrStream = proc.getErrorStream()) {
                
                // 創建線程讀取輸出
                Thread stdoutThread = new Thread(() -> {
                    try {
                        stdoutStream.transferTo(stdout);
                    } catch (IOException e) {
                        log.error("讀取 stdout 失敗", e);
                    }
                });
                
                Thread stderrThread = new Thread(() -> {
                    try {
                        stderrStream.transferTo(stderr);
                    } catch (IOException e) {
                        log.error("讀取 stderr 失敗", e);
                    }
                });
                
                stdoutThread.start();
                stderrThread.start();
                
                // 等待命令執行完成（最多 30 秒）
                boolean finished = proc.waitFor(30, TimeUnit.SECONDS);
                if (!finished) {
                    proc.destroy();
                    log.warn("命令執行超時，已強制終止");
                    return "命令執行超時（30秒）";
                }
                
                // 等待輸出線程完成
                stdoutThread.join(5000);
                stderrThread.join(5000);
            }
            
            // 組合輸出結果
            StringBuilder result = new StringBuilder();
            String stdoutStr = stdout.toString(StandardCharsets.UTF_8);
            String stderrStr = stderr.toString(StandardCharsets.UTF_8);
            
            if (!stdoutStr.isEmpty()) {
                result.append("=== STDOUT ===\n").append(stdoutStr);
            }
            if (!stderrStr.isEmpty()) {
                if (result.length() > 0) {
                    result.append("\n\n");
                }
                result.append("=== STDERR ===\n").append(stderrStr);
            }
            
            // 獲取退出碼
            int exitCode = proc.exitValue();
            result.append("\n\n=== EXIT CODE ===\n").append(exitCode);
            
            log.info("成功執行 Pod 命令 - pod: {}/{}, exitCode: {}", ns, podName, exitCode);
            return result.toString();
            
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            log.error("Pod exec 被中斷", e);
            throw new ApiException("Pod exec 被中斷: " + e.getMessage());
        } catch (IOException e) {
            log.error("Pod exec IO 錯誤", e);
            throw new ApiException("Pod exec IO 錯誤: " + e.getMessage());
        }
    }

    /**
     * 運行一個新的 Pod
     * 
     * @param namespace 命名空間名稱
     * @param podName Pod 名稱（可選，如果為空則自動生成）
     * @param image 容器鏡像
     * @param port 暴露的端口（可選）
     * @return 創建的 Pod 信息 JSON 字符串
     * @throws ApiException 如果 Kubernetes API 調用失敗
     */
    public String runPod(String namespace, String podName, String image, Integer port) throws ApiException {
        String ns = namespace != null ? namespace : defaultNamespace;
        String name = podName != null ? podName : generatePodName(image);
        
        log.debug("正在運行 Pod - namespace: {}, name: {}, image: {}, port: {}", 
                 ns, name, image, port);
        
        try {
            // 使用 YAML 方式創建 Pod，避免 Java API 可能的預設值問題
            StringBuilder yamlBuilder = new StringBuilder();
            yamlBuilder.append("apiVersion: v1\n");
            yamlBuilder.append("kind: Pod\n");
            yamlBuilder.append("metadata:\n");
            yamlBuilder.append("  name: ").append(name).append("\n");
            yamlBuilder.append("  namespace: ").append(ns).append("\n");
            yamlBuilder.append("spec:\n");
            yamlBuilder.append("  restartPolicy: Always\n");
            yamlBuilder.append("  containers:\n");
            yamlBuilder.append("  - name: main\n");
            yamlBuilder.append("    image: ").append(image).append("\n");
            
            if (port != null && port > 0) {
                yamlBuilder.append("    ports:\n");
                yamlBuilder.append("    - containerPort: ").append(port).append("\n");
            }
            
            String podYaml = yamlBuilder.toString();
            log.debug("Pod YAML:\n{}", podYaml);
            
            // 使用 createOrUpdateResource 創建 Pod
            String result = createOrUpdateResource(podYaml);
            log.info("成功創建 Pod: {}/{}", ns, name);
            return result;
            
        } catch (Exception e) {
            log.error("創建 Pod 失敗", e);
            throw new ApiException("創建 Pod 失敗: " + e.getMessage());
        }
    }

    /**
     * 獲取 Pod 資源使用率(CPU 和 Memory)
     * 
     * @param namespace 命名空間名稱(可選,為空則查詢所有命名空間)
     * @param podName Pod 名稱(可選,為空則查詢所有 Pod)
     * @param labelSelector 標籤選擇器(可選)
     * @return Pod 資源使用信息
     * @throws ApiException 如果 Kubernetes API 調用失敗
     */
    public String getPodTop(String namespace, String podName, String labelSelector) throws ApiException {
        String ns = namespace != null ? namespace : defaultNamespace;
        
        log.debug("正在獲取 Pod 資源使用率 - namespace: {}, pod: {}, labelSelector: {}", 
                 ns, podName, labelSelector);
        
        try {
            // 創建 Metrics API 實例
            Metrics metrics = new Metrics(apiClient);
            
            StringBuilder result = new StringBuilder();
            result.append("POD METRICS\n");
            result.append(String.format("%-50s %-15s %-15s%n", "NAME", "CPU(cores)", "MEMORY(bytes)"));
            result.append("=".repeat(80)).append("\n");
            
            // 獲取指定命名空間的 Pod Metrics
            PodMetricsList podMetricsList = metrics.getPodMetrics(ns);
            
            for (PodMetrics podMetrics : podMetricsList.getItems()) {
                String currentPodName = podMetrics.getMetadata().getName();
                
                // 如果指定了 podName,只顯示該 Pod
                if (podName != null && !podName.isEmpty() && !currentPodName.equals(podName)) {
                    continue;
                }
                
                // 計算總 CPU 和 Memory
                long totalCpuNano = 0;
                long totalMemoryBytes = 0;
                
                for (ContainerMetrics container : podMetrics.getContainers()) {
                    Quantity cpu = container.getUsage().get("cpu");
                    Quantity memory = container.getUsage().get("memory");
                    
                    if (cpu != null) {
                        totalCpuNano += cpu.getNumber().longValue();
                    }
                    if (memory != null) {
                        totalMemoryBytes += memory.getNumber().longValue();
                    }
                }
                
                // 轉換單位: nano cores -> milli cores, bytes -> Mi
                long cpuMillis = totalCpuNano / 1_000_000;
                long memoryMi = totalMemoryBytes / (1024 * 1024);
                
                result.append(String.format("%-50s %-15s %-15s%n", 
                    currentPodName, 
                    cpuMillis + "m",
                    memoryMi + "Mi"
                ));
            }
            
            log.info("成功獲取 Pod 資源使用率 - namespace: {}", ns);
            return result.toString();
            
        } catch (Exception e) {
            log.error("獲取 Pod 資源使用率失敗", e);
            throw new ApiException("獲取 Pod 資源使用率失敗: " + e.getMessage());
        }
    }

    /**
     * 生成 Pod 名稱
     * 
     * @param image 容器鏡像名稱
     * @return 生成的 Pod 名稱
     */
    private String generatePodName(String image) {
        String imageName = image.contains("/") 
            ? image.substring(image.lastIndexOf("/") + 1) 
            : image;
        imageName = imageName.contains(":") 
            ? imageName.substring(0, imageName.indexOf(":")) 
            : imageName;
        return imageName + "-" + System.currentTimeMillis();
    }

    /**
     * 列出通用 Kubernetes 資源
     * 
     * 使用 DynamicKubernetesApi 列出任意類型的 Kubernetes 資源。
     * 支援 namespaced 和 cluster-scoped 資源。
     * 
     * 範例：
     * - listResources("v1", "Service", "default", null) - 列出 default namespace 的所有 Services
     * - listResources("v1", "Namespace", null, null) - 列出所有 Namespaces (cluster-scoped)
     * - listResources("apps/v1", "Deployment", "kube-system", "app=nginx") - 過濾特定標籤
     * 
     * @param apiVersion 資源 API 版本（例如："v1", "apps/v1", "networking.k8s.io/v1"）
     * @param kind 資源類型（例如："Pod", "Service", "Deployment"）
     * @param namespace 命名空間（可選，cluster-scoped 資源不需要）
     * @param labelSelector 標籤選擇器（可選）
     * @return 資源列表的 JSON 字符串
     * @throws ApiException 如果 Kubernetes API 調用失敗
     */
    public String listResources(String apiVersion, String kind, String namespace, String labelSelector) throws ApiException {
        log.debug("正在列出資源 - apiVersion: {}, kind: {}, namespace: {}, labelSelector: {}", 
                 apiVersion, kind, namespace, labelSelector);
        
        try {
            // 解析 apiVersion 為 group 和 version
            // 例如: "v1" -> group="", version="v1"
            //      "apps/v1" -> group="apps", version="v1"
            String group;
            String version;
            if (apiVersion.contains("/")) {
                String[] parts = apiVersion.split("/", 2);
                group = parts[0];
                version = parts[1];
            } else {
                group = "";  // Core API 的 group 為空字串
                version = apiVersion;
            }
            
            // 計算資源的複數形式（簡單規則）
            String resourcePlural = calculatePluralForm(kind);
            
            // 創建 DynamicKubernetesApi 實例
            DynamicKubernetesApi dynamicApi = new DynamicKubernetesApi(
                group, 
                version, 
                resourcePlural, 
                apiClient
            );
            
            // 列出資源
            DynamicKubernetesListObject listObj;
            if (namespace != null && !namespace.isEmpty()) {
                // Namespaced 資源
                log.debug("列出 namespaced 資源：{}/{} 在命名空間 {}", group, version, namespace);
                listObj = dynamicApi.list(namespace).throwsApiException().getObject();
            } else {
                // Cluster-scoped 資源
                log.debug("列出 cluster-scoped 資源：{}/{}", group, version);
                listObj = dynamicApi.list().throwsApiException().getObject();
            }
            
            log.info("成功列出 {} 個資源 (kind: {}, namespace: {})", 
                listObj != null && listObj.getItems() != null ? listObj.getItems().size() : 0, 
                kind, namespace);
            
            // 使用 Gson 序列化以避免 Jackson 的反射問題
            Gson gson = new Gson();
            return gson.toJson(listObj);
            
        } catch (ApiException e) {
            log.error("列出資源失敗 - apiVersion: {}, kind: {}, namespace: {}", apiVersion, kind, namespace, e);
            throw e;
        } catch (Exception e) {
            log.error("列出資源時發生未預期錯誤", e);
            throw new ApiException("列出資源失敗: " + e.getMessage());
        }
    }

    /**
     * 獲取單個 Kubernetes 資源
     * 
     * 使用 DynamicKubernetesApi 獲取任意類型的單個 Kubernetes 資源。
     * 
     * 範例：
     * - getResource("v1", "Service", "default", "kubernetes") - 獲取 default namespace 的 kubernetes Service
     * - getResource("v1", "Namespace", null, "kube-system") - 獲取 kube-system Namespace
     * 
     * @param apiVersion 資源 API 版本
     * @param kind 資源類型
     * @param namespace 命名空間（可選，cluster-scoped 資源不需要）
     * @param name 資源名稱
     * @return 資源詳細信息的 JSON 字符串
     * @throws ApiException 如果 Kubernetes API 調用失敗
     */
    public String getResource(String apiVersion, String kind, String namespace, String name) throws ApiException {
        log.debug("正在獲取資源 - apiVersion: {}, kind: {}, namespace: {}, name: {}", 
                 apiVersion, kind, namespace, name);
        
        try {
            // 解析 apiVersion
            String group;
            String version;
            if (apiVersion.contains("/")) {
                String[] parts = apiVersion.split("/", 2);
                group = parts[0];
                version = parts[1];
            } else {
                group = "";
                version = apiVersion;
            }
            
            // 計算資源複數形式
            String resourcePlural = calculatePluralForm(kind);
            
            // 創建 DynamicKubernetesApi 實例
            DynamicKubernetesApi dynamicApi = new DynamicKubernetesApi(
                group, 
                version, 
                resourcePlural, 
                apiClient
            );
            
            // 獲取資源
            DynamicKubernetesObject obj;
            if (namespace != null && !namespace.isEmpty()) {
                // Namespaced 資源
                log.debug("獲取 namespaced 資源：{}/{}/{}/{}", group, version, namespace, name);
                obj = dynamicApi.get(namespace, name).throwsApiException().getObject();
            } else {
                // Cluster-scoped 資源
                log.debug("獲取 cluster-scoped 資源：{}/{}/{}", group, version, name);
                obj = dynamicApi.get(name).throwsApiException().getObject();
            }
            
            if (obj == null) {
                throw new ApiException(404, "資源未找到");
            }
            
            log.info("成功獲取資源: {}/{} (namespace: {})", kind, name, namespace);
            
            // 直接將 API 響應轉為 JSON 字符串
            return objectMapper.writeValueAsString(obj);
            
        } catch (ApiException e) {
            log.error("獲取資源失敗 - apiVersion: {}, kind: {}, namespace: {}, name: {}", 
                     apiVersion, kind, namespace, name, e);
            throw e;
        } catch (Exception e) {
            log.error("獲取資源時發生未預期錯誤", e);
            throw new ApiException("獲取資源失敗: " + e.getMessage());
        }
    }

    /**
     * 創建或更新 Kubernetes 資源
     * 
     * 使用 DynamicKubernetesApi 從 YAML/JSON 創建或更新資源。
     * 如果資源已存在則更新，否則創建新資源。
     * 
     * @param resourceYaml 資源的 YAML 或 JSON 表示
     * @return 創建/更新後的資源 JSON 字符串
     * @throws ApiException 如果 Kubernetes API 調用失敗
     */
    public String createOrUpdateResource(String resourceYaml) throws ApiException {
        log.debug("正在創建或更新資源，長度: {}", resourceYaml.length());
        
        try {
            // 使用 Gson 解析 YAML 字符串
            Gson gson = new Gson();
            
            // 先用 SnakeYAML 解析，但是用通用的方式避免強類型轉換
            org.yaml.snakeyaml.Yaml yaml = new org.yaml.snakeyaml.Yaml();
            Map<String, Object> resourceMap = yaml.load(resourceYaml);
            
            // 從 Map 轉為 JSON 字符串
            String jsonString = gson.toJson(resourceMap);
            JsonObject jsonObject = gson.fromJson(jsonString, JsonObject.class);
            
            // 創建 DynamicKubernetesObject
            DynamicKubernetesObject dynamicObj = new DynamicKubernetesObject(jsonObject);
            
            if (dynamicObj == null || dynamicObj.getApiVersion() == null || dynamicObj.getKind() == null) {
                throw new ApiException("無法解析資源 YAML 或缺少必要欄位 (apiVersion/kind)");
            }
            
            // 提取資源元數據
            String apiVersion = dynamicObj.getApiVersion();
            String kind = dynamicObj.getKind();
            String name = dynamicObj.getMetadata().getName();
            String namespace = dynamicObj.getMetadata().getNamespace();
            
            log.debug("解析資源: apiVersion={}, kind={}, name={}, namespace={}", 
                     apiVersion, kind, name, namespace);
            
            // 解析 apiVersion
            String group;
            String version;
            if (apiVersion.contains("/")) {
                String[] parts = apiVersion.split("/", 2);
                group = parts[0];
                version = parts[1];
            } else {
                group = "";
                version = apiVersion;
            }
            
            // 計算資源複數形式
            String resourcePlural = calculatePluralForm(kind);
            
            // 創建 DynamicKubernetesApi 實例
            DynamicKubernetesApi dynamicApi = new DynamicKubernetesApi(
                group, 
                version, 
                resourcePlural, 
                apiClient
            );
            
            // 嘗試更新或創建
            DynamicKubernetesObject result;
            try {
                // 先嘗試更新
                log.debug("嘗試更新資源: {}/{}", kind, name);
                result = dynamicApi.update(dynamicObj).throwsApiException().getObject();
                log.info("成功更新資源: {}/{} (namespace: {})", kind, name, namespace);
            } catch (ApiException e) {
                if (e.getCode() == 404) {
                    // 資源不存在，創建新的
                    log.debug("資源不存在，嘗試創建: {}/{}", kind, name);
                    result = dynamicApi.create(dynamicObj).throwsApiException().getObject();
                    log.info("成功創建資源: {}/{} (namespace: {})", kind, name, namespace);
                } else {
                    throw e;
                }
            }
            
            // 將結果轉為簡單的字符串形式，避免序列化問題
            return gson.toJson(result.getRaw());
            
        } catch (ApiException e) {
            log.error("創建或更新資源失敗", e);
            throw e;
        } catch (Exception e) {
            log.error("創建或更新資源時發生未預期錯誤", e);
            throw new ApiException("創建或更新資源失敗: " + e.getMessage());
        }
    }

    /**
     * 刪除 Kubernetes 資源
     * 
     * 使用 DynamicKubernetesApi 刪除任意類型的 Kubernetes 資源。
     * 
     * @param apiVersion 資源 API 版本
     * @param kind 資源類型
     * @param namespace 命名空間（可選，cluster-scoped 資源不需要）
     * @param name 資源名稱
     * @throws ApiException 如果 Kubernetes API 調用失敗
     */
    public String deleteResource(String apiVersion, String kind, String namespace, String name) throws ApiException {
        log.debug("正在刪除資源 - apiVersion: {}, kind: {}, namespace: {}, name: {}", 
                 apiVersion, kind, namespace, name);
        
        try {
            // 解析 apiVersion
            String group;
            String version;
            if (apiVersion.contains("/")) {
                String[] parts = apiVersion.split("/", 2);
                group = parts[0];
                version = parts[1];
            } else {
                group = "";
                version = apiVersion;
            }
            
            // 計算資源複數形式
            String resourcePlural = calculatePluralForm(kind);
            
            // 創建 DynamicKubernetesApi 實例
            DynamicKubernetesApi dynamicApi = new DynamicKubernetesApi(
                group, 
                version, 
                resourcePlural, 
                apiClient
            );
            
            // 刪除資源
            if (namespace != null && !namespace.isEmpty()) {
                // Namespaced 資源
                log.debug("刪除 namespaced 資源：{}/{}/{}/{}", group, version, namespace, name);
                dynamicApi.delete(namespace, name).throwsApiException();
            } else {
                // Cluster-scoped 資源
                log.debug("刪除 cluster-scoped 資源：{}/{}/{}", group, version, name);
                dynamicApi.delete(name).throwsApiException();
            }
            
            log.info("成功刪除資源: {}/{} (namespace: {})", kind, name, namespace);
            
            // 返回成功訊息
            Map<String, Object> result = new HashMap<>();
            result.put("success", true);
            result.put("message", String.format("成功刪除資源: %s/%s", kind, name));
            result.put("kind", kind);
            result.put("name", name);
            if (namespace != null && !namespace.isEmpty()) {
                result.put("namespace", namespace);
            }
            
            return objectMapper.writeValueAsString(result);
            
        } catch (ApiException e) {
            log.error("刪除資源失敗 - apiVersion: {}, kind: {}, namespace: {}, name: {}", 
                     apiVersion, kind, namespace, name, e);
            throw e;
        } catch (Exception e) {
            log.error("刪除資源時發生未預期錯誤", e);
            throw new ApiException("刪除資源失敗: " + e.getMessage());
        }
    }

    /**
     * 列出 Kubernetes 事件
     * 
     * @param namespace 命名空間（可選，為空則列出所有命名空間的事件）
     * @return 事件列表的 JSON 字符串
     * @throws ApiException 如果 Kubernetes API 調用失敗
     */
    public String listEvents(String namespace) throws ApiException {
        log.debug("正在列出事件 - namespace: {}", namespace);
        
        CoreV1EventList eventList;
        
        if (namespace != null && !namespace.isEmpty()) {
            // 列出指定命名空間的事件
            eventList = coreV1Api.listNamespacedEvent(namespace).execute();
        } else {
            // 列出所有命名空間的事件
            eventList = coreV1Api.listEventForAllNamespaces().execute();
        }
        
        log.info("成功列出 {} 個事件", eventList.getItems().size());
        
        // 直接將 API 響應轉為 JSON 字符串
        try {
            return objectMapper.writeValueAsString(eventList);
        } catch (Exception e) {
            log.error("序列化事件列表失敗", e);
            throw new ApiException("序列化響應失敗: " + e.getMessage());
        }
    }

    /**
     * 列出所有節點
     * 
     * @param labelSelector 標籤選擇器（可選）
     * @return 節點列表的 JSON 字符串
     * @throws ApiException 如果 Kubernetes API 調用失敗
     */
    public String listNodes(String labelSelector) throws ApiException {
        log.debug("正在列出節點 - labelSelector: {}", labelSelector);
        
        V1NodeList nodeList = coreV1Api.listNode()
            .labelSelector(labelSelector)
            .execute();
        
        log.info("成功列出 {} 個節點", nodeList.getItems().size());
        
        // 直接將 API 響應轉為 JSON 字符串
        try {
            return objectMapper.writeValueAsString(nodeList);
        } catch (Exception e) {
            log.error("序列化節點列表失敗", e);
            throw new ApiException("序列化響應失敗: " + e.getMessage());
        }
    }

    /**
     * 獲取節點資源使用率
     * 
     * @param nodeName 節點名稱(可選)
     * @param labelSelector 標籤選擇器(可選)
     * @return 節點資源使用信息
     * @throws ApiException 如果 Kubernetes API 調用失敗
     */
    public String getNodeTop(String nodeName, String labelSelector) throws ApiException {
        log.debug("正在獲取節點資源使用率 - node: {}, labelSelector: {}", nodeName, labelSelector);
        
        try {
            // 創建 Metrics API 實例
            Metrics metrics = new Metrics(apiClient);
            
            StringBuilder result = new StringBuilder();
            result.append("NODE METRICS\n");
            result.append(String.format("%-20s %-15s %-10s %-15s %-10s%n", 
                "NAME", "CPU(cores)", "CPU%", "MEMORY(bytes)", "MEMORY%"));
            result.append("=".repeat(80)).append("\n");
            
            // 獲取節點 Metrics
            NodeMetricsList nodeMetricsList = metrics.getNodeMetrics();
            
            for (NodeMetrics nodeMetrics : nodeMetricsList.getItems()) {
                String currentNodeName = nodeMetrics.getMetadata().getName();
                
                // 如果指定了 nodeName,只顯示該節點
                if (nodeName != null && !nodeName.isEmpty() && !currentNodeName.equals(nodeName)) {
                    continue;
                }
                
                // 獲取 CPU 和 Memory 使用量
                Quantity cpu = nodeMetrics.getUsage().get("cpu");
                Quantity memory = nodeMetrics.getUsage().get("memory");
                
                long cpuNano = cpu != null ? cpu.getNumber().longValue() : 0;
                long memoryBytes = memory != null ? memory.getNumber().longValue() : 0;
                
                // 轉換單位
                long cpuMillis = cpuNano / 1_000_000;
                long memoryMi = memoryBytes / (1024 * 1024);
                
                // 獲取節點容量以計算百分比
                V1Node node = coreV1Api.readNode(currentNodeName).execute();
                Quantity cpuCapacity = node.getStatus().getCapacity().get("cpu");
                Quantity memCapacity = node.getStatus().getCapacity().get("memory");
                
                // 計算百分比
                int cpuPercent = 0;
                int memPercent = 0;
                
                if (cpuCapacity != null) {
                    long cpuCapacityMillis = cpuCapacity.getNumber().longValue() * 1000;
                    cpuPercent = (int) ((cpuMillis * 100) / cpuCapacityMillis);
                }
                
                if (memCapacity != null) {
                    long memCapacityBytes = memCapacity.getNumber().longValue();
                    memPercent = (int) ((memoryBytes * 100) / memCapacityBytes);
                }
                
                result.append(String.format("%-20s %-15s %-10s %-15s %-10s%n",
                    currentNodeName,
                    cpuMillis + "m",
                    cpuPercent + "%",
                    memoryMi + "Mi",
                    memPercent + "%"
                ));
            }
            
            log.info("成功獲取節點資源使用率");
            return result.toString();
            
        } catch (Exception e) {
            log.error("獲取節點資源使用率失敗", e);
            throw new ApiException("獲取節點資源使用率失敗: " + e.getMessage());
        }
    }

    /**
     * 獲取節點日誌
     * <p>
     * 此方法通過 Kubernetes API Server 代理訪問 Kubelet API 的 /logs 端點,
     * 可以獲取節點上的系統日誌檔案(如 kubelet.log, syslog 等)。
     * </p>
     * 
     * @param nodeName 節點名稱
     * @param query 日誌路徑（例如：kubelet, syslog, /var/log/kubelet.log）
     * @param tailLines 返回最後 N 行（可選）
     * @return 節點日誌內容
     * @throws ApiException 如果 Kubernetes API 調用失敗或節點日誌不存在
     */
    public String getNodeLog(String nodeName, String query, Integer tailLines) throws ApiException {
        log.debug("正在獲取節點日誌 - node: {}, query: {}, tailLines: {}", nodeName, query, tailLines);
        
        try {
            // 構建 Kubelet API 代理路徑
            // 路徑格式: /api/v1/nodes/{nodeName}/proxy/logs/{logPath}
            String logPath = query != null && !query.isEmpty() ? query : "kubelet";
            if (!logPath.startsWith("/")) {
                logPath = "/" + logPath;
            }
            
            String proxyPath = "/api/v1/nodes/" + nodeName + "/proxy/logs" + logPath;
            
            // 構建請求 URL（添加 tailLines 查詢參數）
            String fullUrl = apiClient.getBasePath() + proxyPath;
            if (tailLines != null && tailLines > 0) {
                fullUrl += "?tailLines=" + tailLines;
            }
            
            // 構建自訂 HTTP 請求
            okhttp3.Request request = new okhttp3.Request.Builder()
                .url(fullUrl)
                .get()
                .build();
            
            // 執行請求
            okhttp3.Response response = apiClient.getHttpClient().newCall(request).execute();
            
            if (!response.isSuccessful()) {
                String errorBody = response.body() != null ? response.body().string() : "";
                log.error("無法獲取節點日誌 - 節點: {}, HTTP {}: {}", 
                    nodeName, response.code(), errorBody);
                throw new ApiException(response.code(),
                    "無法獲取節點日誌: " + response.message() + " - " + errorBody);
            }
            
            String logContent = response.body() != null ? response.body().string() : "";
            log.info("成功獲取節點 {} 的日誌，共 {} 字符", nodeName, logContent.length());
            return logContent;
            
        } catch (IOException e) {
            log.error("獲取節點日誌時發生 IO 錯誤 - 節點: {}", nodeName, e);
            throw new ApiException("獲取節點日誌失敗: " + e.getMessage());
        }
    }

    /**
     * 獲取節點詳細統計信息
     * <p>
     * 此方法通過 Kubernetes API Server 代理訪問 Kubelet 的 /stats/summary API,
     * 可以獲取節點的詳細資源統計信息，包括 CPU、內存、文件系統、網絡等指標。
     * </p>
     * 
     * @param nodeName 節點名稱
     * @return 節點統計信息（JSON 格式）
     * @throws ApiException 如果 Kubernetes API 調用失敗
     */
    public String getNodeStats(String nodeName) throws ApiException {
        log.debug("正在獲取節點統計信息 - node: {}", nodeName);
        
        try {
            // 構建 Kubelet API 代理路徑
            // 路徑格式: /api/v1/nodes/{nodeName}/proxy/stats/summary
            String proxyPath = "/api/v1/nodes/" + nodeName + "/proxy/stats/summary";
            String fullUrl = apiClient.getBasePath() + proxyPath;
            
            // 構建自訂 HTTP 請求
            okhttp3.Request request = new okhttp3.Request.Builder()
                .url(fullUrl)
                .get()
                .addHeader("Accept", "application/json")
                .build();
            
            // 執行請求
            okhttp3.Response response = apiClient.getHttpClient().newCall(request).execute();
            
            if (!response.isSuccessful()) {
                String errorBody = response.body() != null ? response.body().string() : "";
                log.error("無法獲取節點統計信息 - 節點: {}, HTTP {}: {}", 
                    nodeName, response.code(), errorBody);
                throw new ApiException(response.code(),
                    "無法獲取節點統計信息: " + response.message() + " - " + errorBody);
            }
            
            String statsJson = response.body() != null ? response.body().string() : "{}";
            log.info("成功獲取節點 {} 的統計信息，共 {} 字符", nodeName, statsJson.length());
            return statsJson;
            
        } catch (IOException e) {
            log.error("獲取節點統計信息時發生 IO 錯誤 - 節點: {}", nodeName, e);
            throw new ApiException("獲取節點統計信息失敗: " + e.getMessage());
        }
    }

    /**
     * 列出所有命名空間
     * 
     * @param labelSelector 標籤選擇器（可選），例如 "env=prod"。如果為空或null，返回所有命名空間
     * @return 命名空間名稱列表
     * @throws ApiException 如果 Kubernetes API 調用失敗
     */
    public List<String> listNamespaces(String labelSelector) throws ApiException {
        log.debug("正在列出命名空間 - labelSelector: {}", labelSelector);
        
        // 調用 Kubernetes API 列出所有 Namespace（使用 Fluent API）
        var request = coreV1Api.listNamespace();
        
        // 如果提供了 labelSelector，應用過濾
        if (labelSelector != null && !labelSelector.trim().isEmpty()) {
            request.labelSelector(labelSelector);
            log.debug("應用標籤選擇器: {}", labelSelector);
        }
        
        V1NamespaceList namespaceList = request.execute();
        
        List<String> namespaces = namespaceList.getItems().stream()
            .map(ns -> ns.getMetadata().getName())
            .collect(Collectors.toList());
        
        log.info("成功列出 {} 個命名空間", namespaces.size());
        return namespaces;
    }

    /**
     * 列出 kubeconfig 中的所有上下文
     * 
     * 讀取 kubeconfig 檔案並解析出所有可用的上下文（contexts）。
     * 每個上下文包含集群、用戶和命名空間的配置組合。
     * 直接返回 kubeconfig 原始內容供 AI 解析。
     * 
     * @return kubeconfig 的 YAML 內容
     */
    public String listConfigurationContexts() {
        log.debug("正在列出 kubeconfig 上下文");
        
        try {
            // 讀取 kubeconfig 檔案
            // 優先順序: KUBECONFIG 環境變數 > ~/.kube/config
            String kubeconfigPath = System.getenv("KUBECONFIG");
            if (kubeconfigPath == null || kubeconfigPath.isEmpty()) {
                String userHome = System.getProperty("user.home");
                kubeconfigPath = userHome + "/.kube/config";
            }
            
            log.debug("讀取 kubeconfig 檔案: {}", kubeconfigPath);
            
            // 讀取檔案內容
            java.nio.file.Path configPath = java.nio.file.Paths.get(kubeconfigPath);
            if (!java.nio.file.Files.exists(configPath)) {
                log.warn("kubeconfig 檔案不存在: {}", kubeconfigPath);
                return "{\"error\": \"kubeconfig file not found\", \"path\": \"" + kubeconfigPath + "\"}";
            }
            
            // 直接返回 kubeconfig 原始內容(YAML 格式)
            // AI 可以直接理解和解析 YAML
            String content = new String(java.nio.file.Files.readAllBytes(configPath), java.nio.charset.StandardCharsets.UTF_8);
            
            log.info("成功讀取 kubeconfig,長度: {} 字符", content.length());
            return content;
            
        } catch (Exception e) {
            log.error("列出配置上下文失敗", e);
            throw new RuntimeException("列出配置上下文失敗: " + e.getMessage(), e);
        }
    }

    /**
     * 查看當前 Kubernetes 配置
     * 
     * 顯示當前使用的集群、用戶、命名空間等配置信息。
     * 包括 API Server 地址、認證方式、當前上下文等。
     * 直接返回當前 ApiClient 的配置信息供 AI 解析。
     * 
     * @return 配置信息的 JSON 字符串
     */
    public String viewConfiguration() {
        log.debug("正在查看當前配置");
        
        try {
            // 構建當前配置信息的 JSON
            // 直接從 ApiClient 獲取當前配置
            StringBuilder config = new StringBuilder();
            config.append("{\n");
            config.append("  \"basePath\": \"").append(apiClient.getBasePath()).append("\",\n");
            config.append("  \"debugging\": ").append(apiClient.isDebugging()).append(",\n");
            config.append("  \"verifyingSsl\": ").append(apiClient.isVerifyingSsl()).append(",\n");
            
            // 獲取當前命名空間
            config.append("  \"defaultNamespace\": \"").append(defaultNamespace).append("\",\n");
            
            // 嘗試獲取當前上下文信息(從 kubeconfig)
            try {
                String kubeconfigPath = System.getenv("KUBECONFIG");
                if (kubeconfigPath == null || kubeconfigPath.isEmpty()) {
                    String userHome = System.getProperty("user.home");
                    kubeconfigPath = userHome + "/.kube/config";
                }
                
                java.nio.file.Path configPath = java.nio.file.Paths.get(kubeconfigPath);
                if (java.nio.file.Files.exists(configPath)) {
                    config.append("  \"kubeconfigPath\": \"").append(kubeconfigPath).append("\",\n");
                    
                    // 解析 kubeconfig 獲取當前上下文
                    io.kubernetes.client.util.KubeConfig kubeConfig = 
                        io.kubernetes.client.util.KubeConfig.loadKubeConfig(
                            new java.io.FileReader(kubeconfigPath));
                    
                    String currentContext = kubeConfig.getCurrentContext();
                    config.append("  \"currentContext\": \"").append(currentContext != null ? currentContext : "null").append("\",\n");
                    
                    // 獲取所有可用的上下文名稱
                    java.util.List<String> contextNames = new java.util.ArrayList<>();
                    if (kubeConfig.getContexts() != null) {
                        for (Object ctx : kubeConfig.getContexts()) {
                            if (ctx instanceof java.util.Map) {
                                Object name = ((java.util.Map<?, ?>) ctx).get("name");
                                if (name != null) {
                                    contextNames.add(name.toString());
                                }
                            }
                        }
                    }
                    config.append("  \"availableContexts\": ").append(new com.google.gson.Gson().toJson(contextNames)).append("\n");
                } else {
                    config.append("  \"kubeconfigPath\": null,\n");
                    config.append("  \"currentContext\": null,\n");
                    config.append("  \"contextDetails\": null\n");
                }
            } catch (Exception e) {
                log.warn("無法讀取 kubeconfig 詳細信息", e);
                config.append("  \"kubeconfigError\": \"").append(e.getMessage()).append("\"\n");
            }
            
            config.append("}");
            
            String result = config.toString();
            log.info("成功獲取當前配置信息");
            return result;
            
        } catch (Exception e) {
            log.error("查看配置失敗", e);
            throw new RuntimeException("查看配置失敗: " + e.getMessage(), e);
        }
    }

    /**
     * Helm CLI 路徑（嵌入式或系統安裝）
     */
    private String helmBinaryPath = null;
    
    /**
     * 初始化嵌入式 Helm CLI
     * 
     * 在首次使用時從 JAR 中提取 Helm binary 到臨時目錄
     */
    private synchronized void initializeEmbeddedHelm() {
        if (helmBinaryPath != null) {
            return; // 已初始化
        }
        
        try {
            // 檢測操作系統
            String os = System.getProperty("os.name").toLowerCase();
            String helmResource;
            String helmFileName;
            
            if (os.contains("win")) {
                helmResource = "/helm-bin/windows/helm.exe";
                helmFileName = "helm.exe";
            } else if (os.contains("mac") || os.contains("darwin")) {
                helmResource = "/helm-bin/darwin/helm";
                helmFileName = "helm";
            } else {
                helmResource = "/helm-bin/linux/helm";
                helmFileName = "helm";
            }
            
            // 檢查資源是否存在
            InputStream helmStream = getClass().getResourceAsStream(helmResource);
            if (helmStream == null) {
                log.warn("嵌入式 Helm binary 不存在: {}, 嘗試使用系統 Helm", helmResource);
                helmBinaryPath = "helm"; // 回退到系統 Helm
                return;
            }
            
            // 創建臨時目錄
            Path tempDir = Files.createTempDirectory("kubernetes-mcp-helm-");
            Path helmPath = tempDir.resolve(helmFileName);
            
            // 提取 Helm binary
            log.info("正在提取嵌入式 Helm binary 到: {}", helmPath);
            Files.copy(helmStream, helmPath, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            helmStream.close();
            
            // 設置可執行權限（Unix/Linux/macOS）
            if (!os.contains("win")) {
                helmPath.toFile().setExecutable(true);
            }
            
            helmBinaryPath = helmPath.toString();
            log.info("嵌入式 Helm CLI 初始化成功: {}", helmBinaryPath);
            
            // 註冊清理鉤子
            Runtime.getRuntime().addShutdownHook(new Thread(() -> {
                try {
                    Files.deleteIfExists(helmPath);
                    Files.deleteIfExists(tempDir);
                } catch (Exception e) {
                    log.warn("清理臨時 Helm binary 失敗", e);
                }
            }));
            
        } catch (Exception e) {
            log.error("初始化嵌入式 Helm 失敗，回退到系統 Helm", e);
            helmBinaryPath = "helm"; // 回退到系統 Helm
        }
    }
    
    /**
     * 檢查 Helm CLI 是否可用（嵌入式或系統安裝）
     * 
     * @return true 如果 Helm 可用
     */
    private boolean isHelmInstalled() {
        // 初始化嵌入式 Helm
        if (helmBinaryPath == null) {
            initializeEmbeddedHelm();
        }
        
        try {
            ProcessBuilder pb = new ProcessBuilder(helmBinaryPath, "version", "--short");
            pb.redirectErrorStream(true);
            Process process = pb.start();
            int exitCode = process.waitFor();
            boolean available = exitCode == 0;
            
            if (available) {
                log.debug("Helm CLI 可用: {}", helmBinaryPath);
            } else {
                log.warn("Helm CLI 不可用: {}", helmBinaryPath);
            }
            
            return available;
        } catch (Exception e) {
            log.error("檢查 Helm 失敗", e);
            return false;
        }
    }
    
    /**
     * 執行 Helm 命令並返回結果
     * 
     * Helm 會自動使用系統的 kubeconfig (與 K8s MCP Server 相同):
     * - KUBECONFIG 環境變數指定的路徑
     * - 或預設的 ~/.kube/config
     * 
     * @param commands Helm 命令參數（第一個參數應為 "helm"）
     * @return 命令輸出結果
     * @throws Exception 執行失敗時拋出異常
     */
    private String executeHelmCommand(String... commands) throws Exception {
        // 初始化嵌入式 Helm
        if (helmBinaryPath == null) {
            initializeEmbeddedHelm();
        }
        
        // 構建實際命令：使用嵌入式 Helm binary 路徑替換 "helm"
        List<String> actualCommands = new ArrayList<>();
        for (int i = 0; i < commands.length; i++) {
            if (i == 0 && "helm".equals(commands[i])) {
                actualCommands.add(helmBinaryPath);
            } else {
                actualCommands.add(commands[i]);
            }
        }
        
        ProcessBuilder pb = new ProcessBuilder(actualCommands);
        pb.redirectErrorStream(true);
        
        Process process = pb.start();
        
        // 讀取輸出
        StringBuilder output = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                output.append(line).append("\n");
            }
        }
        
        int exitCode = process.waitFor();
        
        if (exitCode != 0) {
            throw new RuntimeException("Helm 命令執行失敗 (exit code: " + exitCode + "): " + output.toString());
        }
        
        return output.toString();
    }
    
    /**
     * 確保 Helm 倉庫已添加
     * 自動添加常用的 Helm 倉庫（如果尚未添加）
     * 
     * @param repoName 倉庫名稱（例如：bitnami, prometheus-community）
     */
    private void ensureHelmRepo(String repoName) {
        try {
            // 定義常用倉庫的 URL 映射
            Map<String, String> repoUrls = new HashMap<>();
            repoUrls.put("bitnami", "https://charts.bitnami.com/bitnami");
            repoUrls.put("prometheus-community", "https://prometheus-community.github.io/helm-charts");
            repoUrls.put("grafana", "https://grafana.github.io/helm-charts");
            repoUrls.put("stable", "https://charts.helm.sh/stable");
            repoUrls.put("ingress-nginx", "https://kubernetes.github.io/ingress-nginx");
            repoUrls.put("jetstack", "https://charts.jetstack.io");
            repoUrls.put("elastic", "https://helm.elastic.co");
            
            String repoUrl = repoUrls.get(repoName);
            if (repoUrl == null) {
                log.debug("未知的倉庫名稱: {}, 跳過自動添加", repoName);
                return;
            }
            
            // 檢查倉庫是否已存在
            try {
                String repoList = executeHelmCommand("helm", "repo", "list", "-o", "json");
                if (repoList.contains("\"name\":\"" + repoName + "\"")) {
                    log.debug("Helm 倉庫 {} 已存在", repoName);
                    return;
                }
            } catch (Exception e) {
                // 倉庫列表為空或其他錯誤,繼續添加
                log.debug("無法獲取倉庫列表，嘗試添加倉庫: {}", e.getMessage());
            }
            
            // 添加倉庫
            log.info("添加 Helm 倉庫: {} -> {}", repoName, repoUrl);
            executeHelmCommand("helm", "repo", "add", repoName, repoUrl);
            
            // 更新倉庫
            log.info("更新 Helm 倉庫: {}", repoName);
            executeHelmCommand("helm", "repo", "update", repoName);
            
            log.info("Helm 倉庫 {} 添加成功", repoName);
            
        } catch (Exception e) {
            log.warn("添加 Helm 倉庫失敗: {} - {}", repoName, e.getMessage());
            // 不拋出異常,讓安裝過程繼續
        }
    }
    
    /**
     * 從 chart 名稱中提取倉庫名稱
     * 
     * @param chart Chart 名稱（例如：bitnami/nginx）
     * @return 倉庫名稱，如果沒有倉庫前綴則返回 null
     */
    private String extractRepoName(String chart) {
        if (chart == null || !chart.contains("/")) {
            return null;
        }
        return chart.substring(0, chart.indexOf("/"));
    }
    
    /**
     * 獲取 Helm 安裝指南
     * 
     * @return Helm 安裝指南的 JSON 格式字符串
     */
    private String getHelmInstallationGuide() {
        StringBuilder guide = new StringBuilder();
        guide.append("{\n");
        guide.append("  \"error\": \"Helm CLI 未安裝\",\n");
        guide.append("  \"message\": \"請先安裝 Helm CLI 工具\",\n");
        guide.append("  \"installation\": {\n");
        guide.append("    \"windows\": {\n");
        guide.append("      \"scoop\": \"scoop install helm\",\n");
        guide.append("      \"chocolatey\": \"choco install kubernetes-helm\",\n");
        guide.append("      \"manual\": \"https://github.com/helm/helm/releases\"\n");
        guide.append("    },\n");
        guide.append("    \"linux\": {\n");
        guide.append("      \"script\": \"curl https://raw.githubusercontent.com/helm/helm/main/scripts/get-helm-3 | bash\",\n");
        guide.append("      \"snap\": \"sudo snap install helm --classic\"\n");
        guide.append("    },\n");
        guide.append("    \"macos\": {\n");
        guide.append("      \"homebrew\": \"brew install helm\"\n");
        guide.append("    },\n");
        guide.append("    \"official\": \"https://helm.sh/docs/intro/install/\"\n");
        guide.append("  }\n");
        guide.append("}");
        return guide.toString();
    }

    /**
     * 安裝 Helm Chart
     * 
     * 使用 Helm 安裝指定的 Chart 到 Kubernetes 集群。
     * 需要系統安裝 Helm CLI 工具。
     * 
     * @param releaseName Release 名稱
     * @param chart Chart 名稱或路徑
     * @param namespace 命名空間
     * @param values 自定義 values（YAML 格式，可選）
     * @return 安裝結果
     */
    public String helmInstall(String releaseName, String chart, String namespace, String values) {
        log.debug("正在安裝 Helm Chart - release: {}, chart: {}, namespace: {}", 
                  releaseName, chart, namespace);
        
        try {
            // 檢查 Helm 是否已安裝
            if (!isHelmInstalled()) {
                log.error("Helm CLI 未安裝");
                return getHelmInstallationGuide();
            }
            
            // 驗證必要參數
            if (releaseName == null || releaseName.trim().isEmpty()) {
                throw new IllegalArgumentException("releaseName 為必要參數，不可為空");
            }
            if (chart == null || chart.trim().isEmpty()) {
                throw new IllegalArgumentException("chart 為必要參數，不可為空");
            }
            
            // 設置默認命名空間
            String targetNamespace = (namespace == null || namespace.trim().isEmpty()) ? "default" : namespace;
            
            // 如果 chart 包含倉庫前綴（例如：bitnami/nginx），自動添加該倉庫
            String repoName = extractRepoName(chart);
            if (repoName != null) {
                log.info("檢測到倉庫前綴: {}, 自動添加倉庫", repoName);
                ensureHelmRepo(repoName);
            }
            
            // 構建 Helm install 命令
            List<String> command = new ArrayList<>();
            command.add("helm");
            command.add("install");
            command.add(releaseName);
            command.add(chart);
            command.add("-n");
            command.add(targetNamespace);
            command.add("--create-namespace");
            command.add("--output");
            command.add("json");
            
            // 如果提供了 values，寫入臨時文件
            Path tempValuesFile = null;
            if (values != null && !values.trim().isEmpty()) {
                tempValuesFile = Files.createTempFile("helm-values-", ".yaml");
                Files.write(tempValuesFile, values.getBytes(StandardCharsets.UTF_8));
                command.add("-f");
                command.add(tempValuesFile.toString());
                log.debug("使用自定義 values 文件: {}", tempValuesFile);
            }
            
            try {
                log.info("執行 Helm install: {}", String.join(" ", command));
                String result = executeHelmCommand(command.toArray(new String[0]));
                
                log.info("Helm Chart 安裝成功 - release: {}", releaseName);
                return result;
                
            } finally {
                // 清理臨時文件
                if (tempValuesFile != null) {
                    try {
                        Files.deleteIfExists(tempValuesFile);
                    } catch (Exception e) {
                        log.warn("清理臨時 values 文件失敗: {}", e.getMessage());
                    }
                }
            }
            
        } catch (Exception e) {
            log.error("安裝 Helm Chart 失敗", e);
            throw new RuntimeException("安裝 Helm Chart 失敗: " + e.getMessage(), e);
        }
    }

    /**
     * 列出 Helm Releases
     * 
     * 列出指定命名空間中的所有 Helm releases。
     * 
     * @param namespace 命名空間（可選，為 null 則列出所有命名空間）
     * @return Releases 列表的 JSON 字符串
     */
    public String helmList(String namespace) {
        log.debug("正在列出 Helm Releases - namespace: {}", namespace);
        
        try {
            // 檢查 Helm 是否已安裝
            if (!isHelmInstalled()) {
                log.error("Helm CLI 未安裝");
                return getHelmInstallationGuide();
            }
            
            // 構建 Helm list 命令
            List<String> command = new ArrayList<>();
            command.add("helm");
            command.add("list");
            
            // 如果指定了命名空間，則只列出該命名空間的 releases
            // 否則列出所有命名空間的 releases
            if (namespace != null && !namespace.trim().isEmpty()) {
                command.add("-n");
                command.add(namespace);
            } else {
                command.add("--all-namespaces");
            }
            
            command.add("--output");
            command.add("json");
            
            log.info("執行 Helm list: {}", String.join(" ", command));
            String result = executeHelmCommand(command.toArray(new String[0]));
            
            log.info("成功列出 Helm Releases");
            return result;
            
        } catch (Exception e) {
            log.error("列出 Helm Releases 失敗", e);
            throw new RuntimeException("列出 Helm Releases 失敗: " + e.getMessage(), e);
        }
    }

    /**
     * 卸載 Helm Release
     * 
     * 從 Kubernetes 集群中卸載指定的 Helm release。
     * 
     * @param releaseName Release 名稱
     * @param namespace 命名空間
     * @return 卸載結果
     */
    public String helmUninstall(String releaseName, String namespace) {
        log.debug("正在卸載 Helm Release - release: {}, namespace: {}", releaseName, namespace);
        
        try {
            // 檢查 Helm 是否已安裝
            if (!isHelmInstalled()) {
                log.error("Helm CLI 未安裝");
                return getHelmInstallationGuide();
            }
            
            // 驗證必要參數
            if (releaseName == null || releaseName.trim().isEmpty()) {
                throw new IllegalArgumentException("releaseName 為必要參數，不可為空");
            }
            if (namespace == null || namespace.trim().isEmpty()) {
                throw new IllegalArgumentException("namespace 為必要參數，不可為空");
            }
            
            // 構建 Helm uninstall 命令
            List<String> command = new ArrayList<>();
            command.add("helm");
            command.add("uninstall");
            command.add(releaseName);
            command.add("-n");
            command.add(namespace);
            
            log.info("執行 Helm uninstall: {}", String.join(" ", command));
            String result = executeHelmCommand(command.toArray(new String[0]));
            
            log.info("Helm Release 卸載成功 - release: {}", releaseName);
            
            // 構建結果 JSON
            StringBuilder response = new StringBuilder();
            response.append("{\n");
            response.append("  \"status\": \"success\",\n");
            response.append("  \"releaseName\": \"").append(releaseName).append("\",\n");
            response.append("  \"namespace\": \"").append(namespace).append("\",\n");
            response.append("  \"message\": \"").append(result.trim()).append("\"\n");
            response.append("}");
            
            return response.toString();
            
        } catch (Exception e) {
            log.error("卸載 Helm Release 失敗", e);
            throw new RuntimeException("卸載 Helm Release 失敗: " + e.getMessage(), e);
        }
    }

    // ========== Private Helper Methods for Dynamic Resource Operations ==========

    /**
     * 計算 Kubernetes 資源類型的複數形式
     * 
     * 根據簡單規則將資源 kind 轉換為 plural 形式，用於 API 路徑。
     * 
     * 規則:
     * - 以 "s" 結尾：加 "es" (例如：Ingress -> ingresses)
     * - 以 "y" 結尾：去掉 "y" 加 "ies" (例如：Policy -> policies)  
     * - 其他情況：加 "s" (例如：Pod -> pods, Deployment -> deployments)
     * 
     * 特殊情況:
     * - Endpoints -> endpoints (已經是複數)
     * 
     * @param kind 資源類型（例如：Pod, Service, Deployment）
     * @return 複數形式（例如：pods, services, deployments）
     */
    private String calculatePluralForm(String kind) {
        if (kind == null || kind.isEmpty()) {
            throw new IllegalArgumentException("Kind 不能為空");
        }
        
        String lower = kind.toLowerCase();
        
        // 特殊情況處理
        if (lower.equals("endpoints") || lower.endsWith("data")) {
            return lower;
        }
        
        // Ingress -> ingresses
        if (lower.endsWith("s") || lower.endsWith("x") || lower.endsWith("z") || 
            lower.endsWith("ch") || lower.endsWith("sh")) {
            return lower + "es";
        }
        
        // Policy -> policies
        if (lower.endsWith("y") && lower.length() > 1 && 
            !isVowel(lower.charAt(lower.length() - 2))) {
            return lower.substring(0, lower.length() - 1) + "ies";
        }
        
        // Pod -> pods, Service -> services
        return lower + "s";
    }

    /**
     * 檢查字元是否為母音
     * 
     * @param c 要檢查的字元
     * @return true 如果是母音
     */
    private boolean isVowel(char c) {
        return "aeiou".indexOf(Character.toLowerCase(c)) >= 0;
    }

    /**
     * Patch Kubernetes 資源
     * 
     * 支援三種 Patch 格式:
     * - JSON Patch (RFC 6902): 使用 JSON Patch 操作陣列修改資源
     * - Strategic Merge Patch: Kubernetes 特有的合併策略
     * - Apply Patch (Server-Side Apply): Kubernetes 1.16+ 的聲明式配置
     * 
     * @param apiVersion API 版本,例如: "v1", "apps/v1"
     * @param kind 資源類型,例如: "Pod", "Deployment"
     * @param namespace 命名空間,cluster-scoped 資源可為 null
     * @param name 資源名稱
     * @param patchContent Patch 內容,JSON 或 YAML 字符串
     * @param patchFormat Patch 格式,使用 V1Patch 常量:
     *                    - V1Patch.PATCH_FORMAT_JSON_PATCH
     *                    - V1Patch.PATCH_FORMAT_STRATEGIC_MERGE_PATCH
     *                    - V1Patch.PATCH_FORMAT_APPLY_YAML
     * @return Patch 後的資源 JSON 字符串
     * @throws ApiException 當 API 調用失敗時
     */
    public String patchResource(String apiVersion, String kind, String namespace, 
                                String name, String patchContent, String patchFormat) 
            throws ApiException {
        try {
            log.info("Patching resource: apiVersion={}, kind={}, namespace={}, name={}, format={}", 
                     apiVersion, kind, namespace, name, patchFormat);
            
            // 驗證 patch 格式
            if (!isValidPatchFormat(patchFormat)) {
                throw new IllegalArgumentException(
                    "不支援的 Patch 格式: " + patchFormat + 
                    "。支援的格式: JSON Patch, Strategic Merge Patch, Apply Patch");
            }
            
            // 建立 DynamicKubernetesApi
            DynamicKubernetesApi dynamicApi = new DynamicKubernetesApi(
                "", 
                apiVersion, 
                calculatePluralForm(kind), 
                apiClient
            );
            
            // 建立 V1Patch 對象
            V1Patch patch = new V1Patch(patchContent);
            
            // 執行 Patch 操作(直接調用 DynamicKubernetesApi 的 patch 方法)
            DynamicKubernetesObject result;
            if (namespace != null && !namespace.isEmpty()) {
                // Namespace-scoped 資源
                result = dynamicApi.patch(namespace, name, patchFormat, patch)
                    .throwsApiException()
                    .getObject();
            } else {
                // Cluster-scoped 資源
                result = dynamicApi.patch(name, patchFormat, patch)
                    .throwsApiException()
                    .getObject();
            }
            
            log.info("Resource patched successfully: {}/{}", kind, name);
            return objectMapper.writeValueAsString(result);
            
        } catch (ApiException e) {
            log.error("Failed to patch resource {}/{}: {}", kind, name, e.getResponseBody(), e);
            throw e;
        } catch (Exception e) {
            log.error("Unexpected error patching resource {}/{}", kind, name, e);
            throw new ApiException("Failed to patch resource: " + e.getMessage());
        }
    }
    
    /**
     * 驗證 Patch 格式是否有效
     * 
     * @param patchFormat Patch 格式字符串
     * @return true 如果格式有效
     */
    private boolean isValidPatchFormat(String patchFormat) {
        return V1Patch.PATCH_FORMAT_JSON_PATCH.equals(patchFormat) ||
               V1Patch.PATCH_FORMAT_STRATEGIC_MERGE_PATCH.equals(patchFormat) ||
               V1Patch.PATCH_FORMAT_APPLY_YAML.equals(patchFormat) ||
               V1Patch.PATCH_FORMAT_JSON_MERGE_PATCH.equals(patchFormat);
    }

    /**
     * 列出指定命名空間中的 Service
     * 
     * @param namespace 命名空間名稱
     * @param labelSelector 標籤選擇器,例如: "app=nginx"
     * @return Service 列表的 JSON 字符串
     * @throws ApiException 當 API 調用失敗時
     */
    public String listServices(String namespace, String labelSelector) throws ApiException {
        try {
            log.info("Listing services in namespace: {}, labelSelector: {}", namespace, labelSelector);
            
            V1ServiceList serviceList = coreV1Api.listNamespacedService(namespace)
                .labelSelector(labelSelector)
                .execute();
            
            log.info("Found {} services in namespace {}", 
                     serviceList.getItems().size(), namespace);
            return objectMapper.writeValueAsString(serviceList);
            
        } catch (ApiException e) {
            log.error("Failed to list services: {}", e.getResponseBody(), e);
            throw e;
        } catch (Exception e) {
            log.error("Unexpected error listing services", e);
            throw new ApiException("Failed to list services: " + e.getMessage());
        }
    }

    /**
     * 列出所有命名空間中的 Service
     * 
     * @param labelSelector 標籤選擇器,例如: "app=nginx"
     * @return Service 列表的 JSON 字符串
     * @throws ApiException 當 API 調用失敗時
     */
    public String listAllServices(String labelSelector) throws ApiException {
        try {
            log.info("Listing all services, labelSelector: {}", labelSelector);
            
            V1ServiceList serviceList = coreV1Api.listServiceForAllNamespaces()
                .labelSelector(labelSelector)
                .execute();
            
            log.info("Found {} services across all namespaces", serviceList.getItems().size());
            return objectMapper.writeValueAsString(serviceList);
            
        } catch (ApiException e) {
            log.error("Failed to list all services: {}", e.getResponseBody(), e);
            throw e;
        } catch (Exception e) {
            log.error("Unexpected error listing all services", e);
            throw new ApiException("Failed to list all services: " + e.getMessage());
        }
    }

    /**
     * 獲取指定 Service 的詳細信息
     * 
     * @param namespace 命名空間名稱
     * @param name Service 名稱
     * @return Service 詳細信息的 JSON 字符串
     * @throws ApiException 當 API 調用失敗時
     */
    public String getService(String namespace, String name) throws ApiException {
        try {
            log.info("Getting service: {}/{}", namespace, name);
            
            V1Service service = coreV1Api.readNamespacedService(name, namespace)
                .execute();
            
            log.info("Retrieved service: {}/{}", namespace, name);
            return objectMapper.writeValueAsString(service);
            
        } catch (ApiException e) {
            log.error("Failed to get service {}/{}: {}", namespace, name, e.getResponseBody(), e);
            throw e;
        } catch (Exception e) {
            log.error("Unexpected error getting service {}/{}", namespace, name, e);
            throw new ApiException("Failed to get service: " + e.getMessage());
        }
    }

    /**
     * 刪除指定的 Service
     * 
     * @param namespace 命名空間名稱
     * @param name Service 名稱
     * @return 刪除狀態的 JSON 字符串
     * @throws ApiException 當 API 調用失敗時
     */
    public String deleteService(String namespace, String name) throws ApiException {
        try {
            log.info("Deleting service: {}/{}", namespace, name);
            
            V1Service service = coreV1Api.deleteNamespacedService(name, namespace)
                .execute();
            
            log.info("Service deleted successfully: {}/{}", namespace, name);
            
            // 返回刪除結果
            Map<String, Object> result = new HashMap<>();
            result.put("deleted", true);
            result.put("name", name);
            result.put("namespace", namespace);
            result.put("kind", "Service");
            result.put("apiVersion", service.getApiVersion());
            
            return objectMapper.writeValueAsString(result);
            
        } catch (ApiException e) {
            log.error("Failed to delete service {}/{}: {}", namespace, name, e.getResponseBody(), e);
            throw e;
        } catch (Exception e) {
            log.error("Unexpected error deleting service {}/{}", namespace, name, e);
            throw new ApiException("Failed to delete service: " + e.getMessage());
        }
    }

    // ======================================
    // File Copy 操作
    // ======================================

    /**
     * 從 Pod 複製檔案到本地
     * 
     * 此方法使用 Copy 類別從指定 Pod 的容器中複製檔案到本地檔案系統。
     * 支援指定容器名稱，如果 Pod 只有一個容器可以留空。
     * 
     * @param namespace 命名空間名稱
     * @param podName Pod 名稱
     * @param containerName 容器名稱（可選，如果 Pod 只有一個容器可以留空）
     * @param sourcePath Pod 中的檔案路徑（例如：/app/config.yaml）
     * @param destPath 本地目標檔案路徑（例如：/tmp/config.yaml）
     * @return 複製操作結果的 JSON 字符串
     * @throws ApiException 當 API 調用失敗時拋出
     */
    public String copyFileFromPod(String namespace, String podName, String containerName, 
                                  String sourcePath, String destPath) throws ApiException {
        try {
            log.info("Copying file from pod {}/{}, container: {}, source: {} to local: {}", 
                    namespace, podName, containerName != null ? containerName : "default", 
                    sourcePath, destPath);
            
            Copy copy = new Copy(apiClient);
            Path destination = Paths.get(destPath);
            
            // 確保目標目錄存在
            if (destination.getParent() != null) {
                Files.createDirectories(destination.getParent());
            }
            
            // 複製檔案
            copy.copyFileFromPod(namespace, podName, containerName, sourcePath, destination);
            
            log.info("File copied successfully from pod to local");
            
            // 返回複製結果
            Map<String, Object> result = new HashMap<>();
            result.put("success", true);
            result.put("namespace", namespace);
            result.put("podName", podName);
            result.put("containerName", containerName != null ? containerName : "default");
            result.put("sourcePath", sourcePath);
            result.put("destPath", destPath);
            result.put("fileSize", Files.size(destination));
            
            return objectMapper.writeValueAsString(result);
            
        } catch (ApiException e) {
            log.error("Failed to copy file from pod {}/{}: {}", namespace, podName, e.getResponseBody(), e);
            throw e;
        } catch (Exception e) {
            log.error("Unexpected error copying file from pod {}/{}", namespace, podName, e);
            throw new ApiException("Failed to copy file from pod: " + e.getMessage());
        }
    }

    /**
     * 複製檔案到 Pod
     * 
     * 此方法使用 Copy 類別將本地檔案複製到指定 Pod 的容器中。
     * 支援指定容器名稱，如果 Pod 只有一個容器可以留空。
     * 
     * @param namespace 命名空間名稱
     * @param podName Pod 名稱
     * @param containerName 容器名稱（可選，如果 Pod 只有一個容器可以留空）
     * @param sourcePath 本地來源檔案路徑（例如：/tmp/config.yaml）
     * @param destPath Pod 中的目標檔案路徑（例如：/app/config.yaml）
     * @return 複製操作結果的 JSON 字符串
     * @throws ApiException 當 API 調用失敗時拋出
     */
    public String copyFileToPod(String namespace, String podName, String containerName, 
                               String sourcePath, String destPath) throws ApiException {
        try {
            log.info("Copying file to pod {}/{}, container: {}, from local: {} to pod: {}", 
                    namespace, podName, containerName != null ? containerName : "default", 
                    sourcePath, destPath);
            
            Copy copy = new Copy(apiClient);
            Path source = Paths.get(sourcePath);
            Path destination = Paths.get(destPath);
            
            // 檢查來源檔案是否存在
            if (!Files.exists(source)) {
                throw new IOException("Source file does not exist: " + sourcePath);
            }
            
            // 複製檔案
            copy.copyFileToPod(namespace, podName, containerName, source, destination);
            
            log.info("File copied successfully from local to pod");
            
            // 返回複製結果
            Map<String, Object> result = new HashMap<>();
            result.put("success", true);
            result.put("namespace", namespace);
            result.put("podName", podName);
            result.put("containerName", containerName != null ? containerName : "default");
            result.put("sourcePath", sourcePath);
            result.put("destPath", destPath);
            result.put("fileSize", Files.size(source));
            
            return objectMapper.writeValueAsString(result);
            
        } catch (ApiException e) {
            log.error("Failed to copy file to pod {}/{}: {}", namespace, podName, e.getResponseBody(), e);
            throw e;
        } catch (Exception e) {
            log.error("Unexpected error copying file to pod {}/{}", namespace, podName, e);
            throw new ApiException("Failed to copy file to pod: " + e.getMessage());
        }
    }

    // ======================================
    // ConfigMap 操作
    // ======================================

    /**
     * 列出指定命名空間中的所有 ConfigMap
     * 
     * 支援通過標籤選擇器過濾 ConfigMap，例如：
     * - "app=nginx"
     * - "app=nginx,env=prod"
     * 
     * @param namespace 命名空間名稱
     * @param labelSelector 標籤選擇器（可選）
     * @return ConfigMap 列表的 JSON 字符串
     * @throws ApiException 當 API 調用失敗時拋出
     */
    public String listConfigMaps(String namespace, String labelSelector) throws ApiException {
        try {
            log.info("Listing ConfigMaps in namespace: {}, labelSelector: {}", namespace, labelSelector);
            
            V1ConfigMapList configMapList;
            if (labelSelector != null && !labelSelector.trim().isEmpty()) {
                configMapList = coreV1Api.listNamespacedConfigMap(namespace)
                    .labelSelector(labelSelector)
                    .execute();
            } else {
                configMapList = coreV1Api.listNamespacedConfigMap(namespace)
                    .execute();
            }
            
            log.info("Found {} ConfigMaps in namespace: {}", configMapList.getItems().size(), namespace);
            return objectMapper.writeValueAsString(configMapList);
            
        } catch (ApiException e) {
            log.error("Failed to list ConfigMaps in namespace {}: {}", namespace, e.getResponseBody(), e);
            throw e;
        } catch (Exception e) {
            log.error("Unexpected error listing ConfigMaps in namespace {}", namespace, e);
            throw new ApiException("Failed to list ConfigMaps: " + e.getMessage());
        }
    }

    /**
     * 獲取指定 ConfigMap 的詳細信息
     * 
     * @param namespace 命名空間名稱
     * @param name ConfigMap 名稱
     * @return ConfigMap 詳細信息的 JSON 字符串
     * @throws ApiException 當 API 調用失敗時拋出
     */
    public String getConfigMap(String namespace, String name) throws ApiException {
        try {
            log.info("Getting ConfigMap: {}/{}", namespace, name);
            
            V1ConfigMap configMap = coreV1Api.readNamespacedConfigMap(name, namespace)
                .execute();
            
            log.info("ConfigMap retrieved successfully: {}/{}", namespace, name);
            return objectMapper.writeValueAsString(configMap);
            
        } catch (ApiException e) {
            log.error("Failed to get ConfigMap {}/{}: {}", namespace, name, e.getResponseBody(), e);
            throw e;
        } catch (Exception e) {
            log.error("Unexpected error getting ConfigMap {}/{}", namespace, name, e);
            throw new ApiException("Failed to get ConfigMap: " + e.getMessage());
        }
    }

    /**
     * 創建 ConfigMap
     * 
     * @param namespace 命名空間名稱
     * @param name ConfigMap 名稱
     * @param data ConfigMap 數據（key-value 對）
     * @param labels 標籤（可選）
     * @return 創建的 ConfigMap 的 JSON 字符串
     * @throws ApiException 當 API 調用失敗時拋出
     */
    public String createConfigMap(String namespace, String name, Map<String, String> data, 
                                  Map<String, String> labels) throws ApiException {
        try {
            log.info("Creating ConfigMap: {}/{}", namespace, name);
            
            V1ConfigMap configMap = new V1ConfigMap()
                .metadata(new V1ObjectMeta()
                    .name(name)
                    .namespace(namespace)
                    .labels(labels))
                .data(data);
            
            V1ConfigMap created = coreV1Api.createNamespacedConfigMap(namespace, configMap)
                .execute();
            
            log.info("ConfigMap created successfully: {}/{}", namespace, name);
            return objectMapper.writeValueAsString(created);
            
        } catch (ApiException e) {
            log.error("Failed to create ConfigMap {}/{}: {}", namespace, name, e.getResponseBody(), e);
            throw e;
        } catch (Exception e) {
            log.error("Unexpected error creating ConfigMap {}/{}", namespace, name, e);
            throw new ApiException("Failed to create ConfigMap: " + e.getMessage());
        }
    }

    /**
     * 刪除 ConfigMap
     * 
     * @param namespace 命名空間名稱
     * @param name ConfigMap 名稱
     * @return 刪除結果的 JSON 字符串
     * @throws ApiException 當 API 調用失敗時拋出
     */
    public String deleteConfigMap(String namespace, String name) throws ApiException {
        try {
            log.info("Deleting ConfigMap: {}/{}", namespace, name);
            
            V1Status status = coreV1Api.deleteNamespacedConfigMap(name, namespace)
                .execute();
            
            log.info("ConfigMap deleted successfully: {}/{}", namespace, name);
            
            // 返回刪除結果
            Map<String, Object> result = new HashMap<>();
            result.put("deleted", true);
            result.put("name", name);
            result.put("namespace", namespace);
            result.put("kind", "ConfigMap");
            result.put("status", status.getStatus());
            
            return objectMapper.writeValueAsString(result);
            
        } catch (ApiException e) {
            log.error("Failed to delete ConfigMap {}/{}: {}", namespace, name, e.getResponseBody(), e);
            throw e;
        } catch (Exception e) {
            log.error("Unexpected error deleting ConfigMap {}/{}", namespace, name, e);
            throw new ApiException("Failed to delete ConfigMap: " + e.getMessage());
        }
    }

    // ======================================
    // Secret 操作
    // ======================================

    /**
     * 列出指定命名空間中的所有 Secret
     * 
     * 支援通過標籤選擇器過濾 Secret，例如：
     * - "app=nginx"
     * - "app=nginx,env=prod"
     * 
     * @param namespace 命名空間名稱
     * @param labelSelector 標籤選擇器（可選）
     * @return Secret 列表的 JSON 字符串
     * @throws ApiException 當 API 調用失敗時拋出
     */
    public String listSecrets(String namespace, String labelSelector) throws ApiException {
        try {
            log.info("Listing Secrets in namespace: {}, labelSelector: {}", namespace, labelSelector);
            
            V1SecretList secretList;
            if (labelSelector != null && !labelSelector.trim().isEmpty()) {
                secretList = coreV1Api.listNamespacedSecret(namespace)
                    .labelSelector(labelSelector)
                    .execute();
            } else {
                secretList = coreV1Api.listNamespacedSecret(namespace)
                    .execute();
            }
            
            log.info("Found {} Secrets in namespace: {}", secretList.getItems().size(), namespace);
            return objectMapper.writeValueAsString(secretList);
            
        } catch (ApiException e) {
            log.error("Failed to list Secrets in namespace {}: {}", namespace, e.getResponseBody(), e);
            throw e;
        } catch (Exception e) {
            log.error("Unexpected error listing Secrets in namespace {}", namespace, e);
            throw new ApiException("Failed to list Secrets: " + e.getMessage());
        }
    }

    /**
     * 獲取指定 Secret 的詳細信息
     * 
     * @param namespace 命名空間名稱
     * @param name Secret 名稱
     * @return Secret 詳細信息的 JSON 字符串
     * @throws ApiException 當 API 調用失敗時拋出
     */
    public String getSecret(String namespace, String name) throws ApiException {
        try {
            log.info("Getting Secret: {}/{}", namespace, name);
            
            V1Secret secret = coreV1Api.readNamespacedSecret(name, namespace)
                .execute();
            
            log.info("Secret retrieved successfully: {}/{}", namespace, name);
            return objectMapper.writeValueAsString(secret);
            
        } catch (ApiException e) {
            log.error("Failed to get Secret {}/{}: {}", namespace, name, e.getResponseBody(), e);
            throw e;
        } catch (Exception e) {
            log.error("Unexpected error getting Secret {}/{}", namespace, name, e);
            throw new ApiException("Failed to get Secret: " + e.getMessage());
        }
    }

    /**
     * 創建 Secret
     * 
     * Secret 數據會自動進行 base64 編碼
     * 
     * @param namespace 命名空間名稱
     * @param name Secret 名稱
     * @param data Secret 數據（原始字符串，會自動進行 base64 編碼）
     * @param type Secret 類型（例如：Opaque, kubernetes.io/tls）
     * @param labels 標籤（可選）
     * @return 創建的 Secret 的 JSON 字符串
     * @throws ApiException 當 API 調用失敗時拋出
     */
    public String createSecret(String namespace, String name, Map<String, String> data, 
                              String type, Map<String, String> labels) throws ApiException {
        try {
            log.info("Creating Secret: {}/{}", namespace, name);
            
            // 將原始字符串數據轉換為 base64 編碼的字節數組
            Map<String, byte[]> encodedData = new HashMap<>();
            for (Map.Entry<String, String> entry : data.entrySet()) {
                encodedData.put(entry.getKey(), entry.getValue().getBytes(StandardCharsets.UTF_8));
            }
            
            V1Secret secret = new V1Secret()
                .metadata(new V1ObjectMeta()
                    .name(name)
                    .namespace(namespace)
                    .labels(labels))
                .type(type != null ? type : "Opaque")
                .data(encodedData);
            
            V1Secret created = coreV1Api.createNamespacedSecret(namespace, secret)
                .execute();
            
            log.info("Secret created successfully: {}/{}", namespace, name);
            return objectMapper.writeValueAsString(created);
            
        } catch (ApiException e) {
            log.error("Failed to create Secret {}/{}: {}", namespace, name, e.getResponseBody(), e);
            throw e;
        } catch (Exception e) {
            log.error("Unexpected error creating Secret {}/{}", namespace, name, e);
            throw new ApiException("Failed to create Secret: " + e.getMessage());
        }
    }

    /**
     * 刪除 Secret
     * 
     * @param namespace 命名空間名稱
     * @param name Secret 名稱
     * @return 刪除結果的 JSON 字符串
     * @throws ApiException 當 API 調用失敗時拋出
     */
    public String deleteSecret(String namespace, String name) throws ApiException {
        try {
            log.info("Deleting Secret: {}/{}", namespace, name);
            
            V1Status status = coreV1Api.deleteNamespacedSecret(name, namespace)
                .execute();
            
            log.info("Secret deleted successfully: {}/{}", namespace, name);
            
            // 返回刪除結果
            Map<String, Object> result = new HashMap<>();
            result.put("deleted", true);
            result.put("name", name);
            result.put("namespace", namespace);
            result.put("kind", "Secret");
            result.put("status", status.getStatus());
            
            return objectMapper.writeValueAsString(result);
            
        } catch (ApiException e) {
            log.error("Failed to delete Secret {}/{}: {}", namespace, name, e.getResponseBody(), e);
            throw e;
        } catch (Exception e) {
            log.error("Unexpected error deleting Secret {}/{}", namespace, name, e);
            throw new ApiException("Failed to delete Secret: " + e.getMessage());
        }
    }

    // ======================================
    // Job 操作
    // ======================================

    /**
     * 列出指定命名空間中的所有 Job
     */
    public String listJobs(String namespace, String labelSelector) throws ApiException {
        try {
            log.info("Listing Jobs in namespace: {}, labelSelector: {}", namespace, labelSelector);
            
            io.kubernetes.client.openapi.models.V1JobList jobList;
            if (labelSelector != null && !labelSelector.trim().isEmpty()) {
                jobList = batchV1Api.listNamespacedJob(namespace)
                    .labelSelector(labelSelector)
                    .execute();
            } else {
                jobList = batchV1Api.listNamespacedJob(namespace)
                    .execute();
            }
            
            log.info("Found {} Jobs in namespace: {}", jobList.getItems().size(), namespace);
            return objectMapper.writeValueAsString(jobList);
            
        } catch (ApiException e) {
            log.error("Failed to list Jobs in namespace {}: {}", namespace, e.getResponseBody(), e);
            throw e;
        } catch (Exception e) {
            log.error("Unexpected error listing Jobs in namespace {}", namespace, e);
            throw new ApiException("Failed to list Jobs: " + e.getMessage());
        }
    }

    /**
     * 獲取指定 Job 的詳細信息
     */
    public String getJob(String namespace, String name) throws ApiException {
        try {
            log.info("Getting Job: {}/{}", namespace, name);
            
            io.kubernetes.client.openapi.models.V1Job job = batchV1Api.readNamespacedJob(name, namespace)
                .execute();
            
            log.info("Job retrieved successfully: {}/{}", namespace, name);
            return objectMapper.writeValueAsString(job);
            
        } catch (ApiException e) {
            log.error("Failed to get Job {}/{}: {}", namespace, name, e.getResponseBody(), e);
            throw e;
        } catch (Exception e) {
            log.error("Unexpected error getting Job {}/{}", namespace, name, e);
            throw new ApiException("Failed to get Job: " + e.getMessage());
        }
    }

    /**
     * 刪除 Job
     */
    public String deleteJob(String namespace, String name) throws ApiException {
        try {
            log.info("Deleting Job: {}/{}", namespace, name);
            
            V1Status status = batchV1Api.deleteNamespacedJob(name, namespace)
                .execute();
            
            log.info("Job deleted successfully: {}/{}", namespace, name);
            
            Map<String, Object> result = new HashMap<>();
            result.put("deleted", true);
            result.put("name", name);
            result.put("namespace", namespace);
            result.put("kind", "Job");
            result.put("status", status.getStatus());
            
            return objectMapper.writeValueAsString(result);
            
        } catch (ApiException e) {
            log.error("Failed to delete Job {}/{}: {}", namespace, name, e.getResponseBody(), e);
            throw e;
        } catch (Exception e) {
            log.error("Unexpected error deleting Job {}/{}", namespace, name, e);
            throw new ApiException("Failed to delete Job: " + e.getMessage());
        }
    }

    // ======================================
    // CronJob 操作
    // ======================================

    /**
     * 列出指定命名空間中的所有 CronJob
     */
    public String listCronJobs(String namespace, String labelSelector) throws ApiException {
        try {
            log.info("Listing CronJobs in namespace: {}, labelSelector: {}", namespace, labelSelector);
            
            io.kubernetes.client.openapi.models.V1CronJobList cronJobList;
            if (labelSelector != null && !labelSelector.trim().isEmpty()) {
                cronJobList = batchV1Api.listNamespacedCronJob(namespace)
                    .labelSelector(labelSelector)
                    .execute();
            } else {
                cronJobList = batchV1Api.listNamespacedCronJob(namespace)
                    .execute();
            }
            
            log.info("Found {} CronJobs in namespace: {}", cronJobList.getItems().size(), namespace);
            return objectMapper.writeValueAsString(cronJobList);
            
        } catch (ApiException e) {
            log.error("Failed to list CronJobs in namespace {}: {}", namespace, e.getResponseBody(), e);
            throw e;
        } catch (Exception e) {
            log.error("Unexpected error listing CronJobs in namespace {}", namespace, e);
            throw new ApiException("Failed to list CronJobs: " + e.getMessage());
        }
    }

    /**
     * 獲取指定 CronJob 的詳細信息
     */
    public String getCronJob(String namespace, String name) throws ApiException {
        try {
            log.info("Getting CronJob: {}/{}", namespace, name);
            
            io.kubernetes.client.openapi.models.V1CronJob cronJob = batchV1Api.readNamespacedCronJob(name, namespace)
                .execute();
            
            log.info("CronJob retrieved successfully: {}/{}", namespace, name);
            return objectMapper.writeValueAsString(cronJob);
            
        } catch (ApiException e) {
            log.error("Failed to get CronJob {}/{}: {}", namespace, name, e.getResponseBody(), e);
            throw e;
        } catch (Exception e) {
            log.error("Unexpected error getting CronJob {}/{}", namespace, name, e);
            throw new ApiException("Failed to get CronJob: " + e.getMessage());
        }
    }

    /**
     * 刪除 CronJob
     */
    public String deleteCronJob(String namespace, String name) throws ApiException {
        try {
            log.info("Deleting CronJob: {}/{}", namespace, name);
            
            V1Status status = batchV1Api.deleteNamespacedCronJob(name, namespace)
                .execute();
            
            log.info("CronJob deleted successfully: {}/{}", namespace, name);
            
            Map<String, Object> result = new HashMap<>();
            result.put("deleted", true);
            result.put("name", name);
            result.put("namespace", namespace);
            result.put("kind", "CronJob");
            result.put("status", status.getStatus());
            
            return objectMapper.writeValueAsString(result);
            
        } catch (ApiException e) {
            log.error("Failed to delete CronJob {}/{}: {}", namespace, name, e.getResponseBody(), e);
            throw e;
        } catch (Exception e) {
            log.error("Unexpected error deleting CronJob {}/{}", namespace, name, e);
            throw new ApiException("Failed to delete CronJob: " + e.getMessage());
        }
    }

    // ======================================
    // Ingress 操作
    // ======================================

    public String listIngresses(String namespace, String labelSelector) throws ApiException {
        try {
            io.kubernetes.client.openapi.models.V1IngressList ingressList;
            if (labelSelector != null && !labelSelector.trim().isEmpty()) {
                ingressList = networkingV1Api.listNamespacedIngress(namespace)
                    .labelSelector(labelSelector)
                    .execute();
            } else {
                ingressList = networkingV1Api.listNamespacedIngress(namespace)
                    .execute();
            }
            return objectMapper.writeValueAsString(ingressList);
        } catch (Exception e) {
            throw new ApiException("Failed to list Ingresses: " + e.getMessage());
        }
    }

    public String getIngress(String namespace, String name) throws ApiException {
        try {
            io.kubernetes.client.openapi.models.V1Ingress ingress = networkingV1Api.readNamespacedIngress(name, namespace)
                .execute();
            return objectMapper.writeValueAsString(ingress);
        } catch (Exception e) {
            throw new ApiException("Failed to get Ingress: " + e.getMessage());
        }
    }

    public String deleteIngress(String namespace, String name) throws ApiException {
        try {
            V1Status status = networkingV1Api.deleteNamespacedIngress(name, namespace)
                .execute();
            log.info("Deleted Ingress: {}/{}, status: {}", namespace, name, status.getStatus());
            Map<String, Object> result = new HashMap<>();
            result.put("deleted", true);
            result.put("name", name);
            result.put("namespace", namespace);
            result.put("kind", "Ingress");
            return objectMapper.writeValueAsString(result);
        } catch (Exception e) {
            throw new ApiException("Failed to delete Ingress: " + e.getMessage());
        }
    }

    // ======================================
    // PVC 操作
    // ======================================

    public String listPVCs(String namespace, String labelSelector) throws ApiException {
        try {
            V1PersistentVolumeClaimList pvcList;
            if (labelSelector != null && !labelSelector.trim().isEmpty()) {
                pvcList = coreV1Api.listNamespacedPersistentVolumeClaim(namespace)
                    .labelSelector(labelSelector)
                    .execute();
            } else {
                pvcList = coreV1Api.listNamespacedPersistentVolumeClaim(namespace)
                    .execute();
            }
            return objectMapper.writeValueAsString(pvcList);
        } catch (Exception e) {
            throw new ApiException("Failed to list PVCs: " + e.getMessage());
        }
    }

    public String getPVC(String namespace, String name) throws ApiException {
        try {
            V1PersistentVolumeClaim pvc = coreV1Api.readNamespacedPersistentVolumeClaim(name, namespace)
                .execute();
            return objectMapper.writeValueAsString(pvc);
        } catch (Exception e) {
            throw new ApiException("Failed to get PVC: " + e.getMessage());
        }
    }

    public String deletePVC(String namespace, String name) throws ApiException {
        try {
            V1PersistentVolumeClaim pvc = coreV1Api.deleteNamespacedPersistentVolumeClaim(name, namespace)
                .execute();
            log.info("Deleted PVC: {}/{}, uid: {}", namespace, name, pvc.getMetadata() != null ? pvc.getMetadata().getUid() : "unknown");
            Map<String, Object> result = new HashMap<>();
            result.put("deleted", true);
            result.put("name", name);
            result.put("namespace", namespace);
            result.put("kind", "PersistentVolumeClaim");
            return objectMapper.writeValueAsString(result);
        } catch (Exception e) {
            throw new ApiException("Failed to delete PVC: " + e.getMessage());
        }
    }

    // ======================================
    // StatefulSet 操作
    // ======================================

    public String listStatefulSets(String namespace, String labelSelector) throws ApiException {
        try {
            V1StatefulSetList statefulSetList;
            if (labelSelector != null && !labelSelector.trim().isEmpty()) {
                statefulSetList = appsV1Api.listNamespacedStatefulSet(namespace)
                    .labelSelector(labelSelector)
                    .execute();
            } else {
                statefulSetList = appsV1Api.listNamespacedStatefulSet(namespace)
                    .execute();
            }
            return objectMapper.writeValueAsString(statefulSetList);
        } catch (Exception e) {
            throw new ApiException("Failed to list StatefulSets: " + e.getMessage());
        }
    }

    public String getStatefulSet(String namespace, String name) throws ApiException {
        try {
            V1StatefulSet statefulSet = appsV1Api.readNamespacedStatefulSet(name, namespace)
                .execute();
            return objectMapper.writeValueAsString(statefulSet);
        } catch (Exception e) {
            throw new ApiException("Failed to get StatefulSet: " + e.getMessage());
        }
    }

    public String deleteStatefulSet(String namespace, String name) throws ApiException {
        try {
            V1Status status = appsV1Api.deleteNamespacedStatefulSet(name, namespace)
                .execute();
            log.info("Deleted StatefulSet: {}/{}, status: {}", namespace, name, status.getStatus());
            Map<String, Object> result = new HashMap<>();
            result.put("deleted", true);
            result.put("name", name);
            result.put("namespace", namespace);
            result.put("kind", "StatefulSet");
            return objectMapper.writeValueAsString(result);
        } catch (Exception e) {
            throw new ApiException("Failed to delete StatefulSet: " + e.getMessage());
        }
    }

    public String scaleStatefulSet(String namespace, String name, int replicas) throws ApiException {
        try {
            V1StatefulSet statefulSet = appsV1Api.readNamespacedStatefulSet(name, namespace)
                .execute();
            statefulSet.getSpec().setReplicas(replicas);
            V1StatefulSet updated = appsV1Api.replaceNamespacedStatefulSet(name, namespace, statefulSet)
                .execute();
            return objectMapper.writeValueAsString(updated);
        } catch (Exception e) {
            throw new ApiException("Failed to scale StatefulSet: " + e.getMessage());
        }
    }
}

