package com.momo.ltsre.kubernetes.config;

import io.kubernetes.client.openapi.ApiClient;
import io.kubernetes.client.openapi.apis.AppsV1Api;
import io.kubernetes.client.openapi.apis.BatchV1Api;
import io.kubernetes.client.openapi.apis.CoreV1Api;
import io.kubernetes.client.openapi.apis.NetworkingV1Api;
import io.kubernetes.client.openapi.apis.CustomObjectsApi;
import io.kubernetes.client.util.Config;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;

/**
 * Kubernetes 客戶端配置類別
 * 
 * 此類別負責初始化 Kubernetes Java Client 的核心組件，
 * 包括 ApiClient 和各種 API 實例（CoreV1Api, AppsV1Api 等）。
 * 
 * 支援多種認證方式：
 * - Kubeconfig 文件
 * - In-Cluster 配置（運行在 Pod 內）
 * - 默認配置（自動檢測）
 * 
 * @author pf2tsai
 * @version 1.0.0
 */
@Slf4j
@Configuration
public class KubernetesClientConfig {

    /**
     * Kubeconfig 文件路徑（可選）
     * 如果未設置，將使用默認配置
     */
    @Value("${kubernetes.config.path:}")
    private String kubeconfigPath;

    /**
     * 請求超時時間（秒）
     */
    @Value("${kubernetes.request.timeout:30}")
    private int requestTimeout;

    /**
     * 創建並配置 Kubernetes ApiClient
     * 
     * ApiClient 是所有 Kubernetes API 操作的基礎客戶端，
     * 負責處理認證、請求發送、響應解析等底層操作。
     * 
     * @return 配置好的 ApiClient 實例
     * @throws IOException 如果讀取 kubeconfig 文件失敗
     */
    @Bean
    public ApiClient kubernetesApiClient() throws IOException {
        log.info("正在初始化 Kubernetes ApiClient...");
        
        ApiClient client;
        
        // 根據配置選擇不同的初始化方式
        if (kubeconfigPath != null && !kubeconfigPath.isEmpty()) {
            // 使用指定的 kubeconfig 文件（明確使用 UTF-8 編碼）
            log.info("使用 kubeconfig 文件: {}", kubeconfigPath);
            String kubeconfigContent = Files.readString(Paths.get(kubeconfigPath), StandardCharsets.UTF_8);
            client = Config.fromConfig(new java.io.StringReader(kubeconfigContent));
        } else {
            // 使用默認配置（會自動檢測 ~/.kube/config 或 in-cluster 配置）
            // 明確使用 UTF-8 編碼讀取 kubeconfig
            log.info("使用默認 Kubernetes 配置");
            String defaultKubeconfigPath = System.getProperty("user.home") + "/.kube/config";
            if (Files.exists(Paths.get(defaultKubeconfigPath))) {
                log.info("從預設路徑讀取 kubeconfig: {}", defaultKubeconfigPath);
                String kubeconfigContent = Files.readString(Paths.get(defaultKubeconfigPath), StandardCharsets.UTF_8);
                client = Config.fromConfig(new java.io.StringReader(kubeconfigContent));
            } else {
                // 嘗試 in-cluster 配置
                log.info("嘗試使用 in-cluster 配置");
                client = Config.defaultClient();
            }
        }
        
        // 設置請求超時
        client.setHttpClient(
            client.getHttpClient().newBuilder()
                .connectTimeout(requestTimeout, java.util.concurrent.TimeUnit.SECONDS)
                .readTimeout(requestTimeout, java.util.concurrent.TimeUnit.SECONDS)
                .writeTimeout(requestTimeout, java.util.concurrent.TimeUnit.SECONDS)
                .build()
        );
        
        // 設置為全局默認客戶端
        io.kubernetes.client.openapi.Configuration.setDefaultApiClient(client);
        
        log.info("Kubernetes ApiClient 初始化完成");
        log.info("API Server: {}", client.getBasePath());
        
        return client;
    }

    /**
     * 創建 CoreV1Api 實例
     * 
     * CoreV1Api 用於操作 Kubernetes 核心資源，包括：
     * - Pod: 容器組
     * - Service: 服務
     * - ConfigMap: 配置映射
     * - Secret: 敏感信息
     * - Namespace: 命名空間
     * - Node: 節點
     * - Event: 事件
     * - PersistentVolume: 持久化卷
     * 等等
     * 
     * @param apiClient Kubernetes API 客戶端
     * @return CoreV1Api 實例
     */
    @Bean
    public CoreV1Api coreV1Api(ApiClient apiClient) {
        log.info("正在創建 CoreV1Api 實例...");
        return new CoreV1Api(apiClient);
    }

    /**
     * 創建 AppsV1Api 實例
     * 
     * AppsV1Api 用於操作應用程式相關資源，包括：
     * - Deployment: 部署
     * - StatefulSet: 有狀態集合
     * - DaemonSet: 守護進程集合
     * - ReplicaSet: 副本集合
     * 
     * @param apiClient Kubernetes API 客戶端
     * @return AppsV1Api 實例
     */
    @Bean
    public AppsV1Api appsV1Api(ApiClient apiClient) {
        log.info("正在創建 AppsV1Api 實例...");
        return new AppsV1Api(apiClient);
    }

    /**
     * 創建 BatchV1Api 實例
     * 
     * BatchV1Api 用於操作批處理作業資源，包括：
     * - Job: 一次性作業
     * - CronJob: 定時作業
     * 
     * @param apiClient Kubernetes API 客戶端
     * @return BatchV1Api 實例
     */
    @Bean
    public BatchV1Api batchV1Api(ApiClient apiClient) {
        log.info("正在創建 BatchV1Api 實例...");
        return new BatchV1Api(apiClient);
    }

    /**
     * 創建 NetworkingV1Api 實例
     * 
     * NetworkingV1Api 用於操作網絡相關資源，包括：
     * - Ingress: 入口規則
     * - NetworkPolicy: 網絡策略
     * - IngressClass: 入口類別
     * 
     * @param apiClient Kubernetes API 客戶端
     * @return NetworkingV1Api 實例
     */
    @Bean
    public NetworkingV1Api networkingV1Api(ApiClient apiClient) {
        log.info("正在創建 NetworkingV1Api 實例...");
        return new NetworkingV1Api(apiClient);
    }

    /**
     * 創建 CustomObjectsApi 實例
     * 
     * CustomObjectsApi 是 DynamicKubernetesApi 的底層依賴，
     * 用於操作任意 Kubernetes 資源（包括自定義資源）。
     * 它提供了通用的 CRUD 操作介面，不需要預先生成資源類別。
     * 
     * 支援的操作：
     * - 列出資源（cluster-scoped 或 namespaced）
     * - 獲取單個資源
     * - 創建資源
     * - 更新資源
     * - 刪除資源
     * - Patch 操作
     * 
     * @param apiClient Kubernetes API 客戶端
     * @return CustomObjectsApi 實例
     */
    @Bean
    public CustomObjectsApi customObjectsApi(ApiClient apiClient) {
        log.info("正在創建 CustomObjectsApi 實例...");
        return new CustomObjectsApi(apiClient);
    }
}

