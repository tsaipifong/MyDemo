package com.momo.ltsre.kubernetes.mcp;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.momo.ltsre.kubernetes.service.K8sOperationService;
import io.kubernetes.client.openapi.ApiException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Kubernetes MCP 工具服務
 * 
 * 這是 MCP 層的核心類別，使用 Spring AI 的 @Tool 註解
 * 將 Kubernetes 操作暴露為 MCP 工具。
 * 
 * 架構層次：
 * - Infrastructure 層: KubernetesClientConfig (CoreV1Api, AppsV1Api)
 * - Service 層: K8sOperationService (業務邏輯)
 * - MCP 層: McpK8sToolsService (本類別 - @Tool 註解方法)
 * 
 * 每個 @Tool 方法都會：
 * 1. 接收 MCP 客戶端的請求參數
 * 2. 調用 Service 層執行實際操作
 * 3. 將結果轉換為 JSON 格式返回
 * 
 * @author pf2tsai
 * @version 1.0.0
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class McpK8sToolsService {

    /**
     * K8s 操作服務（Service 層）
     */
    private final K8sOperationService k8sOperationService;

    /**
     * JSON 序列化工具(線程安全，可重用)
     * 註冊 JavaTimeModule 以支援 Java 8 日期時間類型
     */
    private final ObjectMapper objectMapper = new ObjectMapper().registerModule(new JavaTimeModule());

    /**
     * 列出指定命名空間中的 Pod
     * 
     * 此工具允許查詢 Kubernetes 集群中的 Pod 列表，
     * 支援通過命名空間和標籤選擇器進行過濾。
     * 
     * 使用範例：
     * - 列出 default 命名空間的所有 Pod: listMyK8sPods("default", null)
     * - 列出帶有 app=nginx 標籤的 Pod: listMyK8sPods("default", "app=nginx")
     * - 列出多個標籤: listMyK8sPods("default", "app=nginx,env=prod")
     * 
     * @param namespace 命名空間名稱，例如 "default", "kube-system"。如果為空，使用默認命名空間
     * @param labelSelector 標籤選擇器，例如 "app=nginx" 或 "app=nginx,env=prod"。如果為空，返回所有 Pod
     * @return JSON 格式的響應，包含 success (是否成功), data (Pod 列表), message (提示信息)
     */
    @Tool(description = "列出指定命名空間中的 Pod。支援通過標籤選擇器過濾 Pod。" +
                       "例如：labelSelector=\"app=nginx\" 或 \"app=nginx,env=prod\"。" +
                       "如果 namespace 為空，使用默認命名空間 (default)。")
    public String listMyK8sPods(
        @ToolParam(description = "命名空間名稱，例如 'default', 'kube-system'。留空使用默認命名空間") 
        String namespace,
        
        @ToolParam(description = "標籤選擇器，例如 'app=nginx' 或 'app=nginx,env=prod'。留空返回所有 Pod") 
        String labelSelector
    ) {
        try {
            log.info("MCP 工具調用: listMyK8sPods - namespace: {}, labelSelector: {}", namespace, labelSelector);
            return k8sOperationService.listPods(namespace, labelSelector);
        } catch (ApiException e) {
            log.error("列出 Pod 失敗: {}", e.getResponseBody(), e);
            return createErrorResponse("列出 Pod 失敗", e.getMessage());
        } catch (Exception e) {
            log.error("列出 Pod 時發生異常", e);
            return createErrorResponse("系統錯誤", e.getMessage());
        }
    }

    /**
     * 列出所有命名空間中的 Pod
     * 
     * 此工具會跨所有命名空間查詢 Pod，
     * 適用於需要全局視圖的場景。
     * 
     * @param labelSelector 標籤選擇器，例如 "app=nginx"。如果為空，返回所有 Pod
     * @return JSON 格式的響應
     */
    @Tool(description = "列出所有命名空間中的 Pod。支援通過標籤選擇器過濾。" +
                       "這會返回整個集群中的 Pod，適合全局查詢。")
    public String listAllMyK8sPods(
        @ToolParam(description = "標籤選擇器，例如 'app=nginx'。留空返回所有 Pod") 
        String labelSelector
    ) {
        try {
            log.info("MCP 工具調用: listAllMyK8sPods - labelSelector: {}", labelSelector);
            return k8sOperationService.listAllPods(labelSelector);
        } catch (ApiException e) {
            log.error("列出所有 Pod 失敗: {}", e.getResponseBody(), e);
            return createErrorResponse("列出 Pod 失敗", e.getMessage());
        } catch (Exception e) {
            log.error("列出所有 Pod 時發生異常", e);
            return createErrorResponse("系統錯誤", e.getMessage());
        }
    }

    /**
     * 獲取 Pod 日誌
     * 
     * 此工具用於讀取 Pod 中容器的日誌輸出，
     * 對於故障排查和監控非常有用。
     * 
     * @param namespace 命名空間名稱
     * @param podName Pod 名稱
     * @param containerName 容器名稱（可選）。如果 Pod 只有一個容器，可以不指定
     * @param tailLines 返回最後 N 行日誌（可選）。例如 100 表示返回最後 100 行
     * @return JSON 格式的響應，包含日誌內容
     */
    @Tool(description = "獲取 Pod 的日誌內容。可以指定容器名稱和返回的行數。" +
                       "如果 Pod 只有一個容器，containerName 可以留空。" +
                       "tailLines 可以限制返回的日誌行數，例如 100 表示最後 100 行。")
    public String getMyK8sPodLogs(
        @ToolParam(description = "命名空間名稱") 
        String namespace,
        
        @ToolParam(description = "Pod 名稱") 
        String podName,
        
        @ToolParam(description = "容器名稱（可選）。如果 Pod 只有一個容器可以留空") 
        String containerName,
        
        @ToolParam(description = "返回最後 N 行日誌（可選），例如 100") 
        Integer tailLines
    ) {
        Map<String, Object> response = new HashMap<>();
        
        try {
            log.info("MCP 工具調用: getMyK8sPodLogs - pod: {}/{}, container: {}, tailLines: {}", 
                     namespace, podName, containerName, tailLines);
            
            String logs = k8sOperationService.getPodLogs(namespace, podName, containerName, tailLines);
            
            response.put("success", true);
            response.put("logs", logs);
            response.put("pod", podName);
            response.put("namespace", namespace);
            response.put("container", containerName);
            response.put("message", "成功獲取 Pod 日誌");
            
        } catch (ApiException e) {
            log.error("獲取 Pod 日誌失敗: {}", e.getResponseBody(), e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "獲取日誌失敗: " + e.getMessage());
        } catch (Exception e) {
            log.error("獲取 Pod 日誌時發生異常", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "系統錯誤: " + e.getMessage());
        }
        
        return convertToJsonString(response);
    }

    /**
     * 刪除 Pod
     * 
     * 此工具用於刪除指定的 Pod。
     * 注意：如果 Pod 由 Deployment 或其他控制器管理，
     * 刪除後會自動重新創建。
     * 
     * @param namespace 命名空間名稱
     * @param podName Pod 名稱
     * @return JSON 格式的響應
     */
    @Tool(description = "刪除指定的 Pod。注意：如果 Pod 由 Deployment 管理，刪除後會自動重建。")
    public String deleteMyK8sPod(
        @ToolParam(description = "命名空間名稱") 
        String namespace,
        
        @ToolParam(description = "要刪除的 Pod 名稱") 
        String podName
    ) {
        Map<String, Object> response = new HashMap<>();
        
        try {
            log.info("MCP 工具調用: deleteMyK8sPod - pod: {}/{}", namespace, podName);
            
            k8sOperationService.deletePod(namespace, podName);
            
            response.put("success", true);
            response.put("pod", podName);
            response.put("namespace", namespace);
            response.put("message", String.format("成功刪除 Pod: %s/%s", namespace, podName));
            
        } catch (ApiException e) {
            log.error("刪除 Pod 失敗: {}", e.getResponseBody(), e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "刪除 Pod 失敗: " + e.getMessage());
        } catch (Exception e) {
            log.error("刪除 Pod 時發生異常", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "系統錯誤: " + e.getMessage());
        }
        
        return convertToJsonString(response);
    }

    /**
     * 列出指定命名空間中的 Deployment
     * 
     * @param namespace 命名空間名稱
     * @param labelSelector 標籤選擇器（可選）
     * @return JSON 格式的響應
     */
    @Tool(description = "列出指定命名空間中的 Deployment。Deployment 是 Kubernetes 中管理 Pod 副本的控制器。" +
                       "支援通過標籤選擇器過濾 Deployment。")
    public String listMyK8sDeployments(
        @ToolParam(description = "命名空間名稱", required = true) 
        String namespace,
        
        @ToolParam(description = "標籤選擇器（可選），例如 'app=nginx'。留空返回所有 Deployment", required = false) 
        String labelSelector
    ) {
        try {
            log.info("MCP 工具調用: listMyK8sDeployments - namespace: {}, labelSelector: {}", namespace, labelSelector);
            return k8sOperationService.listDeployments(namespace, labelSelector);
        } catch (ApiException e) {
            log.error("列出 Deployment 失敗: {}", e.getResponseBody(), e);
            return createErrorResponse("列出 Deployment 失敗", e.getMessage());
        } catch (Exception e) {
            log.error("列出 Deployment 時發生異常", e);
            return createErrorResponse("系統錯誤", e.getMessage());
        }
    }

    /**
     * 獲取特定 Deployment 的詳細信息
     * 
     * @param namespace 命名空間名稱
     * @param deploymentName Deployment 名稱
     * @return JSON 格式的響應
     */
    @Tool(description = "獲取指定 Deployment 的詳細信息，包括副本數、鏡像、狀態等。")
    public String getMyK8sDeployment(
        @ToolParam(description = "命名空間名稱") 
        String namespace,
        
        @ToolParam(description = "Deployment 名稱") 
        String deploymentName
    ) {
        try {
            log.info("MCP 工具調用: getMyK8sDeployment - deployment: {}/{}", namespace, deploymentName);
            return k8sOperationService.getDeployment(namespace, deploymentName);
        } catch (ApiException e) {
            log.error("獲取 Deployment 失敗: {}", e.getResponseBody(), e);
            return createErrorResponse("獲取 Deployment 失敗", e.getMessage());
        } catch (Exception e) {
            log.error("獲取 Deployment 時發生異常", e);
            return createErrorResponse("系統錯誤", e.getMessage());
        }
    }

    /**
     * 刪除 Deployment
     * 
     * @param namespace 命名空間名稱
     * @param deploymentName Deployment 名稱
     * @return JSON 格式的響應
     */
    @Tool(description = "刪除指定的 Deployment。這也會刪除該 Deployment 管理的所有 Pod。")
    public String deleteMyK8sDeployment(
        @ToolParam(description = "命名空間名稱") 
        String namespace,
        
        @ToolParam(description = "要刪除的 Deployment 名稱") 
        String deploymentName
    ) {
        try {
            log.info("MCP 工具調用: deleteMyK8sDeployment - deployment: {}/{}", namespace, deploymentName);
            return k8sOperationService.deleteDeployment(namespace, deploymentName);
        } catch (ApiException e) {
            log.error("刪除 Deployment 失敗: {}", e.getResponseBody(), e);
            return createErrorResponse("刪除 Deployment 失敗", e.getMessage());
        } catch (Exception e) {
            log.error("刪除 Deployment 時發生異常", e);
            return createErrorResponse("系統錯誤", e.getMessage());
        }
    }

    /**
     * 縮放 Deployment
     * 
     * 此工具用於調整 Deployment 的副本數量，
     * 實現水平擴展或縮減。
     * 
     * @param namespace 命名空間名稱
     * @param deploymentName Deployment 名稱
     * @param replicas 目標副本數（必須 >= 0）
     * @return JSON 格式的響應
     */
    @Tool(description = "縮放 Deployment 的副本數量。設置 replicas 為目標副本數，" +
                       "例如 3 表示運行 3 個 Pod 副本。設為 0 可以停止所有 Pod。")
    public String scaleMyK8sDeployment(
        @ToolParam(description = "命名空間名稱") 
        String namespace,
        
        @ToolParam(description = "Deployment 名稱") 
        String deploymentName,
        
        @ToolParam(description = "目標副本數，例如 3。設為 0 可停止所有 Pod") 
        int replicas
    ) {
        Map<String, Object> response = new HashMap<>();
        
        try {
            log.info("MCP 工具調用: scaleMyK8sDeployment - deployment: {}/{}, replicas: {}", 
                     namespace, deploymentName, replicas);
            
            if (replicas < 0) {
                response.put("success", false);
                response.put("message", "副本數不能為負數");
                return convertToJsonString(response);
            }
            
            k8sOperationService.scaleDeployment(namespace, deploymentName, replicas);
            
            response.put("success", true);
            response.put("deployment", deploymentName);
            response.put("namespace", namespace);
            response.put("replicas", replicas);
            response.put("message", String.format("成功將 Deployment %s/%s 縮放至 %d 個副本", 
                                                  namespace, deploymentName, replicas));
            
        } catch (ApiException e) {
            log.error("縮放 Deployment 失敗: {}", e.getResponseBody(), e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "縮放 Deployment 失敗: " + e.getMessage());
        } catch (Exception e) {
            log.error("縮放 Deployment 時發生異常", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "系統錯誤: " + e.getMessage());
        }
        
        return convertToJsonString(response);
    }

    /**
     * 獲取單個 Pod 的詳細信息
     * 
     * @param namespace 命名空間名稱
     * @param podName Pod 名稱
     * @return JSON 格式的響應
     */
    @Tool(description = "獲取 Kubernetes Pod 的詳細信息，包括狀態、容器信息、重啟次數等。")
    public String getMyK8sPod(
        @ToolParam(description = "命名空間名稱") 
        String namespace,
        
        @ToolParam(description = "Pod 名稱") 
        String podName
    ) {
        try {
            log.info("MCP 工具調用: getMyK8sPod - pod: {}/{}", namespace, podName);
            return k8sOperationService.getPod(namespace, podName);
        } catch (ApiException e) {
            log.error("獲取 Pod 詳細信息失敗: {}", e.getResponseBody(), e);
            return createErrorResponse("獲取 Pod 失敗", e.getMessage());
        } catch (Exception e) {
            log.error("獲取 Pod 詳細信息時發生異常", e);
            return createErrorResponse("系統錯誤", e.getMessage());
        }
    }

    /**
     * 在 Pod 中執行命令
     * 
     * @param namespace 命名空間名稱
     * @param podName Pod 名稱
     * @param containerName 容器名稱（可選）
     * @param command 要執行的命令（JSON 數組字符串）
     * @return JSON 格式的響應
     */
    @Tool(description = "在 Kubernetes Pod 的容器中執行命令。" +
                       "命令應該是一個數組，第一個元素是要執行的命令，後續元素是參數。" +
                       "例如: [\"ls\", \"-la\", \"/tmp\"]")
    public String execMyK8sPod(
        @ToolParam(description = "命名空間名稱") 
        String namespace,
        
        @ToolParam(description = "Pod 名稱") 
        String podName,
        
        @ToolParam(description = "容器名稱（可選）。如果 Pod 只有一個容器可以留空") 
        String containerName,
        
        @ToolParam(description = "要執行的命令數組，例如: [\"ls\", \"-la\"]") 
        String command
    ) {
        Map<String, Object> response = new HashMap<>();
        
        try {
            log.info("MCP 工具調用: execMyK8sPod - pod: {}/{}, container: {}, command: {}", 
                     namespace, podName, containerName, command);
            
            // 解析命令 JSON 數組
            List<String> commandList = objectMapper.readValue(command, 
                objectMapper.getTypeFactory().constructCollectionType(List.class, String.class));
            
            String result = k8sOperationService.execPod(namespace, podName, containerName, commandList);
            
            response.put("success", true);
            response.put("output", result);
            response.put("message", "命令執行完成");
            
        } catch (ApiException e) {
            log.error("執行 Pod 命令失敗: {}", e.getResponseBody(), e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "執行命令失敗: " + e.getMessage());
        } catch (Exception e) {
            log.error("執行 Pod 命令時發生異常", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "系統錯誤: " + e.getMessage());
        }
        
        return convertToJsonString(response);
    }

    /**
     * 運行一個新的 Pod
     * 
     * @param namespace 命名空間名稱
     * @param podName Pod 名稱（可選）
     * @param image 容器鏡像
     * @param port 暴露的端口（可選）
     * @return JSON 格式的響應
     */
    @Tool(description = "在 Kubernetes 中運行一個新的 Pod。" +
                       "可以指定容器鏡像、名稱和暴露的端口。")
    public String runMyK8sPod(
        @ToolParam(description = "命名空間名稱") 
        String namespace,
        
        @ToolParam(description = "Pod 名稱（可選）。如果不提供，將自動生成") 
        String podName,
        
        @ToolParam(description = "容器鏡像，例如: nginx:latest, redis:alpine") 
        String image,
        
        @ToolParam(description = "要暴露的容器端口（可選）") 
        Integer port
    ) {
        try {
            log.info("MCP 工具調用: runMyK8sPod - namespace: {}, name: {}, image: {}, port: {}", 
                     namespace, podName, image, port);
            return k8sOperationService.runPod(namespace, podName, image, port);
        } catch (ApiException e) {
            log.error("運行 Pod 失敗: {}", e.getResponseBody(), e);
            return createErrorResponse("運行 Pod 失敗", e.getMessage());
        } catch (Exception e) {
            log.error("運行 Pod 時發生異常", e);
            return createErrorResponse("系統錯誤", e.getMessage());
        }
    }

    /**
     * 獲取 Pod 資源使用率
     * 
     * @param namespace 命名空間名稱（可選）
     * @param podName Pod 名稱（可選）
     * @param labelSelector 標籤選擇器（可選）
     * @return JSON 格式的響應
     */
    @Tool(description = "獲取 Kubernetes Pod 的資源使用率（CPU 和 Memory）。" +
                       "需要集群安裝 Metrics Server。")
    public String topMyK8sPods(
        @ToolParam(description = "命名空間名稱（可選）") 
        String namespace,
        
        @ToolParam(description = "Pod 名稱（可選）") 
        String podName,
        
        @ToolParam(description = "標籤選擇器（可選），例如: app=nginx") 
        String labelSelector
    ) {
        Map<String, Object> response = new HashMap<>();
        
        try {
            log.info("MCP 工具調用: topMyK8sPods - namespace: {}, pod: {}, labelSelector: {}", 
                     namespace, podName, labelSelector);
            
            String result = k8sOperationService.getPodTop(namespace, podName, labelSelector);
            
            response.put("success", true);
            response.put("data", result);
            response.put("message", "成功獲取 Pod 資源使用率");
            
        } catch (ApiException e) {
            log.error("獲取 Pod 資源使用率失敗: {}", e.getResponseBody(), e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "獲取資源使用率失敗: " + e.getMessage());
        } catch (Exception e) {
            log.error("獲取 Pod 資源使用率時發生異常", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "系統錯誤: " + e.getMessage());
        }
        
        return convertToJsonString(response);
    }

    /**
     * 列出所有命名空間
     * 
     * @param labelSelector 標籤選擇器（可選），用於過濾命名空間
     * @return JSON 格式的響應，包含命名空間列表
     */
    @Tool(description = "列出 Kubernetes 集群中的所有命名空間。" +
                       "命名空間用於在集群中劃分資源邊界，實現多租戶隔離。" +
                       "支援通過標籤選擇器過濾命名空間。")
    public String listMyK8sNamespaces(
        @ToolParam(description = "標籤選擇器（可選），例如 'env=prod'。留空返回所有命名空間", required = false) 
        String labelSelector
    ) {
        Map<String, Object> response = new HashMap<>();
        
        try {
            log.info("MCP 工具調用: listMyK8sNamespaces - labelSelector: {}", labelSelector);
            
            List<String> namespaces = k8sOperationService.listNamespaces(labelSelector);
            
            response.put("success", true);
            response.put("data", namespaces);
            response.put("count", namespaces.size());
            response.put("message", String.format("成功列出 %d 個命名空間", namespaces.size()));
            
        } catch (ApiException e) {
            log.error("列出命名空間失敗: {}", e.getResponseBody(), e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "列出命名空間失敗: " + e.getMessage());
        } catch (Exception e) {
            log.error("列出命名空間時發生異常", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "系統錯誤: " + e.getMessage());
        }
        
        return convertToJsonString(response);
    }

    /**
     * 列出通用 Kubernetes 資源
     * 
     * @param apiVersion 資源 API 版本
     * @param kind 資源類型
     * @param namespace 命名空間（可選）
     * @param labelSelector 標籤選擇器（可選）
     * @return JSON 格式的響應
     */
    @Tool(description = "列出 Kubernetes 資源。" +
                       "支援任意資源類型，例如：Service, ConfigMap, Secret, Ingress 等。" +
                       "常用的 apiVersion 和 kind 組合：" +
                       "v1 Service, v1 ConfigMap, v1 Secret, " +
                       "apps/v1 Deployment, networking.k8s.io/v1 Ingress")
    public String listMyK8sResources(
        @ToolParam(description = "API 版本，例如：v1, apps/v1, networking.k8s.io/v1") 
        String apiVersion,
        
        @ToolParam(description = "資源類型，例如：Service, ConfigMap, Secret, Ingress") 
        String kind,
        
        @ToolParam(description = "命名空間（可選）。cluster-scoped 資源可留空") 
        String namespace,
        
        @ToolParam(description = "標籤選擇器（可選），例如：app=nginx") 
        String labelSelector
    ) {
        try {
            log.info("MCP 工具調用: listMyK8sResources - apiVersion: {}, kind: {}, namespace: {}, labelSelector: {}", 
                     apiVersion, kind, namespace, labelSelector);
            return k8sOperationService.listResources(apiVersion, kind, namespace, labelSelector);
        } catch (ApiException e) {
            log.error("列出資源失敗: {}", e.getResponseBody(), e);
            return createErrorResponse("列出資源失敗", e.getMessage());
        } catch (Exception e) {
            log.error("列出資源時發生異常", e);
            return createErrorResponse("系統錯誤", e.getMessage());
        }
    }

    /**
     * 獲取單個 Kubernetes 資源的詳細信息
     * 
     * @param apiVersion 資源 API 版本
     * @param kind 資源類型
     * @param namespace 命名空間（可選）
     * @param name 資源名稱
     * @return JSON 格式的響應
     */
    @Tool(description = "獲取單個 Kubernetes 資源的詳細信息。" +
                       "支援任意資源類型。")
    public String getMyK8sResource(
        @ToolParam(description = "API 版本，例如：v1, apps/v1") 
        String apiVersion,
        
        @ToolParam(description = "資源類型，例如：Service, ConfigMap") 
        String kind,
        
        @ToolParam(description = "命名空間（可選）") 
        String namespace,
        
        @ToolParam(description = "資源名稱") 
        String name
    ) {
        try {
            log.info("MCP 工具調用: getMyK8sResource - apiVersion: {}, kind: {}, namespace: {}, name: {}", 
                     apiVersion, kind, namespace, name);
            return k8sOperationService.getResource(apiVersion, kind, namespace, name);
        } catch (ApiException e) {
            log.error("獲取資源失敗: {}", e.getResponseBody(), e);
            return createErrorResponse("獲取資源失敗", e.getMessage());
        } catch (Exception e) {
            log.error("獲取資源時發生異常", e);
            return createErrorResponse("系統錯誤", e.getMessage());
        }
    }

    /**
     * 創建或更新 Kubernetes 資源
     * 
     * @param resourceYaml 資源的 YAML 或 JSON 表示
     * @return JSON 格式的響應
     */
    @Tool(description = "創建或更新 Kubernetes 資源。" +
                       "提供資源的完整 YAML 或 JSON 表示，" +
                       "應包含 apiVersion, kind, metadata 和 spec 等頂層欄位。")
    public String createOrUpdateMyK8sResource(
        @ToolParam(description = "資源的 YAML 或 JSON 表示") 
        String resourceYaml
    ) {
        try {
            log.info("MCP 工具調用: createOrUpdateMyK8sResource - 內容長度: {}", resourceYaml.length());
            return k8sOperationService.createOrUpdateResource(resourceYaml);
        } catch (ApiException e) {
            log.error("創建/更新資源失敗: {}", e.getResponseBody(), e);
            return createErrorResponse("創建/更新資源失敗", e.getMessage());
        } catch (Exception e) {
            log.error("創建/更新資源時發生異常", e);
            return createErrorResponse("系統錯誤", e.getMessage());
        }
    }

    /**
     * 刪除 Kubernetes 資源
     * 
     * @param apiVersion 資源 API 版本
     * @param kind 資源類型
     * @param namespace 命名空間（可選）
     * @param name 資源名稱
     * @return JSON 格式的響應
     */
    @Tool(description = "刪除 Kubernetes 資源。" +
                       "需要提供 apiVersion, kind, namespace（如適用）和資源名稱。")
    public String deleteMyK8sResource(
        @ToolParam(description = "API 版本") 
        String apiVersion,
        
        @ToolParam(description = "資源類型") 
        String kind,
        
        @ToolParam(description = "命名空間（可選）") 
        String namespace,
        
        @ToolParam(description = "資源名稱") 
        String name
    ) {
        Map<String, Object> response = new HashMap<>();
        
        try {
            log.info("MCP 工具調用: deleteMyK8sResource - apiVersion: {}, kind: {}, namespace: {}, name: {}", 
                     apiVersion, kind, namespace, name);
            
            k8sOperationService.deleteResource(apiVersion, kind, namespace, name);
            
            response.put("success", true);
            response.put("message", String.format("成功刪除資源: %s/%s", kind, name));
            
        } catch (ApiException e) {
            log.error("刪除資源失敗: {}", e.getResponseBody(), e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "刪除資源失敗: " + e.getMessage());
        } catch (Exception e) {
            log.error("刪除資源時發生異常", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "系統錯誤: " + e.getMessage());
        }
        
        return convertToJsonString(response);
    }

    /**
     * 列出 Kubernetes 事件
     * 
     * @param namespace 命名空間（可選）
     * @return JSON 格式的響應
     */
    @Tool(description = "列出 Kubernetes 集群事件。" +
                       "事件包含重要的集群活動信息，對於故障排查非常有用。" +
                       "如果不指定命名空間，則列出所有命名空間的事件。")
    public String listMyK8sEvents(
        @ToolParam(description = "命名空間名稱（可選）。留空則列出所有命名空間的事件") 
        String namespace
    ) {
        try {
            log.info("MCP 工具調用: listMyK8sEvents - namespace: {}", namespace);
            return k8sOperationService.listEvents(namespace);
        } catch (ApiException e) {
            log.error("列出事件失敗: {}", e.getResponseBody(), e);
            return createErrorResponse("列出事件失敗", e.getMessage());
        } catch (Exception e) {
            log.error("列出事件時發生異常", e);
            return createErrorResponse("系統錯誤", e.getMessage());
        }
    }

    /**
     * 列出集群節點
     * 
     * @param labelSelector 標籤選擇器（可選）
     * @return JSON 格式的響應
     */
    @Tool(description = "列出 Kubernetes 集群中的所有節點。" +
                       "顯示節點狀態、角色、版本等信息。")
    public String listMyK8sNodes(
        @ToolParam(description = "標籤選擇器（可選），例如：node-role.kubernetes.io/worker") 
        String labelSelector
    ) {
        try {
            log.info("MCP 工具調用: listMyK8sNodes - labelSelector: {}", labelSelector);
            return k8sOperationService.listNodes(labelSelector);
        } catch (ApiException e) {
            log.error("列出節點失敗: {}", e.getResponseBody(), e);
            return createErrorResponse("列出節點失敗", e.getMessage());
        } catch (Exception e) {
            log.error("列出節點時發生異常", e);
            return createErrorResponse("系統錯誤", e.getMessage());
        }
    }

    /**
     * 獲取節點資源使用率
     * 
     * @param nodeName 節點名稱（可選）
     * @param labelSelector 標籤選擇器（可選）
     * @return JSON 格式的響應
     */
    @Tool(description = "獲取 Kubernetes 節點的資源使用率（CPU 和 Memory）。" +
                       "需要集群安裝 Metrics Server。")
    public String topMyK8sNodes(
        @ToolParam(description = "節點名稱（可選）。留空則列出所有節點") 
        String nodeName,
        
        @ToolParam(description = "標籤選擇器（可選）") 
        String labelSelector
    ) {
        Map<String, Object> response = new HashMap<>();
        
        try {
            log.info("MCP 工具調用: topMyK8sNodes - node: {}, labelSelector: {}", nodeName, labelSelector);
            
            String result = k8sOperationService.getNodeTop(nodeName, labelSelector);
            
            response.put("success", true);
            response.put("data", result);
            response.put("message", "成功獲取節點資源使用率");
            
        } catch (ApiException e) {
            log.error("獲取節點資源使用率失敗: {}", e.getResponseBody(), e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "獲取資源使用率失敗: " + e.getMessage());
        } catch (Exception e) {
            log.error("獲取節點資源使用率時發生異常", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "系統錯誤: " + e.getMessage());
        }
        
        return convertToJsonString(response);
    }

    /**
     * 獲取節點日誌
     * 
     * @param nodeName 節點名稱
     * @param query 日誌查詢
     * @param tailLines 返回最後 N 行（可選）
     * @return JSON 格式的響應
     */
    @Tool(description = "獲取 Kubernetes 節點的系統日誌（kubelet, kube-proxy 等）。" +
                       "通過 Kubernetes API 代理訪問節點上的日誌。")
    public String logMyK8sNode(
        @ToolParam(description = "節點名稱") 
        String nodeName,
        
        @ToolParam(description = "日誌查詢，例如：kubelet 或 /var/log/kubelet.log") 
        String query,
        
        @ToolParam(description = "返回最後 N 行日誌（可選）") 
        Integer tailLines
    ) {
        Map<String, Object> response = new HashMap<>();
        
        try {
            log.info("MCP 工具調用: logMyK8sNode - node: {}, query: {}, tailLines: {}", 
                     nodeName, query, tailLines);
            
            String logs = k8sOperationService.getNodeLog(nodeName, query, tailLines);
            
            response.put("success", true);
            response.put("logs", logs);
            response.put("node", nodeName);
            response.put("message", "成功獲取節點日誌");
            
        } catch (ApiException e) {
            log.error("獲取節點日誌失敗: {}", e.getResponseBody(), e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "獲取日誌失敗: " + e.getMessage());
        } catch (Exception e) {
            log.error("獲取節點日誌時發生異常", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "系統錯誤: " + e.getMessage());
        }
        
        return convertToJsonString(response);
    }

    /**
     * 獲取節點詳細統計信息
     * 
     * @param nodeName 節點名稱
     * @return JSON 格式的響應
     */
    @Tool(description = "獲取 Kubernetes 節點的詳細統計信息。" +
                       "包括 CPU、Memory、文件系統和網絡使用情況。" +
                       "在支持 cgroup v2 的系統上，還包含 PSI（Pressure Stall Information）指標。")
    public String statsMyK8sNode(
        @ToolParam(description = "節點名稱") 
        String nodeName
    ) {
        Map<String, Object> response = new HashMap<>();
        
        try {
            log.info("MCP 工具調用: statsMyK8sNode - node: {}", nodeName);
            
            String stats = k8sOperationService.getNodeStats(nodeName);
            
            response.put("success", true);
            response.put("data", stats);
            response.put("node", nodeName);
            response.put("message", "成功獲取節點統計信息");
            
        } catch (ApiException e) {
            log.error("獲取節點統計信息失敗: {}", e.getResponseBody(), e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "獲取統計信息失敗: " + e.getMessage());
        } catch (Exception e) {
            log.error("獲取節點統計信息時發生異常", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "系統錯誤: " + e.getMessage());
        }
        
        return convertToJsonString(response);
    }

    /**
     * 列出 kubeconfig 上下文
     * 
     * @return JSON 格式的響應
     */
    @Tool(description = "列出 kubeconfig 中的所有上下文（contexts）。" +
                       "上下文定義了集群、用戶和命名空間的組合。" +
                       "可以查看當前使用的上下文以及所有可用的上下文。")
    public String listMyK8sConfigContexts() {
        Map<String, Object> response = new HashMap<>();
        
        try {
            log.info("MCP 工具調用: listMyK8sConfigContexts");
            
            String result = k8sOperationService.listConfigurationContexts();
            
            response.put("success", true);
            response.put("data", result);
            response.put("message", "成功列出配置上下文");
            
        } catch (Exception e) {
            log.error("列出配置上下文失敗", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "列出配置上下文失敗: " + e.getMessage());
        }
        
        return convertToJsonString(response);
    }

    /**
     * 查看當前 Kubernetes 配置
     * 
     * @return JSON 格式的響應
     */
    @Tool(description = "查看當前 Kubernetes 配置信息。" +
                       "顯示當前上下文、集群 API Server 地址、用戶認證方式等配置詳情。" +
                       "類似於 kubectl config view 命令。")
    public String viewMyK8sConfig() {
        Map<String, Object> response = new HashMap<>();
        
        try {
            log.info("MCP 工具調用: viewMyK8sConfig");
            
            String result = k8sOperationService.viewConfiguration();
            
            response.put("success", true);
            response.put("data", result);
            response.put("message", "成功查看配置");
            
        } catch (Exception e) {
            log.error("查看配置失敗", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "查看配置失敗: " + e.getMessage());
        }
        
        return convertToJsonString(response);
    }

    /**
     * 安裝 Helm Chart
     * 
     * @param releaseName Release 名稱
     * @param chart Chart 名稱或路徑
     * @param namespace 命名空間
     * @param values 自定義 values（YAML 格式，可選）
     * @return JSON 格式的響應
     */
    @Tool(description = "使用 Helm 安裝 Chart 到 Kubernetes 集群。" +
                       "\n\n必要參數：" +
                       "\n- releaseName: 必須提供。Release 的唯一名稱。" +
                       "\n- chart: 必須提供。Chart 名稱或路徑（例如：bitnami/nginx, ./my-chart）。" +
                       "\n\n可選參數：" +
                       "\n- namespace: 可選。默認為 'default'。如果命名空間不存在會自動創建。" +
                       "\n- values: 可選。YAML 格式的自定義配置。" +
                       "\n\n如果用戶沒有提供 namespace，將使用 'default' 作為默認值。" +
                       "\n如果用戶沒有提供 releaseName 或 chart，請提示用戶提供。" +
                       "\n\n注意：需要系統已安裝 Helm CLI 工具。")
    public String installMyK8sHelmChart(
        @ToolParam(description = "【必要】Release 名稱。如果用戶未提供，請提示用戶。") 
        String releaseName,
        
        @ToolParam(description = "【必要】Chart 名稱或路徑。例如：bitnami/nginx、stable/mysql、./my-chart。如果用戶未提供，請提示用戶。") 
        String chart,
        
        @ToolParam(description = "【可選】命名空間。默認值為 'default'。如果命名空間不存在會自動創建。") 
        String namespace,
        
        @ToolParam(description = "【可選】自定義 values，YAML 格式。例如：replicaCount: 3\nimage:\n  tag: latest") 
        String values
    ) {
        Map<String, Object> response = new HashMap<>();
        
        try {
            log.info("MCP 工具調用: installMyK8sHelmChart - release: {}, chart: {}, namespace: {}", 
                     releaseName, chart, namespace);
            
            String result = k8sOperationService.helmInstall(releaseName, chart, namespace, values);
            
            response.put("success", true);
            response.put("data", result);
            response.put("message", "Helm Chart 安裝成功");
            
        } catch (Exception e) {
            log.error("安裝 Helm Chart 失敗", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "安裝失敗: " + e.getMessage());
        }
        
        return convertToJsonString(response);
    }

    /**
     * 列出 Helm Releases
     * 
     * @param namespace 命名空間（可選）
     * @return JSON 格式的響應
     */
    @Tool(description = "列出 Kubernetes 集群中的 Helm releases。" +
                       "\n\n參數說明：" +
                       "\n- namespace: 可選參數。" +
                       "\n  * 如果提供命名空間，則只列出該命名空間的 releases。" +
                       "\n  * 如果留空或未提供，則列出所有命名空間的 releases。" +
                       "\n\n默認行為：列出所有命名空間的 releases。")
    public String listMyK8sHelmReleases(
        @ToolParam(description = "【可選】命名空間。留空則列出所有命名空間的 releases。") 
        String namespace
    ) {
        Map<String, Object> response = new HashMap<>();
        
        try {
            log.info("MCP 工具調用: listMyK8sHelmReleases - namespace: {}", namespace);
            
            String result = k8sOperationService.helmList(namespace);
            
            response.put("success", true);
            response.put("data", result);
            response.put("message", "成功列出 Helm Releases");
            
        } catch (Exception e) {
            log.error("列出 Helm Releases 失敗", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "列出失敗: " + e.getMessage());
        }
        
        return convertToJsonString(response);
    }

    /**
     * 卸載 Helm Release
     * 
     * @param releaseName Release 名稱
     * @param namespace 命名空間
     * @return JSON 格式的響應
     */
    @Tool(description = "從 Kubernetes 集群中卸載指定的 Helm release。" +
                       "\n將刪除該 release 創建的所有 Kubernetes 資源。" +
                       "\n\n必要參數：" +
                       "\n- releaseName: 必須提供。要卸載的 release 名稱。" +
                       "\n- namespace: 必須提供。release 所在的命名空間。" +
                       "\n\n如果用戶沒有提供 releaseName 或 namespace，請提示用戶。")
    public String uninstallMyK8sHelmRelease(
        @ToolParam(description = "【必要】Release 名稱。如果用戶未提供，請提示用戶。") 
        String releaseName,
        
        @ToolParam(description = "【必要】命名空間。如果用戶未提供，請提示用戶。") 
        String namespace
    ) {
        Map<String, Object> response = new HashMap<>();
        
        try {
            log.info("MCP 工具調用: uninstallMyK8sHelmRelease - release: {}, namespace: {}", 
                     releaseName, namespace);
            
            String result = k8sOperationService.helmUninstall(releaseName, namespace);
            
            response.put("success", true);
            response.put("data", result);
            response.put("message", "Helm Release 卸載成功");
            
        } catch (Exception e) {
            log.error("卸載 Helm Release 失敗", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "卸載失敗: " + e.getMessage());
        }
        
        return convertToJsonString(response);
    }

    /**
     * Patch Kubernetes 資源
     * 
     * 支援三種 Patch 格式:
     * - application/json-patch+json (JSON Patch, RFC 6902)
     * - application/strategic-merge-patch+json (Strategic Merge Patch)
     * - application/apply-patch+yaml (Server-Side Apply, Kubernetes 1.16+)
     * 
     * @param apiVersion API 版本,例如: "v1", "apps/v1", "batch/v1"
     * @param kind 資源類型,例如: "Pod", "Deployment", "Service"
     * @param namespace 命名空間,cluster-scoped 資源可留空
     * @param name 資源名稱
     * @param patchContent Patch 內容,JSON 或 YAML 格式字符串
     * @param patchFormat Patch 格式
     * @return Patch 後的資源 JSON 字符串
     */
    @Tool(description = """
            Patch (修補) Kubernetes 資源。支援三種 Patch 格式:
            
            1. JSON Patch (application/json-patch+json):
               使用 RFC 6902 標準的 JSON Patch 操作,例如:
               [{"op": "replace", "path": "/spec/replicas", "value": 3}]
               
            2. Strategic Merge Patch (application/strategic-merge-patch+json):
               Kubernetes 特有的合併策略,例如:
               {"metadata": {"labels": {"app": "updated"}}}
               
            3. Server-Side Apply (application/apply-patch+yaml):
               Kubernetes 1.16+ 的聲明式配置,例如:
               apiVersion: apps/v1
               kind: Deployment
               metadata:
                 name: my-app
               spec:
                 replicas: 3
            
            使用場景:
            - 修改 Deployment 的副本數
            - 更新 Pod 的標籤或註解
            - 修改 Service 的端口配置
            - 更新 ConfigMap 的數據
            """)
    public String patchMyK8sResource(
            @ToolParam(description = "API 版本,例如: v1, apps/v1, batch/v1") 
            String apiVersion,
            
            @ToolParam(description = "資源類型,例如: Pod, Deployment, Service") 
            String kind,
            
            @ToolParam(description = "命名空間,cluster-scoped 資源可留空") 
            String namespace,
            
            @ToolParam(description = "資源名稱") 
            String name,
            
            @ToolParam(description = "Patch 內容,JSON 或 YAML 格式字符串") 
            String patchContent,
            
            @ToolParam(description = "Patch 格式: application/json-patch+json | application/strategic-merge-patch+json | application/apply-patch+yaml") 
            String patchFormat
    ) {
        Map<String, Object> response = new HashMap<>();
        
        try {
            log.info("Patching resource: {}/{} in namespace {}", kind, name, namespace);
            
            // 調用服務層
            String result = k8sOperationService.patchResource(
                apiVersion, 
                kind, 
                namespace, 
                name, 
                patchContent, 
                patchFormat
            );
            
            response.put("success", true);
            response.put("resource", objectMapper.readValue(result, Object.class));
            response.put("message", String.format("資源 %s/%s Patch 成功", kind, name));
            
        } catch (ApiException e) {
            log.error("Patch resource failed: {}", e.getResponseBody(), e);
            response.put("success", false);
            response.put("error", e.getResponseBody());
            response.put("message", "Patch 資源失敗: " + e.getMessage());
        } catch (Exception e) {
            log.error("Patch resource error", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "Patch 資源錯誤: " + e.getMessage());
        }
        
        return convertToJsonString(response);
    }

    /**
     * 列出指定命名空間中的 Service
     * 
     * @param namespace 命名空間名稱
     * @param labelSelector 標籤選擇器
     * @return Service 列表 JSON 字符串
     */
    @Tool(description = "列出指定命名空間中的 Service。" +
                       "Service 是 Kubernetes 中用於暴露應用程序的抽象層,定義了一組 Pod 的訪問策略。" +
                       "可以通過標籤選擇器過濾 Service。")
    public String listMyK8sServices(
            @ToolParam(description = "命名空間名稱") 
            String namespace,
            
            @ToolParam(description = "標籤選擇器,例如 'app=nginx'。留空返回所有 Service") 
            String labelSelector
    ) {
        try {
            log.info("Listing services in namespace: {}", namespace);
            return k8sOperationService.listServices(namespace, labelSelector);
        } catch (ApiException e) {
            log.error("List services failed: {}", e.getResponseBody(), e);
            return createErrorResponse("列出 Service 失敗", e.getMessage());
        } catch (Exception e) {
            log.error("List services error", e);
            return createErrorResponse("系統錯誤", e.getMessage());
        }
    }

    /**
     * 列出所有命名空間中的 Service
     * 
     * @param labelSelector 標籤選擇器
     * @return Service 列表 JSON 字符串
     */
    @Tool(description = "列出所有命名空間中的 Service。" +
                       "這會返回整個集群中的 Service,適合全局查詢。")
    public String listAllMyK8sServices(
            @ToolParam(description = "標籤選擇器,例如 'app=nginx'。留空返回所有 Service") 
            String labelSelector
    ) {
        try {
            log.info("Listing all services");
            return k8sOperationService.listAllServices(labelSelector);
        } catch (ApiException e) {
            log.error("List all services failed: {}", e.getResponseBody(), e);
            return createErrorResponse("列出所有 Service 失敗", e.getMessage());
        } catch (Exception e) {
            log.error("List all services error", e);
            return createErrorResponse("系統錯誤", e.getMessage());
        }
    }

    /**
     * 獲取指定 Service 的詳細信息
     * 
     * @param namespace 命名空間名稱
     * @param name Service 名稱
     * @return Service 詳細信息 JSON 字符串
     */
    @Tool(description = "獲取指定 Service 的詳細信息。" +
                       "返回 Service 的完整配置,包括 selector、ports、type 等信息。")
    public String getMyK8sService(
            @ToolParam(description = "命名空間名稱") 
            String namespace,
            
            @ToolParam(description = "Service 名稱") 
            String name
    ) {
        try {
            log.info("Getting service: {}/{}", namespace, name);
            return k8sOperationService.getService(namespace, name);
        } catch (ApiException e) {
            log.error("Get service failed: {}", e.getResponseBody(), e);
            return createErrorResponse("獲取 Service 失敗", e.getMessage());
        } catch (Exception e) {
            log.error("Get service error", e);
            return createErrorResponse("系統錯誤", e.getMessage());
        }
    }

    /**
     * 刪除指定的 Service
     * 
     * @param namespace 命名空間名稱
     * @param name Service 名稱
     * @return 刪除結果 JSON 字符串
     */
    @Tool(description = "刪除指定的 Service。" +
                       "刪除後,該 Service 將不再可訪問,但不會影響後端的 Pod。")
    public String deleteMyK8sService(
            @ToolParam(description = "命名空間名稱") 
            String namespace,
            
            @ToolParam(description = "Service 名稱") 
            String name
    ) {
        Map<String, Object> response = new HashMap<>();
        
        try {
            log.info("Deleting service: {}/{}", namespace, name);
            
            String result = k8sOperationService.deleteService(namespace, name);
            
            response.put("success", true);
            response.put("result", objectMapper.readValue(result, Object.class));
            response.put("message", String.format("Service %s/%s 刪除成功", namespace, name));
            
        } catch (ApiException e) {
            log.error("Delete service failed: {}", e.getResponseBody(), e);
            response.put("success", false);
            response.put("error", e.getResponseBody());
            response.put("message", "刪除 Service 失敗: " + e.getMessage());
        } catch (Exception e) {
            log.error("Delete service error", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "系統錯誤: " + e.getMessage());
        }
        
        return convertToJsonString(response);
    }

    // ======================================
    // File Copy 工具
    // ======================================

    /**
     * 從 Kubernetes Pod 複製檔案到本地
     * 
     * 此工具使用 kubectl cp 等效功能，從指定 Pod 的容器中複製檔案到本地檔案系統。
     * 
     * 使用場景：
     * 1. 從運行中的應用程式容器下載日誌檔案
     * 2. 從資料庫容器匯出備份檔案
     * 3. 從配置容器下載配置檔案
     * 4. 除錯時獲取容器內部檔案
     * 
     * 注意事項：
     * - Pod 必須處於 Running 狀態
     * - 容器內必須有 tar 命令（大多數容器映像都有）
     * - 來源路徑必須是容器內的絕對路徑
     * - 目標路徑將自動創建父目錄
     * - 如果 Pod 只有一個容器，containerName 可以留空
     * 
     * 範例：
     * - 從 nginx Pod 下載日誌：
     *   namespace: default
     *   podName: nginx-6d4cf56db6-abcde
     *   containerName: nginx
     *   sourcePath: /var/log/nginx/access.log
     *   destPath: /tmp/access.log
     * 
     * @param namespace Pod 所在的命名空間
     * @param podName Pod 名稱
     * @param containerName 容器名稱（可選，如果 Pod 只有一個容器可以留空）
     * @param sourcePath Pod 中的來源檔案路徑（絕對路徑，例如：/app/config.yaml）
     * @param destPath 本地目標檔案路徑（絕對路徑，例如：/tmp/config.yaml）
     * @return JSON 格式的複製結果，包含 success 狀態、檔案大小等信息
     */
    @Tool(description = "從 Kubernetes Pod 複製檔案到本地檔案系統。支援從運行中的容器下載日誌、配置或備份檔案")
    public String copyFileFromMyK8sPod(
            @ToolParam(description = "【必要】Pod 所在的命名空間") String namespace,
            @ToolParam(description = "【必要】Pod 名稱") String podName,
            @ToolParam(description = "【可選】容器名稱。如果 Pod 只有一個容器可以留空") String containerName,
            @ToolParam(description = "【必要】Pod 中的來源檔案路徑（絕對路徑），例如：/var/log/app.log") String sourcePath,
            @ToolParam(description = "【必要】本地目標檔案路徑（絕對路徑），例如：/tmp/app.log") String destPath) {
        
        log.info("MCP Tool: copyFileFromMyK8sPod - namespace={}, podName={}, container={}, source={}, dest={}", 
                namespace, podName, containerName, sourcePath, destPath);
        
        Map<String, Object> response = new HashMap<>();
        
        try {
            String result = k8sOperationService.copyFileFromPod(
                namespace, podName, containerName, sourcePath, destPath);
            
            response.put("success", true);
            response.put("result", objectMapper.readValue(result, Object.class));
            response.put("message", String.format("檔案從 Pod %s/%s 複製成功", namespace, podName));
            
        } catch (ApiException e) {
            log.error("Copy file from pod failed: {}", e.getResponseBody(), e);
            response.put("success", false);
            response.put("error", e.getResponseBody());
            response.put("message", "從 Pod 複製檔案失敗: " + e.getMessage());
        } catch (Exception e) {
            log.error("Copy file from pod error", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "系統錯誤: " + e.getMessage());
        }
        
        return convertToJsonString(response);
    }

    /**
     * 複製本地檔案到 Kubernetes Pod
     * 
     * 此工具使用 kubectl cp 等效功能，將本地檔案複製到指定 Pod 的容器中。
     * 
     * 使用場景：
     * 1. 上傳配置檔案到運行中的應用程式容器
     * 2. 上傳腳本到容器中執行
     * 3. 上傳資料檔案到資料庫容器
     * 4. 熱更新配置而不需要重啟 Pod
     * 
     * 注意事項：
     * - Pod 必須處於 Running 狀態
     * - 容器內必須有 tar 命令（大多數容器映像都有）
     * - 來源檔案必須存在且可讀
     * - 目標路徑必須是容器內的絕對路徑
     * - 如果 Pod 只有一個容器，containerName 可以留空
     * - 上傳大檔案可能需要較長時間
     * 
     * 範例：
     * - 上傳配置到應用容器：
     *   namespace: default
     *   podName: app-6d4cf56db6-abcde
     *   containerName: app
     *   sourcePath: /tmp/new-config.yaml
     *   destPath: /app/config/config.yaml
     * 
     * @param namespace Pod 所在的命名空間
     * @param podName Pod 名稱
     * @param containerName 容器名稱（可選，如果 Pod 只有一個容器可以留空）
     * @param sourcePath 本地來源檔案路徑（絕對路徑，例如：/tmp/config.yaml）
     * @param destPath Pod 中的目標檔案路徑（絕對路徑，例如：/app/config.yaml）
     * @return JSON 格式的複製結果，包含 success 狀態、檔案大小等信息
     */
    @Tool(description = "複製本地檔案到 Kubernetes Pod 的容器中。支援上傳配置、腳本或資料檔案到運行中的容器")
    public String copyFileToMyK8sPod(
            @ToolParam(description = "【必要】Pod 所在的命名空間") String namespace,
            @ToolParam(description = "【必要】Pod 名稱") String podName,
            @ToolParam(description = "【可選】容器名稱。如果 Pod 只有一個容器可以留空") String containerName,
            @ToolParam(description = "【必要】本地來源檔案路徑（絕對路徑），例如：/tmp/config.yaml") String sourcePath,
            @ToolParam(description = "【必要】Pod 中的目標檔案路徑（絕對路徑），例如：/app/config.yaml") String destPath) {
        
        log.info("MCP Tool: copyFileToMyK8sPod - namespace={}, podName={}, container={}, source={}, dest={}", 
                namespace, podName, containerName, sourcePath, destPath);
        
        Map<String, Object> response = new HashMap<>();
        
        try {
            String result = k8sOperationService.copyFileToPod(
                namespace, podName, containerName, sourcePath, destPath);
            
            response.put("success", true);
            response.put("result", objectMapper.readValue(result, Object.class));
            response.put("message", String.format("檔案複製到 Pod %s/%s 成功", namespace, podName));
            
        } catch (ApiException e) {
            log.error("Copy file to pod failed: {}", e.getResponseBody(), e);
            response.put("success", false);
            response.put("error", e.getResponseBody());
            response.put("message", "複製檔案到 Pod 失敗: " + e.getMessage());
        } catch (Exception e) {
            log.error("Copy file to pod error", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "系統錯誤: " + e.getMessage());
        }
        
        return convertToJsonString(response);
    }

    /**
     * 創建錯誤響應 JSON 字符串
     * 
     * @param message 錯誤消息
     * @param error 錯誤詳情
     * @return JSON 錯誤響應字符串
     */
    private String createErrorResponse(String message, String error) {
        try {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", message);
            response.put("error", error);
            return objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(response);
        } catch (Exception e) {
            log.error("創建錯誤響應失敗", e);
            return "{\"success\": false, \"message\": \"" + message + "\", \"error\": \"" + error + "\"}";
        }
    }

    /**
     * 將響應對象轉換為 JSON 字符串
     * 
     * @param response 響應對象
     * @return JSON 字符串
     */
    private String convertToJsonString(Map<String, Object> response) {
        try {
            return objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(response);
        } catch (Exception e) {
            log.error("JSON 序列化失敗", e);
            return "{\"success\": false, \"message\": \"JSON 序列化失敗: " + e.getMessage() + "\"}";
        }
    }

    // ======================================
    // ConfigMap 工具
    // ======================================

    /**
     * 列出 Kubernetes ConfigMap
     * 
     * ConfigMap 是 Kubernetes 用來存儲配置數據的資源，以 key-value 形式存儲。
     * 
     * 使用場景：
     * 1. 查看應用程式的配置數據
     * 2. 透過標籤選擇器過濾特定應用的 ConfigMap
     * 3. 檢查配置更新和版本
     * 
     * @param namespace ConfigMap 所在的命名空間
     * @param labelSelector 標籤選擇器（可選），例如：app=nginx,env=prod
     * @return JSON 格式的 ConfigMap 列表
     */
    @Tool(description = "列出 Kubernetes 命名空間中的所有 ConfigMap，可使用標籤選擇器過濾")
    public String listMyK8sConfigMaps(
            @ToolParam(description = "【必要】命名空間名稱") String namespace,
            @ToolParam(description = "【可選】標籤選擇器，例如：app=nginx") String labelSelector) {
        
        log.info("MCP Tool: listMyK8sConfigMaps - namespace={}, labelSelector={}", namespace, labelSelector);
        
        Map<String, Object> response = new HashMap<>();
        
        try {
            String result = k8sOperationService.listConfigMaps(namespace, labelSelector);
            
            response.put("success", true);
            response.put("result", objectMapper.readValue(result, Object.class));
            response.put("message", String.format("成功列出命名空間 %s 中的 ConfigMap", namespace));
            
        } catch (ApiException e) {
            log.error("List ConfigMaps failed: {}", e.getResponseBody(), e);
            response.put("success", false);
            response.put("error", e.getResponseBody());
            response.put("message", "列出 ConfigMap 失敗: " + e.getMessage());
        } catch (Exception e) {
            log.error("List ConfigMaps error", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "系統錯誤: " + e.getMessage());
        }
        
        return convertToJsonString(response);
    }

    /**
     * 獲取 Kubernetes ConfigMap 詳細信息
     * 
     * @param namespace ConfigMap 所在的命名空間
     * @param name ConfigMap 名稱
     * @return JSON 格式的 ConfigMap 詳細信息
     */
    @Tool(description = "獲取指定 Kubernetes ConfigMap 的詳細信息，包含所有 key-value 配置數據")
    public String getMyK8sConfigMap(
            @ToolParam(description = "【必要】命名空間名稱") String namespace,
            @ToolParam(description = "【必要】ConfigMap 名稱") String name) {
        
        log.info("MCP Tool: getMyK8sConfigMap - namespace={}, name={}", namespace, name);
        
        Map<String, Object> response = new HashMap<>();
        
        try {
            String result = k8sOperationService.getConfigMap(namespace, name);
            
            response.put("success", true);
            response.put("result", objectMapper.readValue(result, Object.class));
            response.put("message", String.format("成功獲取 ConfigMap %s/%s", namespace, name));
            
        } catch (ApiException e) {
            log.error("Get ConfigMap failed: {}", e.getResponseBody(), e);
            response.put("success", false);
            response.put("error", e.getResponseBody());
            response.put("message", "獲取 ConfigMap 失敗: " + e.getMessage());
        } catch (Exception e) {
            log.error("Get ConfigMap error", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "系統錯誤: " + e.getMessage());
        }
        
        return convertToJsonString(response);
    }

    /**
     * 創建 Kubernetes ConfigMap
     * 
     * 此工具創建新的 ConfigMap 用於存儲配置數據。
     * 
     * 注意事項：
     * - ConfigMap 名稱必須符合 DNS 命名規範
     * - data 和 labels 參數必須是有效的 JSON 格式
     * - data 格式：{"key1":"value1","key2":"value2"}
     * - labels 格式：{"app":"nginx","env":"prod"}
     * 
     * @param namespace ConfigMap 所在的命名空間
     * @param name ConfigMap 名稱
     * @param dataJson 配置數據的 JSON 字符串
     * @param labelsJson 標籤的 JSON 字符串（可選）
     * @return JSON 格式的創建結果
     */
    @Tool(description = "創建新的 Kubernetes ConfigMap 用於存儲配置數據")
    public String createMyK8sConfigMap(
            @ToolParam(description = "【必要】命名空間名稱") String namespace,
            @ToolParam(description = "【必要】ConfigMap 名稱") String name,
            @ToolParam(description = "【必要】配置數據的 JSON 字符串，格式：{\"key1\":\"value1\"}") String dataJson,
            @ToolParam(description = "【可選】標籤的 JSON 字符串，格式：{\"app\":\"nginx\"}") String labelsJson) {
        
        log.info("MCP Tool: createMyK8sConfigMap - namespace={}, name={}", namespace, name);
        
        Map<String, Object> response = new HashMap<>();
        
        try {
            // 解析 JSON 字符串
            @SuppressWarnings("unchecked")
            Map<String, String> data = objectMapper.readValue(dataJson, Map.class);
            
            Map<String, String> labels = null;
            if (labelsJson != null && !labelsJson.trim().isEmpty()) {
                @SuppressWarnings("unchecked")
                Map<String, String> parsedLabels = objectMapper.readValue(labelsJson, Map.class);
                labels = parsedLabels;
            }
            
            String result = k8sOperationService.createConfigMap(namespace, name, data, labels);
            
            response.put("success", true);
            response.put("result", objectMapper.readValue(result, Object.class));
            response.put("message", String.format("ConfigMap %s/%s 創建成功", namespace, name));
            
        } catch (ApiException e) {
            log.error("Create ConfigMap failed: {}", e.getResponseBody(), e);
            response.put("success", false);
            response.put("error", e.getResponseBody());
            response.put("message", "創建 ConfigMap 失敗: " + e.getMessage());
        } catch (Exception e) {
            log.error("Create ConfigMap error", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "系統錯誤: " + e.getMessage());
        }
        
        return convertToJsonString(response);
    }

    /**
     * 刪除 Kubernetes ConfigMap
     * 
     * @param namespace ConfigMap 所在的命名空間
     * @param name ConfigMap 名稱
     * @return JSON 格式的刪除結果
     */
    @Tool(description = "刪除指定的 Kubernetes ConfigMap")
    public String deleteMyK8sConfigMap(
            @ToolParam(description = "【必要】命名空間名稱") String namespace,
            @ToolParam(description = "【必要】ConfigMap 名稱") String name) {
        
        log.info("MCP Tool: deleteMyK8sConfigMap - namespace={}, name={}", namespace, name);
        
        Map<String, Object> response = new HashMap<>();
        
        try {
            String result = k8sOperationService.deleteConfigMap(namespace, name);
            
            response.put("success", true);
            response.put("result", objectMapper.readValue(result, Object.class));
            response.put("message", String.format("ConfigMap %s/%s 刪除成功", namespace, name));
            
        } catch (ApiException e) {
            log.error("Delete ConfigMap failed: {}", e.getResponseBody(), e);
            response.put("success", false);
            response.put("error", e.getResponseBody());
            response.put("message", "刪除 ConfigMap 失敗: " + e.getMessage());
        } catch (Exception e) {
            log.error("Delete ConfigMap error", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "系統錯誤: " + e.getMessage());
        }
        
        return convertToJsonString(response);
    }

    // ======================================
    // Secret 工具
    // ======================================

    /**
     * 列出 Kubernetes Secret
     * 
     * Secret 是 Kubernetes 用來存儲敏感數據的資源，例如密碼、token、金鑰等。
     * 數據以 base64 編碼格式存儲。
     * 
     * @param namespace Secret 所在的命名空間
     * @param labelSelector 標籤選擇器（可選）
     * @return JSON 格式的 Secret 列表
     */
    @Tool(description = "列出 Kubernetes 命名空間中的所有 Secret，可使用標籤選擇器過濾")
    public String listMyK8sSecrets(
            @ToolParam(description = "【必要】命名空間名稱") String namespace,
            @ToolParam(description = "【可選】標籤選擇器，例如：app=nginx") String labelSelector) {
        
        log.info("MCP Tool: listMyK8sSecrets - namespace={}, labelSelector={}", namespace, labelSelector);
        
        Map<String, Object> response = new HashMap<>();
        
        try {
            String result = k8sOperationService.listSecrets(namespace, labelSelector);
            
            response.put("success", true);
            response.put("result", objectMapper.readValue(result, Object.class));
            response.put("message", String.format("成功列出命名空間 %s 中的 Secret", namespace));
            
        } catch (ApiException e) {
            log.error("List Secrets failed: {}", e.getResponseBody(), e);
            response.put("success", false);
            response.put("error", e.getResponseBody());
            response.put("message", "列出 Secret 失敗: " + e.getMessage());
        } catch (Exception e) {
            log.error("List Secrets error", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "系統錯誤: " + e.getMessage());
        }
        
        return convertToJsonString(response);
    }

    /**
     * 獲取 Kubernetes Secret 詳細信息
     * 
     * @param namespace Secret 所在的命名空間
     * @param name Secret 名稱
     * @return JSON 格式的 Secret 詳細信息（數據已 base64 編碼）
     */
    @Tool(description = "獲取指定 Kubernetes Secret 的詳細信息，包含 base64 編碼的敏感數據")
    public String getMyK8sSecret(
            @ToolParam(description = "【必要】命名空間名稱") String namespace,
            @ToolParam(description = "【必要】Secret 名稱") String name) {
        
        log.info("MCP Tool: getMyK8sSecret - namespace={}, name={}", namespace, name);
        
        Map<String, Object> response = new HashMap<>();
        
        try {
            String result = k8sOperationService.getSecret(namespace, name);
            
            response.put("success", true);
            response.put("result", objectMapper.readValue(result, Object.class));
            response.put("message", String.format("成功獲取 Secret %s/%s", namespace, name));
            
        } catch (ApiException e) {
            log.error("Get Secret failed: {}", e.getResponseBody(), e);
            response.put("success", false);
            response.put("error", e.getResponseBody());
            response.put("message", "獲取 Secret 失敗: " + e.getMessage());
        } catch (Exception e) {
            log.error("Get Secret error", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "系統錯誤: " + e.getMessage());
        }
        
        return convertToJsonString(response);
    }

    /**
     * 創建 Kubernetes Secret
     * 
     * 此工具創建新的 Secret 用於存儲敏感數據。
     * 數據會自動進行 base64 編碼，您只需提供原始字符串即可。
     * 
     * 注意事項：
     * - Secret 名稱必須符合 DNS 命名規範
     * - data、type 和 labels 參數必須是有效的 JSON 格式
     * - data 格式：{"username":"admin","password":"secret123"}
     * - type 常見值：Opaque（默認）, kubernetes.io/tls, kubernetes.io/dockerconfigjson
     * - labels 格式：{"app":"nginx","env":"prod"}
     * 
     * @param namespace Secret 所在的命名空間
     * @param name Secret 名稱
     * @param dataJson 原始數據的 JSON 字符串（會自動 base64 編碼）
     * @param type Secret 類型（可選，默認為 Opaque）
     * @param labelsJson 標籤的 JSON 字符串（可選）
     * @return JSON 格式的創建結果
     */
    @Tool(description = "創建新的 Kubernetes Secret 用於存儲敏感數據（如密碼、token）。數據會自動 base64 編碼")
    public String createMyK8sSecret(
            @ToolParam(description = "【必要】命名空間名稱") String namespace,
            @ToolParam(description = "【必要】Secret 名稱") String name,
            @ToolParam(description = "【必要】原始數據的 JSON 字符串，格式：{\"username\":\"admin\",\"password\":\"secret\"}") String dataJson,
            @ToolParam(description = "【可選】Secret 類型，默認為 Opaque。其他類型：kubernetes.io/tls, kubernetes.io/dockerconfigjson") String type,
            @ToolParam(description = "【可選】標籤的 JSON 字符串，格式：{\"app\":\"nginx\"}") String labelsJson) {
        
        log.info("MCP Tool: createMyK8sSecret - namespace={}, name={}", namespace, name);
        
        Map<String, Object> response = new HashMap<>();
        
        try {
            // 解析 JSON 字符串
            @SuppressWarnings("unchecked")
            Map<String, String> data = objectMapper.readValue(dataJson, Map.class);
            
            Map<String, String> labels = null;
            if (labelsJson != null && !labelsJson.trim().isEmpty()) {
                @SuppressWarnings("unchecked")
                Map<String, String> parsedLabels = objectMapper.readValue(labelsJson, Map.class);
                labels = parsedLabels;
            }
            
            String result = k8sOperationService.createSecret(namespace, name, data, type, labels);
            
            response.put("success", true);
            response.put("result", objectMapper.readValue(result, Object.class));
            response.put("message", String.format("Secret %s/%s 創建成功", namespace, name));
            
        } catch (ApiException e) {
            log.error("Create Secret failed: {}", e.getResponseBody(), e);
            response.put("success", false);
            response.put("error", e.getResponseBody());
            response.put("message", "創建 Secret 失敗: " + e.getMessage());
        } catch (Exception e) {
            log.error("Create Secret error", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "系統錯誤: " + e.getMessage());
        }
        
        return convertToJsonString(response);
    }

    /**
     * 刪除 Kubernetes Secret
     * 
     * @param namespace Secret 所在的命名空間
     * @param name Secret 名稱
     * @return JSON 格式的刪除結果
     */
    @Tool(description = "刪除指定的 Kubernetes Secret")
    public String deleteMyK8sSecret(
            @ToolParam(description = "【必要】命名空間名稱") String namespace,
            @ToolParam(description = "【必要】Secret 名稱") String name) {
        
        log.info("MCP Tool: deleteMyK8sSecret - namespace={}, name={}", namespace, name);
        
        Map<String, Object> response = new HashMap<>();
        
        try {
            String result = k8sOperationService.deleteSecret(namespace, name);
            
            response.put("success", true);
            response.put("result", objectMapper.readValue(result, Object.class));
            response.put("message", String.format("Secret %s/%s 刪除成功", namespace, name));
            
        } catch (ApiException e) {
            log.error("Delete Secret failed: {}", e.getResponseBody(), e);
            response.put("success", false);
            response.put("error", e.getResponseBody());
            response.put("message", "刪除 Secret 失敗: " + e.getMessage());
        } catch (Exception e) {
            log.error("Delete Secret error", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "系統錯誤: " + e.getMessage());
        }
        
        return convertToJsonString(response);
    }

    // ======================================
    // Job 工具
    // ======================================

    @Tool(description = "列出 Kubernetes 命名空間中的所有 Job，可使用標籤選擇器過濾")
    public String listMyK8sJobs(
            @ToolParam(description = "【必要】命名空間名稱") String namespace,
            @ToolParam(description = "【可選】標籤選擇器") String labelSelector) {
        
        log.info("MCP Tool: listMyK8sJobs - namespace={}, labelSelector={}", namespace, labelSelector);
        
        Map<String, Object> response = new HashMap<>();
        
        try {
            String result = k8sOperationService.listJobs(namespace, labelSelector);
            
            response.put("success", true);
            response.put("result", objectMapper.readValue(result, Object.class));
            response.put("message", String.format("成功列出命名空間 %s 中的 Job", namespace));
            
        } catch (ApiException e) {
            log.error("List Jobs failed: {}", e.getResponseBody(), e);
            response.put("success", false);
            response.put("error", e.getResponseBody());
            response.put("message", "列出 Job 失敗: " + e.getMessage());
        } catch (Exception e) {
            log.error("List Jobs error", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "系統錯誤: " + e.getMessage());
        }
        
        return convertToJsonString(response);
    }

    @Tool(description = "獲取指定 Kubernetes Job 的詳細信息")
    public String getMyK8sJob(
            @ToolParam(description = "【必要】命名空間名稱") String namespace,
            @ToolParam(description = "【必要】Job 名稱") String name) {
        
        log.info("MCP Tool: getMyK8sJob - namespace={}, name={}", namespace, name);
        
        Map<String, Object> response = new HashMap<>();
        
        try {
            String result = k8sOperationService.getJob(namespace, name);
            
            response.put("success", true);
            response.put("result", objectMapper.readValue(result, Object.class));
            response.put("message", String.format("成功獲取 Job %s/%s", namespace, name));
            
        } catch (ApiException e) {
            log.error("Get Job failed: {}", e.getResponseBody(), e);
            response.put("success", false);
            response.put("error", e.getResponseBody());
            response.put("message", "獲取 Job 失敗: " + e.getMessage());
        } catch (Exception e) {
            log.error("Get Job error", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "系統錯誤: " + e.getMessage());
        }
        
        return convertToJsonString(response);
    }

    @Tool(description = "刪除指定的 Kubernetes Job")
    public String deleteMyK8sJob(
            @ToolParam(description = "【必要】命名空間名稱") String namespace,
            @ToolParam(description = "【必要】Job 名稱") String name) {
        
        log.info("MCP Tool: deleteMyK8sJob - namespace={}, name={}", namespace, name);
        
        Map<String, Object> response = new HashMap<>();
        
        try {
            String result = k8sOperationService.deleteJob(namespace, name);
            
            response.put("success", true);
            response.put("result", objectMapper.readValue(result, Object.class));
            response.put("message", String.format("Job %s/%s 刪除成功", namespace, name));
            
        } catch (ApiException e) {
            log.error("Delete Job failed: {}", e.getResponseBody(), e);
            response.put("success", false);
            response.put("error", e.getResponseBody());
            response.put("message", "刪除 Job 失敗: " + e.getMessage());
        } catch (Exception e) {
            log.error("Delete Job error", e);
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "系統錯誤: " + e.getMessage());
        }
        
        return convertToJsonString(response);
    }

    // ======================================
    // CronJob 工具
    // ======================================

    @Tool(description = "列出 Kubernetes 命名空間中的所有 CronJob")
    public String listMyK8sCronJobs(
            @ToolParam(description = "【必要】命名空間名稱") String namespace,
            @ToolParam(description = "【可選】標籤選擇器") String labelSelector) {
        
        Map<String, Object> response = new HashMap<>();
        
        try {
            String result = k8sOperationService.listCronJobs(namespace, labelSelector);
            
            response.put("success", true);
            response.put("result", objectMapper.readValue(result, Object.class));
            response.put("message", String.format("成功列出命名空間 %s 中的 CronJob", namespace));
            
        } catch (ApiException e) {
            response.put("success", false);
            response.put("error", e.getResponseBody());
            response.put("message", "列出 CronJob 失敗: " + e.getMessage());
        } catch (Exception e) {
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "系統錯誤: " + e.getMessage());
        }
        
        return convertToJsonString(response);
    }

    @Tool(description = "獲取指定 Kubernetes CronJob 的詳細信息")
    public String getMyK8sCronJob(
            @ToolParam(description = "【必要】命名空間名稱") String namespace,
            @ToolParam(description = "【必要】CronJob 名稱") String name) {
        
        Map<String, Object> response = new HashMap<>();
        
        try {
            String result = k8sOperationService.getCronJob(namespace, name);
            
            response.put("success", true);
            response.put("result", objectMapper.readValue(result, Object.class));
            response.put("message", String.format("成功獲取 CronJob %s/%s", namespace, name));
            
        } catch (ApiException e) {
            response.put("success", false);
            response.put("error", e.getResponseBody());
            response.put("message", "獲取 CronJob 失敗: " + e.getMessage());
        } catch (Exception e) {
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "系統錯誤: " + e.getMessage());
        }
        
        return convertToJsonString(response);
    }

    @Tool(description = "刪除指定的 Kubernetes CronJob")
    public String deleteMyK8sCronJob(
            @ToolParam(description = "【必要】命名空間名稱") String namespace,
            @ToolParam(description = "【必要】CronJob 名稱") String name) {
        
        Map<String, Object> response = new HashMap<>();
        
        try {
            String result = k8sOperationService.deleteCronJob(namespace, name);
            
            response.put("success", true);
            response.put("result", objectMapper.readValue(result, Object.class));
            response.put("message", String.format("CronJob %s/%s 刪除成功", namespace, name));
            
        } catch (ApiException e) {
            response.put("success", false);
            response.put("error", e.getResponseBody());
            response.put("message", "刪除 CronJob 失敗: " + e.getMessage());
        } catch (Exception e) {
            response.put("success", false);
            response.put("error", e.getMessage());
            response.put("message", "系統錯誤: " + e.getMessage());
        }
        
        return convertToJsonString(response);
    }

    // ======================================
    // Ingress/PVC/StatefulSet 工具
    // ======================================

    @Tool(description = "列出 Kubernetes Ingress")
    public String listMyK8sIngresses(@ToolParam(description = "命名空間") String namespace, 
                                      @ToolParam(description = "標籤選擇器") String labelSelector) {
        Map<String, Object> response = new HashMap<>();
        try {
            response.put("success", true);
            response.put("result", objectMapper.readValue(k8sOperationService.listIngresses(namespace, labelSelector), Object.class));
        } catch (Exception e) {
            response.put("success", false);
            response.put("error", e.getMessage());
        }
        return convertToJsonString(response);
    }

    @Tool(description = "獲取 Kubernetes Ingress")
    public String getMyK8sIngress(@ToolParam(description = "命名空間") String namespace, 
                                   @ToolParam(description = "名稱") String name) {
        Map<String, Object> response = new HashMap<>();
        try {
            response.put("success", true);
            response.put("result", objectMapper.readValue(k8sOperationService.getIngress(namespace, name), Object.class));
        } catch (Exception e) {
            response.put("success", false);
            response.put("error", e.getMessage());
        }
        return convertToJsonString(response);
    }

    @Tool(description = "刪除 Kubernetes Ingress")
    public String deleteMyK8sIngress(@ToolParam(description = "命名空間") String namespace, 
                                      @ToolParam(description = "名稱") String name) {
        Map<String, Object> response = new HashMap<>();
        try {
            response.put("success", true);
            response.put("result", objectMapper.readValue(k8sOperationService.deleteIngress(namespace, name), Object.class));
        } catch (Exception e) {
            response.put("success", false);
            response.put("error", e.getMessage());
        }
        return convertToJsonString(response);
    }

    @Tool(description = "列出 Kubernetes PVC")
    public String listMyK8sPVCs(@ToolParam(description = "命名空間") String namespace, 
                                 @ToolParam(description = "標籤選擇器") String labelSelector) {
        Map<String, Object> response = new HashMap<>();
        try {
            response.put("success", true);
            response.put("result", objectMapper.readValue(k8sOperationService.listPVCs(namespace, labelSelector), Object.class));
        } catch (Exception e) {
            response.put("success", false);
            response.put("error", e.getMessage());
        }
        return convertToJsonString(response);
    }

    @Tool(description = "獲取 Kubernetes PVC")
    public String getMyK8sPVC(@ToolParam(description = "命名空間") String namespace, 
                              @ToolParam(description = "名稱") String name) {
        Map<String, Object> response = new HashMap<>();
        try {
            response.put("success", true);
            response.put("result", objectMapper.readValue(k8sOperationService.getPVC(namespace, name), Object.class));
        } catch (Exception e) {
            response.put("success", false);
            response.put("error", e.getMessage());
        }
        return convertToJsonString(response);
    }

    @Tool(description = "刪除 Kubernetes PVC")
    public String deleteMyK8sPVC(@ToolParam(description = "命名空間") String namespace, 
                                  @ToolParam(description = "名稱") String name) {
        Map<String, Object> response = new HashMap<>();
        try {
            response.put("success", true);
            response.put("result", objectMapper.readValue(k8sOperationService.deletePVC(namespace, name), Object.class));
        } catch (Exception e) {
            response.put("success", false);
            response.put("error", e.getMessage());
        }
        return convertToJsonString(response);
    }

    @Tool(description = "列出 Kubernetes StatefulSet")
    public String listMyK8sStatefulSets(@ToolParam(description = "命名空間") String namespace, 
                                         @ToolParam(description = "標籤選擇器") String labelSelector) {
        Map<String, Object> response = new HashMap<>();
        try {
            response.put("success", true);
            response.put("result", objectMapper.readValue(k8sOperationService.listStatefulSets(namespace, labelSelector), Object.class));
        } catch (Exception e) {
            response.put("success", false);
            response.put("error", e.getMessage());
        }
        return convertToJsonString(response);
    }

    @Tool(description = "獲取 Kubernetes StatefulSet")
    public String getMyK8sStatefulSet(@ToolParam(description = "命名空間") String namespace, 
                                       @ToolParam(description = "名稱") String name) {
        Map<String, Object> response = new HashMap<>();
        try {
            response.put("success", true);
            response.put("result", objectMapper.readValue(k8sOperationService.getStatefulSet(namespace, name), Object.class));
        } catch (Exception e) {
            response.put("success", false);
            response.put("error", e.getMessage());
        }
        return convertToJsonString(response);
    }

    @Tool(description = "刪除 Kubernetes StatefulSet")
    public String deleteMyK8sStatefulSet(@ToolParam(description = "命名空間") String namespace, 
                                          @ToolParam(description = "名稱") String name) {
        Map<String, Object> response = new HashMap<>();
        try {
            response.put("success", true);
            response.put("result", objectMapper.readValue(k8sOperationService.deleteStatefulSet(namespace, name), Object.class));
        } catch (Exception e) {
            response.put("success", false);
            response.put("error", e.getMessage());
        }
        return convertToJsonString(response);
    }

    @Tool(description = "縮放 Kubernetes StatefulSet")
    public String scaleMyK8sStatefulSet(@ToolParam(description = "命名空間") String namespace, 
                                         @ToolParam(description = "名稱") String name,
                                         @ToolParam(description = "副本數") int replicas) {
        Map<String, Object> response = new HashMap<>();
        try {
            response.put("success", true);
            response.put("result", objectMapper.readValue(k8sOperationService.scaleStatefulSet(namespace, name, replicas), Object.class));
        } catch (Exception e) {
            response.put("success", false);
            response.put("error", e.getMessage());
        }
        return convertToJsonString(response);
    }
}
