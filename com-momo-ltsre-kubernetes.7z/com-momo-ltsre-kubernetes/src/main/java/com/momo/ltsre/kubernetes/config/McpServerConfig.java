package com.momo.ltsre.kubernetes.config;

import com.momo.ltsre.kubernetes.mcp.McpK8sToolsService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.tool.ToolCallbackProvider;
import org.springframework.ai.tool.method.MethodToolCallbackProvider;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * MCP Server 配置類別
 * 
 * 此類別負責將 Kubernetes 工具註冊到 Spring AI MCP Server 框架。
 * 
 * 使用 MethodToolCallbackProvider 自動掃描 McpK8sToolsService 中
 * 所有帶有 @Tool 註解的方法，並將它們註冊為 MCP 工具。
 * 
 * 註冊後的工具可以通過 MCP 協議被客戶端調用，
 * 例如 VS Code Copilot、Claude Desktop 等。
 * 
 * @author pf2tsai
 * @version 1.0.0
 */
@Slf4j
@Configuration
public class McpServerConfig {

    /**
     * 註冊 Kubernetes MCP 工具
     * 
     * 此 Bean 將 McpK8sToolsService 中所有 @Tool 註解的方法
     * 註冊到 MCP Server，使其可以被外部客戶端調用。
     * 
     * MethodToolCallbackProvider 會自動：
     * 1. 掃描 McpK8sToolsService 中的所有 @Tool 方法
     * 2. 解析方法參數上的 @ToolParam 註解
     * 3. 生成 MCP 工具描述（包括參數類型、描述等）
     * 4. 處理工具調用請求並轉發到對應的方法
     * 
     * @param mcpK8sToolsService Kubernetes MCP 工具服務
     * @return ToolCallbackProvider 實例
     */
    @Bean
    public ToolCallbackProvider k8sTools(McpK8sToolsService mcpK8sToolsService) {
        log.info("============================================");
        log.info("正在註冊 Kubernetes MCP 工具...");
        log.info("============================================");
        
        // 使用 MethodToolCallbackProvider 自動註冊所有 @Tool 方法
        ToolCallbackProvider provider = MethodToolCallbackProvider.builder()
                .toolObjects(mcpK8sToolsService)
                .build();
        
        log.info("Kubernetes MCP 工具註冊完成");
        log.info("已註冊的工具：");
        log.info("  基本操作 (13 個):");
        log.info("    - listMyK8sPods: 列出 Pod");
        log.info("    - listAllMyK8sPods: 列出所有命名空間的 Pod");
        log.info("    - getMyK8sPod: 獲取 Pod 詳細信息");
        log.info("    - getMyK8sPodLogs: 獲取 Pod 日誌");
        log.info("    - deleteMyK8sPod: 刪除 Pod");
        log.info("    - listMyK8sDeployments: 列出 Deployment");
        log.info("    - getMyK8sDeployment: 獲取 Deployment 詳情");
        log.info("    - deleteMyK8sDeployment: 刪除 Deployment");
        log.info("    - scaleMyK8sDeployment: 縮放 Deployment");
        log.info("    - listMyK8sNamespaces: 列出命名空間");
        log.info("    - execMyK8sPod: 在 Pod 中執行命令");
        log.info("    - runMyK8sPod: 運行新 Pod");
        log.info("    - topMyK8sPods: 查看 Pod 資源使用率");
        log.info("  通用資源操作 (5 個):");
        log.info("    - patchMyK8sResource: Patch 資源 ⭐");
        log.info("    - listMyK8sResources: 列出任意類型資源");
        log.info("    - getMyK8sResource: 獲取資源詳情");
        log.info("    - createOrUpdateMyK8sResource: 創建或更新資源");
        log.info("    - deleteMyK8sResource: 刪除資源");
        log.info("  Service 操作 (4 個) ⭐:");
        log.info("    - listMyK8sServices: 列出 Service");
        log.info("    - listAllMyK8sServices: 列出所有命名空間的 Service");
        log.info("    - getMyK8sService: 獲取 Service 詳情");
        log.info("    - deleteMyK8sService: 刪除 Service");
        log.info("  檔案複製操作 (2 個) ⭐:");
        log.info("    - copyFileFromMyK8sPod: 從 Pod 複製檔案到本地");
        log.info("    - copyFileToMyK8sPod: 從本地複製檔案到 Pod");
        log.info("  ConfigMap 操作 (4 個) ⭐:");
        log.info("    - listMyK8sConfigMaps: 列出 ConfigMap");
        log.info("    - getMyK8sConfigMap: 獲取 ConfigMap 詳情");
        log.info("    - createMyK8sConfigMap: 創建 ConfigMap");
        log.info("    - deleteMyK8sConfigMap: 刪除 ConfigMap");
        log.info("  Secret 操作 (4 個) ⭐:");
        log.info("    - listMyK8sSecrets: 列出 Secret");
        log.info("    - getMyK8sSecret: 獲取 Secret 詳情");
        log.info("    - createMyK8sSecret: 創建 Secret");
        log.info("    - deleteMyK8sSecret: 刪除 Secret");
        log.info("  Job 操作 (3 個) ⭐:");
        log.info("    - listMyK8sJobs: 列出 Job");
        log.info("    - getMyK8sJob: 獲取 Job 詳情");
        log.info("    - deleteMyK8sJob: 刪除 Job");
        log.info("  CronJob 操作 (3 個) ⭐:");
        log.info("    - listMyK8sCronJobs: 列出 CronJob");
        log.info("    - getMyK8sCronJob: 獲取 CronJob 詳情");
        log.info("    - deleteMyK8sCronJob: 刪除 CronJob");
        log.info("  Ingress 操作 (3 個) ⭐:");
        log.info("    - listMyK8sIngresses: 列出 Ingress");
        log.info("    - getMyK8sIngress: 獲取 Ingress 詳情");
        log.info("    - deleteMyK8sIngress: 刪除 Ingress");
        log.info("  PVC 操作 (3 個) ⭐:");
        log.info("    - listMyK8sPVCs: 列出 PersistentVolumeClaim");
        log.info("    - getMyK8sPVC: 獲取 PVC 詳情");
        log.info("    - deleteMyK8sPVC: 刪除 PVC");
        log.info("  StatefulSet 操作 (4 個) ⭐:");
        log.info("    - listMyK8sStatefulSets: 列出 StatefulSet");
        log.info("    - getMyK8sStatefulSet: 獲取 StatefulSet 詳情");
        log.info("    - deleteMyK8sStatefulSet: 刪除 StatefulSet");
        log.info("    - scaleMyK8sStatefulSet: 縮放 StatefulSet");
        log.info("  事件與節點監控 (5 個):");
        log.info("    - listMyK8sEvents: 列出集群事件");
        log.info("    - listMyK8sNodes: 列出集群節點");
        log.info("    - topMyK8sNodes: 查看節點資源使用率");
        log.info("    - logMyK8sNode: 獲取節點日誌");
        log.info("    - statsMyK8sNode: 獲取節點統計信息");
        log.info("  配置管理 (2 個):");
        log.info("    - listMyK8sConfigContexts: 列出配置上下文");
        log.info("    - viewMyK8sConfig: 查看當前配置");
        log.info("  Helm 支持 (3 個):");
        log.info("    - installMyK8sHelmChart: 安裝 Helm Chart");
        log.info("    - listMyK8sHelmReleases: 列出 Helm Releases");
        log.info("    - uninstallMyK8sHelmRelease: 卸載 Helm Release");
        log.info("  總計: 58 個工具 已註冊");
        log.info("============================================");
        
        return provider;
    }
}
