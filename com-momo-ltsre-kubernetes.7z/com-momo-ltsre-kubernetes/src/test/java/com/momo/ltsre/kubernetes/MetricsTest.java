package com.momo.ltsre.kubernetes;

import io.kubernetes.client.Metrics;
import io.kubernetes.client.custom.*;
import io.kubernetes.client.openapi.ApiClient;
import io.kubernetes.client.util.Config;

/**
 * 測試 Kubernetes Metrics API
 * 
 * 用於驗證 getPodTop 和 getNodeTop 的實作邏輯
 */
public class MetricsTest {
    public static void main(String[] args) throws Exception {
        System.out.println("=== Kubernetes Metrics API 測試 ===\n");
        
        // 初始化 Kubernetes Client
        ApiClient client = Config.defaultClient();
        Metrics metrics = new Metrics(client);
        
        // 測試 Node Metrics
        System.out.println("NODE METRICS:");
        System.out.println(String.format("%-20s %-15s %-15s", 
            "NAME", "CPU(cores)", "MEMORY(bytes)"));
        System.out.println("=".repeat(70));
        
        NodeMetricsList nodeMetrics = metrics.getNodeMetrics();
        for (NodeMetrics node : nodeMetrics.getItems()) {
            String name = node.getMetadata().getName();
            Quantity cpu = node.getUsage().get("cpu");
            Quantity mem = node.getUsage().get("memory");
            
            long cpuNano = cpu.getNumber().longValue();
            long memBytes = mem.getNumber().longValue();
            long cpuMillis = cpuNano / 1_000_000;
            long memMi = memBytes / (1024 * 1024);
            
            System.out.println(String.format("%-20s %-15s %-15s",
                name, cpuMillis + "m", memMi + "Mi"));
        }
        
        // 測試 Pod Metrics
        System.out.println("\n\nPOD METRICS (kube-system):");
        System.out.println(String.format("%-50s %-15s %-15s", 
            "NAME", "CPU(cores)", "MEMORY(bytes)"));
        System.out.println("=".repeat(80));
        
        PodMetricsList podMetrics = metrics.getPodMetrics("kube-system");
        for (PodMetrics pod : podMetrics.getItems()) {
            String name = pod.getMetadata().getName();
            long totalCpuNano = 0;
            long totalMemBytes = 0;
            
            for (ContainerMetrics container : pod.getContainers()) {
                Quantity cpu = container.getUsage().get("cpu");
                Quantity mem = container.getUsage().get("memory");
                if (cpu != null) totalCpuNano += cpu.getNumber().longValue();
                if (mem != null) totalMemBytes += mem.getNumber().longValue();
            }
            
            long cpuMillis = totalCpuNano / 1_000_000;
            long memMi = totalMemBytes / (1024 * 1024);
            
            System.out.println(String.format("%-50s %-15s %-15s",
                name, cpuMillis + "m", memMi + "Mi"));
        }
        
        System.out.println("\n✅ Metrics API 測試完成!");
    }
}
