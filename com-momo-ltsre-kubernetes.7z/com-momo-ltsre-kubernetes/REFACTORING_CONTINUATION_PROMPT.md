# Kubernetes MCP 服務架構簡化重構 - 續作任務

## 背景說明

我們正在進行一個重大的架構簡化重構,目的是消除不必要的 Java Bean 轉換層。因為這是一個純 MCP (Model Context Protocol) 專案,所有輸出都是給 AI 消費的,所以不需要將 Kubernetes API 的回傳先轉成 Java Bean,再轉回 JSON String。

### 架構變更

**原始架構 (複雜且不必要):**
```
Kubernetes API → Java Bean (PodInfo/DeploymentInfo/ResourceInfo等) → JSON String → AI
```

**目標架構 (簡潔高效):**
```
Kubernetes API → UTF-8 JSON String → AI
```

## 已完成的工作

### 1. K8sOperationService.java - ✅ 已完全重構完成

- ✅ 所有方法已改為返回 `String` (JSON 格式) 而非 Java Bean
- ✅ 刪除了所有 `convertTo*` 方法 (convertToPodInfo, convertToDeploymentInfo, convertToResourceInfo, convertToNodeInfo, convertToEventInfo)
- ✅ 刪除了 `matchesLabelSelector` 輔助方法
- ✅ 所有方法現在直接使用 `objectMapper.writeValueAsString()` 轉換 Kubernetes API 回應

**重構範例:**
```java
// 舊版本
public List<PodInfo> listPods(String namespace, String labelSelector) {
    // ... API 呼叫 ...
    return podList.getItems().stream()
        .map(this::convertToPodInfo)
        .collect(Collectors.toList());
}

// 新版本
public String listPods(String namespace, String labelSelector) throws Exception {
    // ... API 呼叫 ...
    return objectMapper.writeValueAsString(podList);
}
```

### 2. McpK8sToolsService.java - ⚠️ 部分完成

已簡化的方法 (約 7 個):
- ✅ `listMyK8sPods`
- ✅ `getMyK8sPod`
- ✅ `getMyK8sPodLogs`
- ✅ `execMyK8sPod`
- ✅ `runMyK8sPod`
- ✅ `deleteMyK8sPod`
- ✅ `createOrUpdateMyK8sResource`

已添加的輔助方法:
- ✅ `createErrorResponse(String error)` - 在檔案末尾

**簡化模式:**
```java
// 舊版本
@Tool(name = "listMyK8sPods", description = "...")
public String listMyK8sPods(...) {
    try {
        List<PodInfo> pods = k8sOperationService.listPods(namespace, labelSelector);
        Map<String, Object> response = new HashMap<>();
        response.put("success", true);
        response.put("data", pods);
        return objectMapper.writeValueAsString(response);
    } catch (Exception e) {
        Map<String, Object> errorResponse = new HashMap<>();
        errorResponse.put("success", false);
        errorResponse.put("error", e.getMessage());
        return objectMapper.writeValueAsString(errorResponse);
    }
}

// 新版本
@Tool(name = "listMyK8sPods", description = "...")
public String listMyK8sPods(...) {
    try {
        return k8sOperationService.listPods(namespace, labelSelector);
    } catch (Exception e) {
        return createErrorResponse(e.getMessage());
    }
}
```

## 待完成的工作

### 任務 1: 完成 McpK8sToolsService.java 的剩餘方法簡化 (約 20 個方法)

需要簡化的方法清單:

**Deployment 相關 (5 個方法):**
1. `listMyK8sDeployments` - 列出 Deployments
2. `getMyK8sDeployment` - 取得單一 Deployment
3. `deleteMyK8sDeployment` - 刪除 Deployment
4. `scaleMyK8sDeployment` - 擴展 Deployment 副本數
5. `getMyK8sDeploymentStatus` - 取得 Deployment 狀態

**Resource 相關 (3 個方法):**
6. `listMyK8sResources` - 列出指定類型的資源
7. `getMyK8sResource` - 取得單一資源詳情
8. `deleteMyK8sResource` - 刪除指定資源

**Node 相關 (3 個方法):**
9. `listMyK8sNodes` - 列出所有節點
10. `getMyK8sNode` - 取得單一節點詳情
11. `getMyK8sNodeStats` - 取得節點統計資訊

**Helm 相關 (4 個方法):**
12. `listMyK8sHelmReleases` - 列出 Helm releases
13. `getMyK8sHelmRelease` - 取得單一 Helm release
14. `installMyK8sHelmChart` - 安裝 Helm chart
15. `uninstallMyK8sHelmRelease` - 卸載 Helm release

**其他資源 (5 個方法):**
16. `listMyK8sEvents` - 列出事件
17. `listMyK8sNamespaces` - 列出命名空間
18. `viewMyK8sConfig` - 查看 kubeconfig
19. `listMyK8sConfigContexts` - 列出 kubeconfig contexts
20. `getMyK8sResourceUsage` - 取得 Pod 資源使用情況

**每個方法的簡化步驟:**
1. 移除 `List<*Info>` 或 `*Info` 的回傳類型處理
2. 移除 `Map<String, Object> response` 的建立
3. 移除 `response.put("success", true)` 和 `response.put("data", ...)` 的邏輯
4. 直接返回 `k8sOperationService.*()` 的結果 (已經是 JSON String)
5. catch 區塊改為使用 `createErrorResponse(e.getMessage())`

### 任務 2: 刪除 Bean 模型類 (5 個檔案)

需要刪除的檔案:
1. `src/main/java/com/momo/ltsre/kubernetes/model/PodInfo.java`
2. `src/main/java/com/momo/ltsre/kubernetes/model/DeploymentInfo.java`
3. `src/main/java/com/momo/ltsre/kubernetes/model/ResourceInfo.java`
4. `src/main/java/com/momo/ltsre/kubernetes/model/NodeInfo.java`
5. `src/main/java/com/momo/ltsre/kubernetes/model/EventInfo.java`

**執行方式:**
使用 PowerShell 命令刪除:
```powershell
Remove-Item "c:\MyVsCodeWorkspace\local-infra\com-momo-ltsre-kubernetes\src\main\java\com\momo\ltsre\kubernetes\model\PodInfo.java"
Remove-Item "c:\MyVsCodeWorkspace\local-infra\com-momo-ltsre-kubernetes\src\main\java\com\momo\ltsre\kubernetes\model\DeploymentInfo.java"
Remove-Item "c:\MyVsCodeWorkspace\local-infra\com-momo-ltsre-kubernetes\src\main\java\com\momo\ltsre\kubernetes\model\ResourceInfo.java"
Remove-Item "c:\MyVsCodeWorkspace\local-infra\com-momo-ltsre-kubernetes\src\main\java\com\momo\ltsre\kubernetes\model\NodeInfo.java"
Remove-Item "c:\MyVsCodeWorkspace\local-infra\com-momo-ltsre-kubernetes\src\main\java\com\momo\ltsre\kubernetes\model\EventInfo.java"
```

### 任務 3: 移除未使用的 import 語句

在 `McpK8sToolsService.java` 中,刪除所有對已刪除 Bean 類的 import:
- `import com.momo.ltsre.kubernetes.model.PodInfo;`
- `import com.momo.ltsre.kubernetes.model.DeploymentInfo;`
- `import com.momo.ltsre.kubernetes.model.ResourceInfo;`
- `import com.momo.ltsre.kubernetes.model.NodeInfo;`
- `import com.momo.ltsre.kubernetes.model.EventInfo;`

可能也需要移除:
- `import java.util.List;` (如果不再使用)
- `import java.util.stream.Collectors;` (如果不再使用)

### 任務 4: 編譯並測試

**步驟 1: 編譯專案**
```powershell
cd c:\MyVsCodeWorkspace\local-infra\com-momo-ltsre-kubernetes
mvn clean compile
```

**步驟 2: 打包專案**
```powershell
mvn clean package -DskipTests
```

**步驟 3: 重啟 MCP 服務**

⚠️ **重要:必須使用正確的方式重啟服務,否則會一直報錯!**

```powershell
# 1. 檢查 10011 端口是否被佔用
netstat -ano | findstr :10011

# 2. 如果有輸出,記下最後一欄的 PID,然後停止該 Java 程序
# 假設 PID 是 12345,執行:
taskkill /F /PID 12345

# 3. 切換到專案目錄 (使用完整路徑)
cd c:\MyVsCodeWorkspace\local-infra\com-momo-ltsre-kubernetes

# 4. 啟動服務
mvn spring-boot:run
```

**完整的重啟腳本 (建議使用):**
```powershell
# 一鍵重啟腳本
$port = 10011
$process = Get-NetTCPConnection -LocalPort $port -ErrorAction SilentlyContinue | Select-Object -ExpandProperty OwningProcess
if ($process) {
    Write-Host "停止佔用端口 $port 的程序 (PID: $process)..."
    Stop-Process -Id $process -Force
    Start-Sleep -Seconds 2
}
cd c:\MyVsCodeWorkspace\local-infra\com-momo-ltsre-kubernetes
Write-Host "啟動 MCP 服務..."
mvn spring-boot:run
```

**步驟 4: 測試關鍵工具**

服務啟動後 (看到 "Started KubernetesMcpServerApplication" 訊息),測試:
1. `createOrUpdateMyK8sResource` - 建立/更新資源 (原始失敗的測試案例)
2. `listMyK8sPods` - 列出 Pods
3. `listMyK8sDeployments` - 列出 Deployments
4. `getMyK8sResource` - 取得資源詳情
5. `deleteMyK8sResource` - 刪除資源

## 重構指南

### 使用 multi_replace_string_in_file 工具批量處理

由於有 20 個方法需要簡化,建議分批處理:

**批次 1: Deployment 相關 (5 個方法)**
**批次 2: Resource 相關 (3 個方法)**
**批次 3: Node 相關 (3 個方法)**
**批次 4: Helm 相關 (4 個方法)**
**批次 5: 其他資源 (5 個方法)**

每批次使用 `multi_replace_string_in_file` 一次處理 3-5 個方法。

### 標準簡化模板

```java
// 對於返回列表的方法
@Tool(name = "methodName", description = "...")
public String methodName(String param1, String param2) {
    try {
        return k8sOperationService.serviceMethod(param1, param2);
    } catch (Exception e) {
        return createErrorResponse(e.getMessage());
    }
}

// 對於返回單一物件的方法
@Tool(name = "methodName", description = "...")
public String methodName(String param1) {
    try {
        return k8sOperationService.serviceMethod(param1);
    } catch (Exception e) {
        return createErrorResponse(e.getMessage());
    }
}

// 對於執行操作的方法 (如 delete, scale)
@Tool(name = "methodName", description = "...")
public String methodName(String param1, int param2) {
    try {
        return k8sOperationService.serviceMethod(param1, param2);
    } catch (Exception e) {
        return createErrorResponse(e.getMessage());
    }
}
```

## 檔案位置

- K8sOperationService: `c:\MyVsCodeWorkspace\local-infra\com-momo-ltsre-kubernetes\src\main\java\com\momo\ltsre\kubernetes\service\K8sOperationService.java`
- McpK8sToolsService: `c:\MyVsCodeWorkspace\local-infra\com-momo-ltsre-kubernetes\src\main\java\com\momo\ltsre\kubernetes\mcp\McpK8sToolsService.java`
- Model 類: `c:\MyVsCodeWorkspace\local-infra\com-momo-ltsre-kubernetes\src\main\java\com\momo\ltsre\kubernetes\model\`

## 預期結果

重構完成後:
1. **程式碼簡潔度:** McpK8sToolsService 每個方法從 ~15 行減少到 ~7 行
2. **維護性:** 消除雙重轉換邏輯,降低錯誤風險
3. **效能:** 減少一次 Bean 序列化/反序列化過程
4. **清晰度:** 架構更直觀 - MCP 層只負責錯誤包裝,Service 層負責資料轉換

## 注意事項

1. **createErrorResponse 方法已存在** - 在 McpK8sToolsService.java 末尾
2. **所有 K8sOperationService 方法已返回 String** - 可以直接使用
3. **保持 @Tool 註解不變** - 只修改方法實作
4. **編譯前先刪除 Bean 類** - 避免編譯錯誤
5. **測試時注意 JSON 格式** - 確保 AI 可以正確解析

## 開始指令

請繼續完成以下任務:
1. 簡化 McpK8sToolsService.java 中剩餘的 20 個方法
2. 刪除 5 個 Bean 模型類
3. 清理未使用的 import
4. 編譯測試

使用繁體中文回應,並採用批量處理方式提高效率。
