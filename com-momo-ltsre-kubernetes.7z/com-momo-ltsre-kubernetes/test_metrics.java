///usr/bin/env jbang "$0" "$@" ; exit $?
//DEPS io.kubernetes:client-java:21.0.1
//DEPS org.slf4j:slf4j-simple:2.0.9

import io.kubernetes.client.Metrics;
import io.kubernetes.client.custom.*;
import io.kubernetes.client.openapi.ApiClient;
import io.kubernetes.client.util.Config;

/**
 * 測試 Kubernetes Metrics API
 * 
 * 驗證 getPodTop 和 getNodeTop 方法的邏輯
 */
public class test_metrics {
    public static void main(String[] args) throws Exception {
        System.out.println("=== Kubernetes Metrics API 測試 ===\n");
        
        // 初始化 Kubernetes Client
        ApiClient client = Config.defaultClient();
        Metrics metrics = new Metrics(client);
        
        // 測試 Node Metrics
        System.out.println("NODE METRICS:");
        System.out.println(String.format("%-20s %-15s %-10s %-15s %-10s", 
            "NAME", "CPU(cores)", "CPU%", "MEMORY(bytes)", "MEMORY%"));
        System.out.println("=".repeat(80));
        
        NodeMetricsList nodeMetrics = metrics.getNodeMetrics();
        for (NodeMetrics node : nodeMetrics.getItems()) {
            String name = node.getMetadata().getName();
            Quantity cpu = node.getUsage().get("cpu");
            Quantity mem = node.getUsage().get("memory");
            
            long cpuNano = cpu.getNumber().longValue();
            long memBytes = mem.getNumber().longValue();
            long cpuMillis = cpuNano / 1_000_000;
            long memMi = memBytes / (1024 * 1024);
            
            System.out.println(String.format("%-20s %-15s %-10s %-15s %-10s",
                name, cpuMillis + "m", "N/A", memMi + "Mi", "N/A"));
        }
        
        // 測試 Pod Metrics
        System.out.println("\n\nPOD METRICS (kube-system):");
        System.out.println(String.format("%-50s %-15s %-15s", 
            "NAME", "CPU(cores)", "MEMORY(bytes)"));
        System.out.println("=".repeat(80));
        
        PodMetricsList podMetrics = metrics.getPodMetrics("kube-system");
        for (PodMetrics pod : podMetrics.getItems()) {
            String name = pod.getMetadata().getName();
            long totalCpuNano = 0;
            long totalMemBytes = 0;
            
            for (ContainerMetrics container : pod.getContainers()) {
                Quantity cpu = container.getUsage().get("cpu");
                Quantity mem = container.getUsage().get("memory");
                if (cpu != null) totalCpuNano += cpu.getNumber().longValue();
                if (mem != null) totalMemBytes += mem.getNumber().longValue();
            }
            
            long cpuMillis = totalCpuNano / 1_000_000;
            long memMi = totalMemBytes / (1024 * 1024);
            
            System.out.println(String.format("%-50s %-15s %-15s",
                name, cpuMillis + "m", memMi + "Mi"));
        }
        
        System.out.println("\n✅ Metrics API 測試完成!");
    }
}
