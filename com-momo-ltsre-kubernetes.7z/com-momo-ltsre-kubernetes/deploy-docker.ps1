# Kubernetes MCP Server Docker 部署腳本
# 
# 功能:
# 1. 停止並移除舊的 k8s-mcp-server 容器
# 2. 刪除舊的映像
# 3. 構建新的 Docker 映像
# 4. 運行新容器,對外暴露在 port 10001

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Kubernetes MCP Server Docker 部署" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# 檢查 Docker 是否運行
Write-Host "[1/5] 檢查 Docker 狀態..." -ForegroundColor Yellow
try {
    $dockerInfo = docker info 2>&1
    if ($LASTEXITCODE -ne 0) {
        throw "Docker 未運行"
    }
    Write-Host "✓ Docker 正在運行" -ForegroundColor Green
} catch {
    Write-Host "✗ Docker 未運行" -ForegroundColor Red
    Write-Host "請先啟動 Docker Desktop,然後重新執行此腳本" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "啟動 Docker Desktop 後,執行:" -ForegroundColor Cyan
    Write-Host "  .\deploy-docker.ps1" -ForegroundColor White
    exit 1
}
Write-Host ""

# 停止並移除舊容器
Write-Host "[2/5] 移除舊容器..." -ForegroundColor Yellow
$oldContainer = docker ps -a --filter "name=k8s-mcp-server" --format "{{.ID}}"
if ($oldContainer) {
    Write-Host "  找到舊容器: $oldContainer" -ForegroundColor Gray
    docker stop $oldContainer 2>$null | Out-Null
    docker rm $oldContainer 2>$null | Out-Null
    Write-Host "✓ 已移除舊容器" -ForegroundColor Green
} else {
    Write-Host "✓ 沒有找到舊容器" -ForegroundColor Green
}
Write-Host ""

# 刪除舊映像
Write-Host "[3/5] 移除舊映像..." -ForegroundColor Yellow
$oldImage = docker images kubernetes-mcp-server --format "{{.ID}}"
if ($oldImage) {
    Write-Host "  找到舊映像: $oldImage" -ForegroundColor Gray
    docker rmi $oldImage 2>$null | Out-Null
    Write-Host "✓ 已移除舊映像" -ForegroundColor Green
} else {
    Write-Host "✓ 沒有找到舊映像" -ForegroundColor Green
}
Write-Host ""

# 構建新映像
Write-Host "[4/5] 構建 Docker 映像..." -ForegroundColor Yellow
docker build -t kubernetes-mcp-server:latest .
if ($LASTEXITCODE -ne 0) {
    Write-Host "✗ Docker 映像構建失敗" -ForegroundColor Red
    exit 1
}
Write-Host "✓ Docker 映像構建成功" -ForegroundColor Green
Write-Host ""

# 運行容器
Write-Host "[5/5] 啟動容器..." -ForegroundColor Yellow
Write-Host "  容器名稱: k8s-mcp-server" -ForegroundColor Gray
Write-Host "  內部端口: 8080" -ForegroundColor Gray
Write-Host "  對外端口: 10001" -ForegroundColor Gray
Write-Host "  kubeconfig: 掛載 ~/.kube/config" -ForegroundColor Gray
Write-Host ""

docker run -d `
  --name k8s-mcp-server `
  -p 10001:8080 `
  -v ${env:USERPROFILE}\.kube:/root/.kube:ro `
  --restart unless-stopped `
  kubernetes-mcp-server:latest

if ($LASTEXITCODE -ne 0) {
    Write-Host "✗ 容器啟動失敗" -ForegroundColor Red
    exit 1
}

Write-Host "✓ 容器啟動成功" -ForegroundColor Green
Write-Host ""

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "部署完成!" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "MCP 服務端點: http://localhost:10001/mcp/sse" -ForegroundColor White
Write-Host ""
Write-Host "查看容器狀態: docker ps -f name=k8s-mcp-server" -ForegroundColor Gray
Write-Host "查看容器日誌: docker logs k8s-mcp-server" -ForegroundColor Gray
Write-Host "進入容器內部: docker exec -it k8s-mcp-server sh" -ForegroundColor Gray
Write-Host "停止容器: docker stop k8s-mcp-server" -ForegroundColor Gray
Write-Host ""
