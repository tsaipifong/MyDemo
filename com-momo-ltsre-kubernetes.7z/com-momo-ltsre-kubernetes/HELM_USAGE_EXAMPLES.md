# Helm 功能使用範例

## 前置需求

### 1. 安裝 Helm CLI

#### Windows (使用 Scoop)
```powershell
scoop install helm
```

#### Windows (使用 Chocolatey)
```powershell
choco install kubernetes-helm
```

#### Linux
```bash
curl https://raw.githubusercontent.com/helm/helm/main/scripts/get-helm-3 | bash
```

#### macOS
```bash
brew install helm
```

### 2. 驗證安裝
```bash
helm version
```

## MCP Tool 使用範例

### 1. 安裝 Helm Chart

#### 範例 1: 安裝 NGINX
```json
{
  "tool": "installMyK8sHelmChart",
  "parameters": {
    "releaseName": "my-nginx",
    "chart": "bitnami/nginx",
    "namespace": "web",
    "values": ""
  }
}
```

AI 對話範例:
```
用戶: 幫我安裝一個 nginx
AI: 我需要一些資訊來安裝 nginx:
    1. Release 名稱 (例如: my-nginx)
    2. 要使用哪個 Chart? (例如: bitnami/nginx)
    3. 要部署到哪個命名空間? (預設為 default)
    
用戶: release 叫 web-server,用 bitnami/nginx,部署到 production 命名空間
AI: [調用 installMyK8sHelmChart]
```

#### 範例 2: 安裝帶自定義配置的 MySQL
```json
{
  "tool": "installMyK8sHelmChart",
  "parameters": {
    "releaseName": "my-database",
    "chart": "bitnami/mysql",
    "namespace": "database",
    "values": "auth:\n  rootPassword: MySecurePassword123\n  database: myapp\n  username: myuser\n  password: MyUserPassword123\nprimary:\n  persistence:\n    size: 20Gi"
  }
}
```

AI 對話範例:
```
用戶: 安裝 MySQL,root 密碼設為 MySecurePassword123,創建資料庫 myapp
AI: 好的,我會幫您安裝 MySQL。還需要:
    1. Release 名稱 (例如: my-mysql)
    2. 要部署到哪個命名空間? (預設為 default)
    
用戶: 叫 production-db,部署到 database 命名空間
AI: [調用 installMyK8sHelmChart]
```

### 2. 列出 Helm Releases

#### 範例 1: 列出所有 releases
```json
{
  "tool": "listMyK8sHelmReleases",
  "parameters": {
    "namespace": ""
  }
}
```

AI 對話範例:
```
用戶: 列出所有 helm releases
AI: [調用 listMyK8sHelmReleases(namespace: "")]
```

#### 範例 2: 列出特定命名空間的 releases
```json
{
  "tool": "listMyK8sHelmReleases",
  "parameters": {
    "namespace": "production"
  }
}
```

AI 對話範例:
```
用戶: production 命名空間有哪些 helm releases?
AI: [調用 listMyK8sHelmReleases(namespace: "production")]
```

### 3. 卸載 Helm Release

#### 範例: 卸載 NGINX release
```json
{
  "tool": "uninstallMyK8sHelmRelease",
  "parameters": {
    "releaseName": "my-nginx",
    "namespace": "web"
  }
}
```

AI 對話範例:
```
用戶: 刪除 nginx
AI: 我需要知道:
    1. Release 名稱是什麼? (例如: my-nginx)
    2. 在哪個命名空間? (例如: default)
    
用戶: release 叫 web-server,在 production 命名空間
AI: [調用 uninstallMyK8sHelmRelease]
```

## 錯誤處理範例

### 未安裝 Helm CLI

**用戶請求**:
```
用戶: 安裝一個 nginx chart
```

**系統返回**:
```json
{
  "success": false,
  "data": {
    "error": "Helm CLI 未安裝",
    "message": "請先安裝 Helm CLI 工具",
    "installation": {
      "windows": {
        "scoop": "scoop install helm",
        "chocolatey": "choco install kubernetes-helm",
        "manual": "https://github.com/helm/helm/releases"
      },
      "linux": {
        "script": "curl https://raw.githubusercontent.com/helm/helm/main/scripts/get-helm-3 | bash",
        "snap": "sudo snap install helm --classic"
      },
      "macos": {
        "homebrew": "brew install helm"
      },
      "official": "https://helm.sh/docs/intro/install/"
    }
  }
}
```

**AI 回應**:
```
AI: 您的系統尚未安裝 Helm CLI。請根據您的作業系統選擇安裝方式:

Windows:
- 使用 Scoop: scoop install helm
- 使用 Chocolatey: choco install kubernetes-helm

Linux:
- 使用安裝腳本: curl https://raw.githubusercontent.com/helm/helm/main/scripts/get-helm-3 | bash
- 使用 Snap: sudo snap install helm --classic

macOS:
- 使用 Homebrew: brew install helm

更多資訊請參考: https://helm.sh/docs/intro/install/
```

### 缺少必要參數

**用戶請求**:
```
用戶: 安裝 helm chart
```

**AI 回應** (根據 Tool 描述引導):
```
AI: 好的,我需要一些資訊來安裝 Helm chart:

必要參數:
1. Release 名稱 - 給這個部署取一個名字 (例如: my-app)
2. Chart 名稱 - 要安裝哪個 chart? (例如: bitnami/nginx, stable/mysql)

可選參數:
3. 命名空間 - 要部署到哪個命名空間? (預設為 'default')
4. 自定義配置 - 需要自定義任何配置嗎? (YAML 格式)

請提供必要的資訊。
```

## 完整工作流程範例

### 場景: 部署一個完整的 Web 應用

#### 步驟 1: 安裝 PostgreSQL 資料庫
```
用戶: 我要部署一個 web 應用,先安裝 PostgreSQL

AI: 好的,我需要以下資訊:
    1. Release 名稱 (例如: my-postgres)
    2. 要部署到哪個命名空間? (預設為 default)
    3. 需要設定資料庫密碼嗎?

用戶: release 叫 webapp-db,部署到 production,密碼設為 SecurePass123

AI: [調用 installMyK8sHelmChart]
    releaseName: "webapp-db"
    chart: "bitnami/postgresql"
    namespace: "production"
    values: "auth:\n  password: SecurePass123"
```

#### 步驟 2: 安裝 Redis 快取
```
用戶: 再安裝一個 Redis

AI: [調用 installMyK8sHelmChart]
    releaseName: "webapp-redis"
    chart: "bitnami/redis"
    namespace: "production"
    values: ""
```

#### 步驟 3: 查看已安裝的服務
```
用戶: 列出 production 命名空間的所有 releases

AI: [調用 listMyK8sHelmReleases]
    namespace: "production"
    
回應:
[
  {
    "name": "webapp-db",
    "namespace": "production",
    "revision": "1",
    "status": "deployed",
    "chart": "postgresql-12.1.0",
    "app_version": "15.2.0"
  },
  {
    "name": "webapp-redis",
    "namespace": "production",
    "revision": "1",
    "status": "deployed",
    "chart": "redis-17.8.0",
    "app_version": "7.0.9"
  }
]
```

#### 步驟 4: 清理不需要的服務
```
用戶: 刪除 Redis,不需要了

AI: [調用 uninstallMyK8sHelmRelease]
    releaseName: "webapp-redis"
    namespace: "production"
```

## 常見 Chart 範例

### 1. 資料庫類

#### PostgreSQL
```yaml
# Chart: bitnami/postgresql
# 基本安裝
releaseName: my-postgres
chart: bitnami/postgresql
namespace: database
values: |
  auth:
    postgresPassword: postgres123
    database: myapp
  primary:
    persistence:
      size: 10Gi
```

#### MySQL
```yaml
# Chart: bitnami/mysql
releaseName: my-mysql
chart: bitnami/mysql
namespace: database
values: |
  auth:
    rootPassword: root123
    database: myapp
    username: appuser
    password: apppass123
  primary:
    persistence:
      size: 10Gi
```

#### MongoDB
```yaml
# Chart: bitnami/mongodb
releaseName: my-mongodb
chart: bitnami/mongodb
namespace: database
values: |
  auth:
    rootPassword: mongo123
  persistence:
    size: 20Gi
```

### 2. 快取和訊息佇列

#### Redis
```yaml
# Chart: bitnami/redis
releaseName: my-redis
chart: bitnami/redis
namespace: cache
values: |
  auth:
    password: redis123
  master:
    persistence:
      size: 8Gi
```

#### RabbitMQ
```yaml
# Chart: bitnami/rabbitmq
releaseName: my-rabbitmq
chart: bitnami/rabbitmq
namespace: messaging
values: |
  auth:
    username: admin
    password: rabbitmq123
  persistence:
    size: 8Gi
```

### 3. Web 服務

#### NGINX
```yaml
# Chart: bitnami/nginx
releaseName: my-nginx
chart: bitnami/nginx
namespace: web
values: |
  replicaCount: 3
  service:
    type: LoadBalancer
    port: 80
```

#### Apache
```yaml
# Chart: bitnami/apache
releaseName: my-apache
chart: bitnami/apache
namespace: web
values: |
  replicaCount: 2
  service:
    type: LoadBalancer
```

### 4. 監控和日誌

#### Prometheus
```yaml
# Chart: prometheus-community/prometheus
releaseName: monitoring-prometheus
chart: prometheus-community/prometheus
namespace: monitoring
values: |
  server:
    retention: "30d"
    persistentVolume:
      size: 50Gi
```

#### Grafana
```yaml
# Chart: grafana/grafana
releaseName: monitoring-grafana
chart: grafana/grafana
namespace: monitoring
values: |
  adminPassword: admin123
  persistence:
    enabled: true
    size: 10Gi
```

## 進階技巧

### 1. 使用本地 Chart
```json
{
  "tool": "installMyK8sHelmChart",
  "parameters": {
    "releaseName": "my-app",
    "chart": "./charts/my-custom-chart",
    "namespace": "default",
    "values": ""
  }
}
```

### 2. 使用特定版本的 Chart
```json
{
  "tool": "installMyK8sHelmChart",
  "parameters": {
    "releaseName": "my-nginx",
    "chart": "bitnami/nginx --version 15.0.0",
    "namespace": "web",
    "values": ""
  }
}
```

### 3. 複雜的 Values 配置
```yaml
# 多副本 + 資源限制 + 自動擴展
replicaCount: 3
resources:
  limits:
    cpu: 500m
    memory: 512Mi
  requests:
    cpu: 250m
    memory: 256Mi
autoscaling:
  enabled: true
  minReplicas: 3
  maxReplicas: 10
  targetCPUUtilizationPercentage: 80
service:
  type: LoadBalancer
  port: 80
ingress:
  enabled: true
  hosts:
    - host: myapp.example.com
      paths:
        - /
```

## 故障排除

### 1. Chart 找不到
```
錯誤: chart "xxx" not found

解決方案:
1. 確認 chart 名稱正確
2. 添加 helm repo: helm repo add bitnami https://charts.bitnami.com/bitnami
3. 更新 repo: helm repo update
```

### 2. 命名空間不存在
```
不用擔心! helmInstall 會自動創建命名空間 (--create-namespace)
```

### 3. Release 已存在
```
錯誤: release "xxx" already exists

解決方案:
1. 使用不同的 release 名稱
2. 先卸載舊的 release
3. 或使用 helm upgrade (未來功能)
```

## 相關資源

- [Helm 官方文檔](https://helm.sh/docs/)
- [Artifact Hub - Chart 搜索](https://artifacthub.io/)
- [Bitnami Charts](https://github.com/bitnami/charts)
- [Helm Charts 最佳實踐](https://helm.sh/docs/chart_best_practices/)

---

**文檔版本**: 1.0.0  
**最後更新**: 2025-11-18
