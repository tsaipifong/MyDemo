# Docker 管理 MCP Server

基於 Spring Boot 和 Spring AI 實現的 Docker 管理 MCP (Model Context Protocol) Server，提供完整的 Docker 容器、映像檔、網路和磁碟區管理功能。

## 專案概覽

本專案使用 Spring AI MCP Server 框架，透過 Docker Java API 與 Docker Desktop 進行通訊，將 Docker 管理功能透過 MCP 協議暴露給 AI 模型使用。支援透過 HTTP 或 stdio 兩種模式運行。

## 主要特色

- ✅ **完整的 Docker 管理功能** - 容器、映像檔、網路、磁碟區的完整生命週期管理
- ✅ **MCP 協議支援** - 基於 Spring AI MCP Server 實現，與 AI 模型無縫整合
- ✅ **雙模式運行** - 支援 HTTP 和 stdio 兩種通訊模式
- ✅ **容器化部署** - 提供 Dockerfile 輕鬆部署到容器環境
- ✅ **豐富的工具註解** - 每個 MCP 工具都有詳細的描述和參數說明
- ✅ **完整的單元測試** - 涵蓋所有核心功能的測試用例

## 專案目錄結構

```
com-momo-ltsre-docker/
├── Dockerfile                                  # Docker 映像檔建構檔
├── HELP.md                                     # 幫助文件
├── mvnw                                        # Maven wrapper 執行檔 (Unix/Linux/Mac)
├── mvnw.cmd                                    # Maven wrapper 執行檔 (Windows)
├── pom.xml                                     # Maven 專案配置檔
├── README.md                                   # 專案說明文件
└── src/
    ├── main/
    │   ├── java/com/momo/ltsre/docker/
    │   │   ├── ComMomoLtsreDockerApplication.java      # Spring Boot 應用程式主入口
    │   │   ├── config/
    │   │   │   └── McpServerConfig.java                # MCP Server 配置類別
    │   │   └── service/
    │   │       ├── McpRemoteDockerService.java         # MCP Docker 工具服務（暴露給 AI）
    │   │       └── RemoteDockerService.java            # Docker API 底層服務實現
    │   └── resources/
    │       ├── application.properties                  # 應用程式配置檔
    │       ├── logback-spring.xml                      # 日誌配置檔
    │       └── META-INF/
    │           └── spring-configuration-metadata.json  # Spring 配置元數據
    └── test/
        ├── java/com/momo/ltsre/docker/
        │   ├── ComMomoLtsreDockerApplicationTests.java # 應用程式基礎測試
        │   └── service/
        │       └── RemoteDockerServiceTest.java        # Docker 服務整合測試
        └── resources/
            ├── application.properties                  # 測試環境配置
            └── logback-spring.xml                      # 測試日誌配置
```

## 核心功能

### 🐳 容器管理 (Container Management)
- **`listContainers(showAll)`** - 列出容器（可選是否包含已停止的容器）
- **`createContainer(imageName, containerName)`** - 建立容器但不啟動
- **`runContainer(imageName, containerName, ports, envVars)`** - 運行容器（建立並啟動，支援端口映射和環境變數）
- **`runContainerWithCommand(imageName, containerName, cmd, ports, envVars)`** - 以自訂命令運行容器
- **`startContainer(containerIdOrName)`** - 啟動已停止的容器
- **`stopContainer(containerIdOrName)`** - 停止運行中的容器
- **`removeContainer(containerIdOrName, force)`** - 移除容器（可強制移除運行中的容器）
- **`getContainerLogs(containerIdOrName, tail, follow)`** - 獲取容器日誌

### 🖼️ 映像檔管理 (Image Management)
- **`listImages(showDangling)`** - 列出映像檔（可選是否顯示懸掛映像檔）
- **`pullImage(imageName)`** - 從 Docker Hub 或其他註冊庫拉取映像檔
- **`pushImage(imageName)`** - 推送映像檔到遠端註冊庫
- **`buildImage(dockerfilePath, imageName, buildContext)`** - 從 Dockerfile 建構映像檔
- **`removeImage(imageIdOrName, force)`** - 移除映像檔（可強制移除）

### 🌐 網路管理 (Network Management)
- **`listNetworks()`** - 列出所有 Docker 網路
- **`createNetwork(networkName, driver)`** - 建立自訂網路（支援 bridge、overlay 等驅動）
- **`removeNetwork(networkIdOrName)`** - 移除網路

### 💾 磁碟區管理 (Volume Management)
- **`listVolumes()`** - 列出所有 Docker 磁碟區
- **`createVolume(volumeName, driver, driverOpts)`** - 建立磁碟區（支援驅動選項）
- **`removeVolume(volumeName, force)`** - 移除磁碟區（可強制移除）

### 🔧 系統資訊
- **`getDockerVersion()`** - 獲取 Docker 版本和系統資訊

## 技術架構

### 核心依賴
- **Spring Boot 3.4.10** - 應用程式框架
- **Spring AI 1.0.3** - MCP Server 框架支援
- **Java 21** - 執行環境
- **Docker Java API 3.3.4** - Docker 客戶端程式庫
- **Apache HttpClient 5** - HTTP 傳輸層
- **Lombok** - 程式碼簡化工具
- **JUnit 5** - 單元測試框架

### 架構層次

```
┌─────────────────────────────────────────┐
│   AI 模型 (透過 MCP Client 連接)        │
└─────────────────┬───────────────────────┘
                  │ MCP Protocol
┌─────────────────▼───────────────────────┐
│     Spring AI MCP Server                │
│  (HTTP/stdio 傳輸層)                    │
└─────────────────┬───────────────────────┘
                  │
┌─────────────────▼───────────────────────┐
│   McpRemoteDockerService                │
│  (MCP 工具提供者 - @Tool 註解)          │
└─────────────────┬───────────────────────┘
                  │ 委派調用
┌─────────────────▼───────────────────────┐
│   RemoteDockerService                   │
│  (Docker API 底層實現)                  │
└─────────────────┬───────────────────────┘
                  │ Docker Java API
┌─────────────────▼───────────────────────┐
│   Docker Desktop / Docker Daemon        │
│  (tcp://localhost:2375)                 │
└─────────────────────────────────────────┘
```

### 配置設定

#### MCP Server 配置
```properties
# Spring AI MCP Server 配置
spring.ai.mcp.server.enabled=true
spring.ai.mcp.server.stdio=false
spring.ai.mcp.server.name=docker-mcp-server
spring.ai.mcp.server.version=1.0.0
server.port=8080
```

#### Docker 連接配置
```properties
# Docker 連接配置
docker.host=tcp://localhost:2375
docker.tls.enabled=false
docker.timeout.connection=30
docker.timeout.response=300
docker.pool.max.connections=50
```

## 安裝與執行

### 環境需求
1. **Java 21** 或更高版本
2. **Maven 3.8+** 
3. **Docker Desktop** 並啟用 TCP 連接
   - 在 Docker Desktop > Settings > General > 勾選 "Expose daemon on tcp://localhost:2375 without TLS"

### 本地運行

#### 方式一：使用 Maven 直接運行
```powershell
# 編譯專案
mvn clean compile

# 執行測試
mvn test

# 運行應用程式（HTTP 模式，預設端口 8080）
mvn spring-boot:run
```

#### 方式二：打包後運行
```powershell
# 打包成 JAR 檔
mvn clean package

# 運行 JAR 檔
java -jar target\com-momo-ltsre-docker-1.0.0.jar
```

### Docker 容器化部署

```powershell
# 構建 Docker 映像檔
docker build -t docker-mcp-server:1.0.0 .

# 運行容器
docker run -d `
  --name docker-mcp-server `
  -p 8080:8080 `
  -e DOCKER_HOST=tcp://host.docker.internal:2375 `
  --add-host host.docker.internal:host-gateway `
  docker-mcp-server:1.0.0

# 查看容器日誌
docker logs -f docker-mcp-server

# 停止容器
docker stop docker-mcp-server

# 移除容器
docker rm docker-mcp-server
```

### 驗證運行狀態

應用程式啟動後，可以透過以下方式驗證：

#### 1. 檢查應用程式日誌

查看日誌確認服務已成功啟動，應該會看到類似以下訊息：

```
正在初始化遠端 Docker 客戶端...
遠端 Docker 客戶端初始化成功
正在註冊 Docker MCP 工具...
Started ComMomoLtsreDockerApplication in X.XXX seconds
```

#### 2. 驗證 MCP Server（HTTP 模式）

當 `spring.ai.mcp.server.stdio=false` 時（HTTP 模式），可以驗證：

```powershell
# 檢查 Spring Boot 應用程式端口是否開放
Test-NetConnection -ComputerName localhost -Port 8080

# 查看應用程式是否正常運行
# 注意：Spring AI MCP Server 的具體端點由框架自動配置
# 主要透過 MCP Client（如 Claude Desktop）連接使用
```

#### 3. 驗證 MCP Server（Stdio 模式）

當 `spring.ai.mcp.server.stdio=true` 時（Stdio 模式），應用程式會：
- 關閉 Web 伺服器（`spring.main.web-application-type=none`）
- 透過標準輸入/輸出與 MCP Client 通訊
- 主要透過配置在 MCP Client（如 Claude Desktop）中使用

**最佳驗證方式**：在 MCP Client 中成功連接並能夠調用 Docker 工具

## MCP Server 使用方式

### 連接 MCP Server

此 MCP Server 支援兩種模式：

#### 1. HTTP 模式（預設）
適合開發和測試，透過 HTTP 端點提供服務：

```json
{
  "mcpServers": {
    "docker-mcp-server": {
      "url": "http://localhost:8080/mcp"
    }
  }
}
```

#### 2. Stdio 模式
適合生產環境，透過標準輸入/輸出通訊：

修改 `application.properties`：
```properties
spring.ai.mcp.server.stdio=true
spring.main.web-application-type=none
```

然後在 MCP 客戶端配置：
```json
{
  "mcpServers": {
    "docker-mcp-server": {
      "command": "java",
      "args": ["-jar", "path/to/com-momo-ltsre-docker-1.0.0.jar"]
    }
  }
}
```

### 可用的 MCP 工具

所有工具都透過 `@Tool` 註解暴露，包含完整的描述和參數說明：

- **容器管理**: `listContainers`, `createContainer`, `runContainer`, `runContainerWithCommand`, `startContainer`, `stopContainer`, `removeContainer`, `getContainerLogs`
- **映像檔管理**: `listImages`, `pullImage`, `pushImage`, `buildImage`, `removeImage`
- **網路管理**: `listNetworks`, `createNetwork`, `removeNetwork`
- **磁碟區管理**: `listVolumes`, `createVolume`, `removeVolume`
- **系統資訊**: `getDockerVersion`

每個工具都返回結構化的 JSON 響應，便於 AI 模型理解和處理。

## 測試結果

專案包含完整的單元測試和整合測試：

### ✅ 測試覆蓋範圍
- Docker 連接和版本資訊驗證
- 映像檔管理（列出、拉取、推送、建構、移除）
- 容器完整生命週期管理（建立、運行、啟動、停止、移除）
- 容器自訂命令執行
- 容器日誌獲取功能
- 網路建立、列出和移除
- 磁碟區建立、列出和移除  
- 整合測試（多資源協同操作）
- 效能測試

### 執行測試
```powershell
# 執行所有測試
mvn test

# 執行特定測試類別
mvn test -Dtest=RemoteDockerServiceTest

# 查看測試報告
# 報告位於: target\surefire-reports\
```

## 配置說明

### Docker 連接配置

專案支援兩種 Docker 連接方式：

#### 1. TCP 連接（推薦用於本地開發）
```properties
docker.host=tcp://localhost:2375
docker.tls.enabled=false
```

**Docker Desktop 設定步驟**：
1. 開啟 Docker Desktop
2. 進入 Settings > General
3. 勾選 "Expose daemon on tcp://localhost:2375 without TLS"
4. 重啟 Docker Desktop

#### 2. TLS 加密連接（推薦用於生產環境）
```properties  
docker.host=tcp://localhost:2376
docker.tls.enabled=true
docker.cert.path=/path/to/certificates
```

#### 3. Docker 容器內連接宿主機 Docker
```properties
docker.host=tcp://host.docker.internal:2375
```

### 進階配置選項

```properties
# 連接超時（秒）
docker.timeout.connection=30

# 回應超時（秒）
docker.timeout.response=300

# HTTP 連接池最大連接數
docker.pool.max.connections=50

# MCP Server 名稱和版本
spring.ai.mcp.server.name=docker-mcp-server
spring.ai.mcp.server.version=1.0.0

# 應用程式端口
server.port=8080
```

### 日誌配置

日誌檔案位置：`/opt/dockerstdio/log/`（容器內）或專案根目錄下的 `logs/`（本地運行）

修改 `logback-spring.xml` 可調整日誌級別和輸出格式。

## 程式碼架構

### 核心類別說明

#### 1. ComMomoLtsreDockerApplication
Spring Boot 應用程式主入口點。

**主要職責**：
- 啟動 Spring Boot 應用程式
- 初始化日誌目錄

#### 2. McpServerConfig
MCP Server 配置類別，使用 Spring AI 的 ToolCallbackProvider。

**主要職責**：
- 註冊 Docker 工具到 MCP Server
- 將 `McpRemoteDockerService` 的方法暴露為 MCP 工具

**程式碼範例**：
```java
@Configuration
public class McpServerConfig {
    @Bean
    public ToolCallbackProvider dockerTools(McpRemoteDockerService service) {
        return MethodToolCallbackProvider.builder()
                .toolObjects(service)
                .build();
    }
}
```

#### 3. McpRemoteDockerService
MCP 工具提供者，透過 `@Tool` 註解暴露 Docker 管理功能。

**主要職責**：
- 提供 MCP 工具介面（使用 `@Tool` 和 `@ToolParam` 註解）
- 將請求委派給 `RemoteDockerService` 執行
- 將結果轉換為 JSON 格式返回給 AI 模型

**工具分類**：
- 容器管理工具（8 個）
- 映像檔管理工具（5 個）
- 網路管理工具（3 個）
- 磁碟區管理工具（3 個）
- 系統資訊工具（1 個）

#### 4. RemoteDockerService
Docker API 底層實現服務。

**主要職責**：
- 初始化和管理 Docker 客戶端連接
- 實現所有 Docker 操作的底層邏輯
- 處理 Docker API 的異常和錯誤

**核心方法分組**：
```java
@Service
@Slf4j
public class RemoteDockerService {
    // Docker 客戶端初始化
    @PostConstruct
    public void initializeDockerClient()
    
    // 容器管理
    public List<Container> listContainers(boolean showAll)
    public String createContainer(String imageName, String containerName)
    public String runContainer(...)
    public void startContainer(String containerIdOrName)
    public void stopContainer(String containerIdOrName)
    public void removeContainer(String containerIdOrName, boolean force)
    public String fetchContainerLogs(...)
    
    // 映像檔管理  
    public List<Image> listImages(boolean showDangling)
    public boolean pullImage(String imageName)
    public boolean pushImage(String imageName)
    public boolean buildImage(...)
    public void removeImage(String imageIdOrName, boolean force)
    
    // 網路管理
    public List<Network> listNetworks()
    public String createNetwork(String networkName, String driver)
    public void removeNetwork(String networkIdOrName)
    
    // 磁碟區管理
    public List<?> listVolumes()
    public String createVolume(...)
    public void removeVolume(String volumeName, boolean force)
    
    // 系統資訊
    public String getDockerVersion()
    public String getApiVersion()
}
```

### 資料流程

```
AI 模型請求
    ↓
MCP Client (HTTP/stdio)
    ↓
Spring AI MCP Server
    ↓
McpRemoteDockerService (@Tool 方法)
    ↓
RemoteDockerService (Docker API 調用)
    ↓
Docker Java Client
    ↓
Docker Desktop / Daemon
    ↓
執行結果
    ↓
JSON 格式返回
    ↓
AI 模型接收並處理
```

## 開發指南

### 新增 MCP 工具

如需新增自訂的 Docker 管理工具，請依照以下步驟：

#### 1. 在 RemoteDockerService 中實現底層邏輯
```java
/**
 * 獲取容器詳細資訊
 * @param containerIdOrName 容器 ID 或名稱
 * @return 容器詳細資訊物件
 */
public InspectContainerResponse inspectContainer(String containerIdOrName) {
    log.info("檢查容器資訊: {}", containerIdOrName);
    return dockerClient.inspectContainerCmd(containerIdOrName).exec();
}
```

#### 2. 在 McpRemoteDockerService 中暴露為 MCP 工具
```java
/**
 * 檢查容器詳細資訊
 * @param containerIdOrName 容器 ID 或名稱
 * @return JSON 格式的容器詳細資訊
 */
@Tool(description = "檢查並返回 Docker 容器的詳細資訊，包括配置、網路設定、掛載點等。")
public String inspectContainer(
    @ToolParam(description = "容器 ID 或名稱") String containerIdOrName) {
    try {
        InspectContainerResponse info = dockerService.inspectContainer(containerIdOrName);
        // 轉換為 Map 並返回 JSON
        return convertToJsonString(info);
    } catch (Exception e) {
        return createErrorResponse("檢查容器失敗: " + e.getMessage());
    }
}
```

#### 3. 工具將自動註冊到 MCP Server

Spring AI 會自動掃描 `@Tool` 註解的方法並註冊到 MCP Server。

### 錯誤處理最佳實踐

所有 MCP 工具方法都應遵循統一的錯誤處理模式：

```java
@Tool(description = "...")
public String someDockerOperation(...) {
    try {
        // 執行 Docker 操作
        Result result = dockerService.someOperation(...);
        
        // 成功時返回結構化響應
        Map<String, Object> response = new HashMap<>();
        response.put("success", true);
        response.put("data", result);
        return convertToJsonString(response);
        
    } catch (Exception e) {
        // 失敗時返回錯誤訊息
        log.error("操作失敗", e);
        return createErrorResponse("操作失敗: " + e.getMessage());
    }
}
```

### 單元測試編寫

為新功能編寫測試：

```java
@Test
@Order(順序)
public void testNewFeature() {
    // Given - 準備測試數據
    String containerName = "test-container";
    
    // When - 執行操作
    InspectContainerResponse info = dockerService.inspectContainer(containerName);
    
    // Then - 驗證結果
    assertNotNull(info);
    assertEquals(containerName, info.getName());
    log.info("測試通過: {}", info);
}
```

## 常見問題與故障排除

### 1. Docker 連接失敗

**問題**: 應用程式無法連接到 Docker

**解決方案**:
- 確認 Docker Desktop 正在運行
- 檢查是否已啟用 TCP 連接（Settings > General > "Expose daemon on tcp://localhost:2375 without TLS"）
- 驗證防火牆設定，確保端口 2375 未被封鎖
- 測試連接：`curl http://localhost:2375/version` 或 `Invoke-WebRequest -Uri http://localhost:2375/version`

### 2. 容器無法啟動

**問題**: 容器建立成功但無法啟動

**解決方案**:
- 檢查容器日誌：使用 `getContainerLogs` 工具
- 確認映像檔是否存在且完整
- 檢查端口映射是否衝突
- 驗證環境變數設定是否正確

### 3. 映像檔拉取緩慢

**問題**: 從 Docker Hub 拉取映像檔速度很慢

**解決方案**:
- 配置 Docker Hub 鏡像加速器
- 使用國內鏡像服務（如阿里雲、騰訊雲）
- 檢查網路連接狀態

### 4. MCP Server 無法連接

**問題**: AI 模型無法連接到 MCP Server

**解決方案**:
- 確認應用程式已啟動（檢查日誌輸出）
- HTTP 模式：驗證端口 8080 是否開放
- Stdio 模式：確認 JAR 檔路徑正確
- 檢查 MCP 客戶端配置是否正確

### 5. 容器內運行無法連接宿主機 Docker

**問題**: 在 Docker 容器內運行 MCP Server，無法連接到宿主機的 Docker

**解決方案**:
- 使用 `host.docker.internal` 作為 Docker 主機地址
- 確保容器配置了 `--add-host host.docker.internal:host-gateway`
- 檢查宿主機 Docker 是否暴露了 TCP 端口

### 取得更多幫助

- 查看應用程式日誌：`logs/spring.log`（本地）或 `docker logs docker-mcp-server`（容器）
- 查看 Docker Desktop 日誌
- 檢查專案測試用例作為使用範例

## 專案演進

### 目前版本功能
- ✅ 完整的 Docker 管理功能實現
- ✅ Spring AI MCP Server 整合
- ✅ HTTP 和 stdio 雙模式支援
- ✅ Docker 容器化部署
- ✅ 完整的單元測試覆蓋

### 未來計劃
- 🔄 支援 Docker Swarm 叢集管理
- 🔄 支援 Docker Compose 檔案解析和部署
- 🔄 容器效能監控和資源使用統計
- 🔄 映像檔安全掃描整合
- 🔄 多 Docker 主機管理
- 🔄 Kubernetes 整合支援

## 貢獻指南

歡迎提交 Issue 和 Pull Request 來改進這個專案。

**開發流程**：
1. Fork 專案
2. 建立功能分支 (`git checkout -b feature/AmazingFeature`)
3. 提交變更 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 開啟 Pull Request

**程式碼規範**：
- 遵循 Java 編碼規範
- 所有公開方法必須包含 JavaDoc 註解
- 新功能必須包含對應的單元測試
- 提交前執行 `mvn test` 確保所有測試通過

---

**專案版本**: 1.0.0  
**最後更新**: 2025 年 11 月