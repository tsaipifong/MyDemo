package com.momo.ltsre.docker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.io.File;

/**
 * Docker Stdio 應用程式主類別
 * 使用 Spring Boot 啟動應用程式
 */
@SpringBootApplication
public class ComMomoLtsreDockerApplication {

	/**
	 * 應用程式主入口點
	 * @param args 命令列參數
	 */
	public static void main(String[] args) {
		// 創建日誌檔案目錄
		createLogDirectory();
		
		SpringApplication.run(ComMomoLtsreDockerApplication.class, args);
	}
	
	/**
	 * 創建日誌檔案目錄
	 * 確保日誌檔案可以正確寫入
	 */
	private static void createLogDirectory() {
		File logDir = new File("/opt/dockerstdio/log");
		if (!logDir.exists()) {
			logDir.mkdirs();
			System.out.println("已創建日誌目錄: " + logDir.getAbsolutePath());
		}
	}
}