package com.momo.ltsre.docker.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.tool.method.MethodToolCallbackProvider;
import org.springframework.ai.tool.ToolCallbackProvider;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.momo.ltsre.docker.service.McpRemoteDockerService;

/**
 * MCP Server 配置類別
 * 使用 Spring AI 的 ToolCallbackProvider 來暴露 Docker 工具給 MCP 客戶端
 * 
 * 根據 Spring AI 官方文檔的建議模式實現
 */
@Configuration
@Slf4j
public class McpServerConfig {

    /**
     * 建立 ToolCallbackProvider Bean 來暴露 Docker 工具
     * @param mcpRemoteDockerService Docker 服務實例
     * @return ToolCallbackProvider 實例
     */
    @Bean
    public ToolCallbackProvider dockerTools(McpRemoteDockerService mcpRemoteDockerService) {
        log.info("正在註冊 Docker MCP 工具...");
        return MethodToolCallbackProvider.builder()
                .toolObjects(mcpRemoteDockerService)
                .build();
    }
}