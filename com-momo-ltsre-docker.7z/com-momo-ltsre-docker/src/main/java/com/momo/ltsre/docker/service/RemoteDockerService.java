package com.momo.ltsre.docker.service;

import com.github.dockerjava.api.DockerClient;
import com.github.dockerjava.api.command.CreateContainerResponse;
import com.github.dockerjava.api.command.PullImageResultCallback;
import com.github.dockerjava.api.model.*;
import com.github.dockerjava.api.exception.NotFoundException;
import com.github.dockerjava.core.DefaultDockerClientConfig;
import com.github.dockerjava.core.DockerClientConfig;
import com.github.dockerjava.core.DockerClientImpl;
import com.github.dockerjava.httpclient5.ApacheDockerHttpClient;
import com.github.dockerjava.transport.DockerHttpClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import java.io.IOException;
import java.time.Duration;
import java.util.List;
import java.util.Map;

/**
 * 遠端 Docker 服務類別
 * 提供遠端 Docker 主機的容器管理功能
 */
@Service
@Slf4j
public class RemoteDockerService {
    
    /** 遠端 Docker 客戶端實例 */
    private DockerClient dockerClient;
    
    /** Docker 主機地址 */
    @Value("${docker.host:tcp://localhost:2376}")
    private String dockerHost;
    
    /** 是否啟用 TLS */
    @Value("${docker.tls.enabled:false}")
    private boolean tlsEnabled;
    
    /** 證書路徑（當啟用 TLS 時使用） */
    @Value("${docker.cert.path:}")
    private String certPath;
    
    /** 連接超時時間（秒） */
    @Value("${docker.timeout.connection:30}")
    private int connectionTimeout;
    
    /** 響應超時時間（秒） */
    @Value("${docker.timeout.response:300}")
    private int responseTimeout;
    
    /** 最大連接數 */
    @Value("${docker.pool.max.connections:50}")
    private int maxConnections;
    
    /**
     * 初始化 Docker 客戶端
     */
    @PostConstruct
    public void initializeDockerClient() {
        try {
            log.info("正在初始化遠端 Docker 客戶端...");
            log.info("Docker 主機: {}", dockerHost);
            log.info("TLS 啟用: {}", tlsEnabled);
            
            // 建立 Docker 配置
            // 注意：不需要事先設定 API 版本，Docker Java 會自動協商最佳版本
            DefaultDockerClientConfig.Builder configBuilder = 
                DefaultDockerClientConfig.createDefaultConfigBuilder()
                    .withDockerHost(dockerHost)
                    .withDockerTlsVerify(tlsEnabled);
            
            // 如果啟用 TLS 且提供了證書路徑
            if (tlsEnabled && !certPath.isEmpty()) {
                log.info("使用 TLS 證書路徑: {}", certPath);
                configBuilder.withDockerCertPath(certPath);
            }
            
            DockerClientConfig config = configBuilder.build();
            
            // 建立 HTTP 客戶端
            DockerHttpClient httpClient = new ApacheDockerHttpClient.Builder()
                    .dockerHost(config.getDockerHost())
                    .sslConfig(config.getSSLConfig())
                    .maxConnections(maxConnections)
                    .connectionTimeout(Duration.ofSeconds(connectionTimeout))
                    .responseTimeout(Duration.ofSeconds(responseTimeout))
                    .build();
            
            // 初始化 Docker 客戶端
            this.dockerClient = DockerClientImpl.getInstance(config, httpClient);
            
            // 測試連接並獲取版本資訊
            testConnectionAndGetVersion();
            
            log.info("遠端 Docker 客戶端初始化成功");
            
        } catch (Exception e) {
            log.error("初始化遠端 Docker 客戶端失敗", e);
            throw new RuntimeException("無法連接到遠端 Docker 主機: " + dockerHost, e);
        }
    }
    
    /**
     * 測試連接並獲取 Docker 版本資訊
     */
    private void testConnectionAndGetVersion() {
        try {
            // 獲取 Docker 資訊
            Info dockerInfo = dockerClient.infoCmd().exec();
            
            log.info("=== Docker 主機資訊 ===");
            log.info("Docker 版本: {}", dockerInfo.getServerVersion());
            log.info("主機名稱: {}", dockerInfo.getName());
            log.info("作業系統: {}", dockerInfo.getOperatingSystem());
            log.info("系統架構: {}", dockerInfo.getArchitecture());
            log.info("總容器數: {}", dockerInfo.getContainers());
            log.info("運行中容器數: {}", dockerInfo.getContainersRunning());
            log.info("總映像檔數: {}", dockerInfo.getImages());
            
            // 獲取並記錄 API 版本
            logDockerVersionInfo();
            
            log.info("========================");
            
        } catch (Exception e) {
            log.error("測試 Docker 連接失敗", e);
            throw new RuntimeException("Docker 連接測試失敗", e);
        }
    }
    
    /**
     * 獲取 Docker 版本資訊
     * @return Docker 版本字串
     */
    public String getDockerVersion() {
        try {
            return dockerClient.versionCmd().exec().getVersion();
        } catch (Exception e) {
            log.error("獲取 Docker 版本失敗", e);
            return "未知版本";
        }
    }
    
    /**
     * 獲取 Docker API 版本
     * @return API 版本字串
     */
    public String getApiVersion() {
        try {
            return dockerClient.versionCmd().exec().getApiVersion();
        } catch (Exception e) {
            log.error("獲取 Docker API 版本失敗", e);
            return "未知 API 版本";
        }
    }
    
    /**
     * 獲取完整的 Docker 資訊（包含 API 版本）
     */
    private void logDockerVersionInfo() {
        try {
            var version = dockerClient.versionCmd().exec();
            log.info("API 版本: {}", version.getApiVersion());
        } catch (Exception e) {
            log.warn("無法獲取 Docker API 版本: {}", e.getMessage());
        }
    }
    
    /**
     * 建立容器
     * @param imageName 映像檔名稱
     * @param containerName 容器名稱
     * @return 容器 ID
     */
    public String createContainer(String imageName, String containerName) {
        try {
            // 檢查映像檔是否存在，不存在則拉取
            ensureImageExists(imageName);
            
            // 建立容器
            CreateContainerResponse container = dockerClient.createContainerCmd(imageName)
                    .withName(containerName)
                    .exec();
            
            log.info("容器建立成功 - ID: {}, 名稱: {}", container.getId(), containerName);
            
            return container.getId();
            
        } catch (Exception e) {
            log.error("建立容器失敗 - 映像檔: {}, 容器名稱: {}", imageName, containerName, e);
            throw new RuntimeException("容器建立失敗", e);
        }
    }
    
    /**
     * 確保映像檔存在，不存在則拉取
     * @param imageName 映像檔名稱
     */
    private void ensureImageExists(String imageName) {
        try {
            // 嘗試檢查映像檔是否存在
            dockerClient.inspectImageCmd(imageName).exec();
            log.debug("映像檔已存在: {}", imageName);
            
        } catch (NotFoundException e) {
            // 映像檔不存在，進行拉取
            log.info("映像檔不存在，正在拉取: {}", imageName);
            
            try {
                dockerClient.pullImageCmd(imageName)
                        .exec(new com.github.dockerjava.api.async.ResultCallback.Adapter<>())
                        .awaitCompletion();
                        
                log.info("映像檔拉取完成: {}", imageName);
                
            } catch (InterruptedException pullException) {
                Thread.currentThread().interrupt();
                throw new RuntimeException("映像檔拉取被中斷: " + imageName, pullException);
            }
        }
    }
    
    // ================================
    // 容器管理功能 (Container Operations)
    // ================================
    
    /**
     * 列出所有容器
     * @param showAll 是否顯示所有容器（包含已停止的）
     * @return 容器清單
     */
    public List<Container> listContainers(boolean showAll) {
        try {
            log.debug("正在列出容器，顯示所有: {}", showAll);
            List<Container> containers = dockerClient.listContainersCmd()
                    .withShowAll(showAll)
                    .exec();
            
            log.info("找到 {} 個容器", containers.size());
            return containers;
            
        } catch (Exception e) {
            log.error("列出容器失敗", e);
            throw new RuntimeException("無法列出容器", e);
        }
    }
    
    /**
     * 運行容器（建立並啟動）
     * @param imageName 映像檔名稱
     * @param containerName 容器名稱
     * @param ports 端口映射 (主機端口:容器端口)
     * @param envVars 環境變數
     * @return 容器 ID
     */
    public String runContainer(String imageName, String containerName, Map<String, String> ports, Map<String, String> envVars) {
        try {
            // 確保映像檔存在
            ensureImageExists(imageName);
            
            // 建立容器命令
            var createCmd = dockerClient.createContainerCmd(imageName)
                    .withName(containerName);
            
            // 設定端口映射
            if (ports != null && !ports.isEmpty()) {
                var portBindings = new Ports();
                var exposedPorts = new ExposedPort[ports.size()];
                int i = 0;
                
                for (Map.Entry<String, String> entry : ports.entrySet()) {
                    ExposedPort containerPort = ExposedPort.tcp(Integer.parseInt(entry.getValue()));
                    exposedPorts[i++] = containerPort;
                    portBindings.bind(containerPort, Ports.Binding.bindPort(Integer.parseInt(entry.getKey())));
                }
                
                createCmd.withExposedPorts(exposedPorts)
                        .withHostConfig(HostConfig.newHostConfig().withPortBindings(portBindings));
            }
            
            // 設定環境變數
            if (envVars != null && !envVars.isEmpty()) {
                String[] envArray = envVars.entrySet().stream()
                        .map(entry -> entry.getKey() + "=" + entry.getValue())
                        .toArray(String[]::new);
                createCmd.withEnv(envArray);
            }
            
            // 建立容器
            CreateContainerResponse container = createCmd.exec();
            String containerId = container.getId();
            
            // 啟動容器
            dockerClient.startContainerCmd(containerId).exec();
            
            log.info("容器運行成功 - ID: {}, 名稱: {}", containerId, containerName);
            return containerId;
            
        } catch (Exception e) {
            log.error("運行容器失敗 - 映像檔: {}, 容器名稱: {}", imageName, containerName, e);
            throw new RuntimeException("容器運行失敗", e);
        }
    }
    
    /**
     * 運行容器，支援自定義命令（建立並啟動）
     * @param imageName 映像檔名稱
     * @param containerName 容器名稱
     * @param cmd 要執行的命令數組
     * @param ports 端口映射 (主機端口:容器端口)
     * @param envVars 環境變數
     * @return 容器 ID
     */
    public String runContainerWithCommand(String imageName, String containerName, String[] cmd, 
                                        Map<String, String> ports, Map<String, String> envVars) {
        try {
            // 確保映像檔存在
            ensureImageExists(imageName);
            
            // 建立容器命令
            var createCmd = dockerClient.createContainerCmd(imageName)
                    .withName(containerName);
            
            // 設定自定義命令
            if (cmd != null && cmd.length > 0) {
                createCmd.withCmd(cmd);
            }
            
            // 設定端口映射
            if (ports != null && !ports.isEmpty()) {
                var portBindings = new Ports();
                var exposedPorts = new ExposedPort[ports.size()];
                int i = 0;
                
                for (Map.Entry<String, String> entry : ports.entrySet()) {
                    ExposedPort containerPort = ExposedPort.tcp(Integer.parseInt(entry.getValue()));
                    exposedPorts[i++] = containerPort;
                    portBindings.bind(containerPort, Ports.Binding.bindPort(Integer.parseInt(entry.getKey())));
                }
                
                createCmd.withExposedPorts(exposedPorts)
                        .withHostConfig(HostConfig.newHostConfig().withPortBindings(portBindings));
            }
            
            // 設定環境變數
            if (envVars != null && !envVars.isEmpty()) {
                String[] envArray = envVars.entrySet().stream()
                        .map(entry -> entry.getKey() + "=" + entry.getValue())
                        .toArray(String[]::new);
                createCmd.withEnv(envArray);
            }
            
            // 建立容器
            CreateContainerResponse container = createCmd.exec();
            String containerId = container.getId();
            
            // 啟動容器
            dockerClient.startContainerCmd(containerId).exec();
            
            log.info("容器運行成功（自定義命令）- ID: {}, 名稱: {}, 命令: {}", 
                    containerId, containerName, cmd != null ? String.join(" ", cmd) : "default");
            return containerId;
            
        } catch (Exception e) {
            log.error("運行容器失敗（自定義命令） - 映像檔: {}, 容器名稱: {}, 命令: {}", 
                    imageName, containerName, cmd != null ? String.join(" ", cmd) : "default", e);
            throw new RuntimeException("容器運行失敗", e);
        }
    }
    
    /**
     * 重新建立容器（刪除現有容器並重新建立）
     * @param containerName 容器名稱
     * @param imageName 映像檔名稱
     * @param ports 端口映射
     * @param envVars 環境變數
     * @return 新容器 ID
     */
    public String recreateContainer(String containerName, String imageName, Map<String, String> ports, Map<String, String> envVars) {
        try {
            // 嘗試停止並移除現有容器
            try {
                stopContainer(containerName);
            } catch (Exception e) {
                log.debug("停止容器失敗（容器可能已停止）: {}", e.getMessage());
            }
            
            try {
                removeContainer(containerName, true);
                log.info("已移除現有容器: {}", containerName);
            } catch (Exception e) {
                log.debug("容器 {} 不存在或已移除: {}", containerName, e.getMessage());
            }
            
            // 建立新容器
            return runContainer(imageName, containerName, ports, envVars);
            
        } catch (Exception e) {
            log.error("重新建立容器失敗 - 容器名稱: {}", containerName, e);
            throw new RuntimeException("重新建立容器失敗", e);
        }
    }
    
    /**
     * 啟動容器
     * @param containerIdOrName 容器 ID 或名稱
     */
    public void startContainer(String containerIdOrName) {
        try {
            dockerClient.startContainerCmd(containerIdOrName).exec();
            log.info("容器啟動成功: {}", containerIdOrName);
            
        } catch (Exception e) {
            log.error("啟動容器失敗: {}", containerIdOrName, e);
            throw new RuntimeException("容器啟動失敗", e);
        }
    }
    
    /**
     * 停止容器
     * @param containerIdOrName 容器 ID 或名稱
     */
    public void stopContainer(String containerIdOrName) {
        try {
            dockerClient.stopContainerCmd(containerIdOrName)
                    .withTimeout(30) // 30秒超時
                    .exec();
            log.info("容器停止成功: {}", containerIdOrName);
            
        } catch (Exception e) {
            log.error("停止容器失敗: {}", containerIdOrName, e);
            throw new RuntimeException("容器停止失敗", e);
        }
    }
    
    /**
     * 移除容器
     * @param containerIdOrName 容器 ID 或名稱
     * @param force 是否強制移除（包含運行中的容器）
     */
    public void removeContainer(String containerIdOrName, boolean force) {
        try {
            dockerClient.removeContainerCmd(containerIdOrName)
                    .withForce(force)
                    .exec();
            log.info("容器移除成功: {}", containerIdOrName);
            
        } catch (Exception e) {
            log.error("移除容器失敗: {}", containerIdOrName, e);
            throw new RuntimeException("容器移除失敗", e);
        }
    }
    
    /**
     * 獲取容器日誌
     * @param containerIdOrName 容器 ID 或名稱
     * @param tail 顯示最後幾行日誌
     * @param follow 是否持續追蹤日誌
     * @return 日誌內容
     */
    public String fetchContainerLogs(String containerIdOrName, int tail, boolean follow) {
        try {
            var logCmd = dockerClient.logContainerCmd(containerIdOrName)
                    .withStdOut(true)
                    .withStdErr(true)
                    .withTimestamps(true);
            
            if (tail > 0) {
                logCmd.withTail(tail);
            }
            
            if (follow) {
                logCmd.withFollowStream(true);
            }
            
            // 使用同步方式獲取日誌
            var outputStream = new java.io.ByteArrayOutputStream();
            logCmd.exec(new com.github.dockerjava.api.async.ResultCallback.Adapter<Frame>() {
                @Override
                public void onNext(Frame frame) {
                    try {
                        outputStream.write(frame.getPayload());
                    } catch (IOException e) {
                        log.error("寫入日誌失敗", e);
                    }
                }
            }).awaitCompletion();
            
            String logs = outputStream.toString(java.nio.charset.StandardCharsets.UTF_8);
            log.debug("獲取容器 {} 的日誌成功，長度: {}", containerIdOrName, logs.length());
            
            return logs;
            
        } catch (Exception e) {
            log.error("獲取容器日誌失敗: {}", containerIdOrName, e);
            throw new RuntimeException("獲取容器日誌失敗", e);
        }
    }

    // ================================
    // 映像檔管理功能 (Image Operations)  
    // ================================
    
    /**
     * 列出所有映像檔
     * @param showDangling 是否顯示懸掛映像檔
     * @return 映像檔清單
     */
    public List<Image> listImages(boolean showDangling) {
        try {
            log.debug("正在列出映像檔，顯示懸掛映像檔: {}", showDangling);
            
            var listCmd = dockerClient.listImagesCmd();
            if (showDangling) {
                listCmd.withDanglingFilter(true);
            }
            
            List<Image> images = listCmd.exec();
            log.info("找到 {} 個映像檔", images.size());
            
            return images;
            
        } catch (Exception e) {
            log.error("列出映像檔失敗", e);
            throw new RuntimeException("無法列出映像檔", e);
        }
    }
    
    /**
     * 拉取映像檔
     * @param imageName 映像檔名稱（包含標籤）
     * @return 是否拉取成功
     */
    public boolean pullImage(String imageName) {
        try {
            log.info("開始拉取映像檔: {}", imageName);
            
            dockerClient.pullImageCmd(imageName)
                    .exec(new PullImageResultCallback())
                    .awaitCompletion();
            
            log.info("映像檔拉取成功: {}", imageName);
            return true;
            
        } catch (Exception e) {
            log.error("拉取映像檔失敗: {}", imageName, e);
            throw new RuntimeException("映像檔拉取失敗", e);
        }
    }
    
    /**
     * 推送映像檔
     * @param imageName 映像檔名稱（包含標籤）
     * @return 是否推送成功
     */
    public boolean pushImage(String imageName) {
        try {
            log.info("開始推送映像檔: {}", imageName);
            
            dockerClient.pushImageCmd(imageName)
                    .exec(new com.github.dockerjava.api.async.ResultCallback.Adapter<>())
                    .awaitCompletion();
            
            log.info("映像檔推送成功: {}", imageName);
            return true;
            
        } catch (Exception e) {
            log.error("推送映像檔失敗: {}", imageName, e);
            throw new RuntimeException("映像檔推送失敗", e);
        }
    }
    
    /**
     * 建構映像檔
     * @param dockerfilePath Dockerfile 路徑
     * @param imageName 映像檔名稱和標籤
     * @param buildContext 建構上下文目錄
     * @return 是否建構成功
     */
    public boolean buildImage(String dockerfilePath, String imageName, String buildContext) {
        try {
            log.info("開始建構映像檔: {} from {}", imageName, dockerfilePath);
            
            var buildContextFile = new java.io.File(buildContext);
            var dockerFile = new java.io.File(dockerfilePath);
            
            dockerClient.buildImageCmd()
                    .withBaseDirectory(buildContextFile)
                    .withDockerfile(dockerFile)
                    .withTags(java.util.Set.of(imageName))
                    .exec(new com.github.dockerjava.api.async.ResultCallback.Adapter<>())
                    .awaitCompletion();
            
            log.info("映像檔建構成功: {}", imageName);
            return true;
            
        } catch (Exception e) {
            log.error("建構映像檔失敗: {}", imageName, e);
            throw new RuntimeException("映像檔建構失敗", e);
        }
    }
    
    /**
     * 移除映像檔
     * @param imageIdOrName 映像檔 ID 或名稱
     * @param force 是否強制移除
     */
    public void removeImage(String imageIdOrName, boolean force) {
        try {
            dockerClient.removeImageCmd(imageIdOrName)
                    .withForce(force)
                    .exec();
            log.info("映像檔移除成功: {}", imageIdOrName);
            
        } catch (Exception e) {
            log.error("移除映像檔失敗: {}", imageIdOrName, e);
            throw new RuntimeException("映像檔移除失敗", e);
        }
    }

    // ================================
    // 網路管理功能 (Network Operations)
    // ================================
    
    /**
     * 列出所有網路
     * @return 網路清單
     */
    public List<Network> listNetworks() {
        try {
            log.debug("正在列出網路");
            List<Network> networks = dockerClient.listNetworksCmd().exec();
            log.info("找到 {} 個網路", networks.size());
            
            return networks;
            
        } catch (Exception e) {
            log.error("列出網路失敗", e);
            throw new RuntimeException("無法列出網路", e);
        }
    }
    
    /**
     * 建立網路
     * @param networkName 網路名稱
     * @param driver 網路驅動程式（bridge, overlay, host, none）
     * @return 網路 ID
     */
    public String createNetwork(String networkName, String driver) {
        try {
            log.info("建立網路: {} (驅動程式: {})", networkName, driver);
            
            var createCmd = dockerClient.createNetworkCmd()
                    .withName(networkName);
                    
            if (driver != null && !driver.isEmpty()) {
                createCmd.withDriver(driver);
            }
            
            var response = createCmd.exec();
            String networkId = response.getId();
            
            log.info("網路建立成功 - ID: {}, 名稱: {}", networkId, networkName);
            return networkId;
            
        } catch (Exception e) {
            log.error("建立網路失敗: {}", networkName, e);
            throw new RuntimeException("網路建立失敗", e);
        }
    }
    
    /**
     * 移除網路
     * @param networkIdOrName 網路 ID 或名稱
     */
    public void removeNetwork(String networkIdOrName) {
        try {
            dockerClient.removeNetworkCmd(networkIdOrName).exec();
            log.info("網路移除成功: {}", networkIdOrName);
            
        } catch (Exception e) {
            log.error("移除網路失敗: {}", networkIdOrName, e);
            throw new RuntimeException("網路移除失敗", e);
        }
    }

    // ================================
    // 磁碟區管理功能 (Volume Operations)
    // ================================
    
    /**
     * 列出所有磁碟區
     * @return 磁碟區清單
     */
    public java.util.List<?> listVolumes() {
        try {
            log.debug("正在列出磁碟區");
            var response = dockerClient.listVolumesCmd().exec();
            var volumes = response.getVolumes();
            log.info("找到 {} 個磁碟區", volumes.size());
            
            return volumes;
            
        } catch (Exception e) {
            log.error("列出磁碟區失敗", e);
            throw new RuntimeException("無法列出磁碟區", e);
        }
    }
    
    /**
     * 建立磁碟區
     * @param volumeName 磁碟區名稱
     * @param driver 磁碟區驅動程式
     * @param driverOpts 驅動程式選項
     * @return 磁碟區名稱
     */
    public String createVolume(String volumeName, String driver, Map<String, String> driverOpts) {
        try {
            log.info("建立磁碟區: {} (驅動程式: {})", volumeName, driver);
            
            var createCmd = dockerClient.createVolumeCmd()
                    .withName(volumeName);
                    
            if (driver != null && !driver.isEmpty()) {
                createCmd.withDriver(driver);
            }
            
            if (driverOpts != null && !driverOpts.isEmpty()) {
                createCmd.withDriverOpts(driverOpts);
            }
            
            var response = createCmd.exec();
            String createdVolumeName = response.getName();
            
            log.info("磁碟區建立成功: {}", createdVolumeName);
            return createdVolumeName;
            
        } catch (Exception e) {
            log.error("建立磁碟區失敗: {}", volumeName, e);
            throw new RuntimeException("磁碟區建立失敗", e);
        }
    }
    
    /**
     * 移除磁碟區
     * @param volumeName 磁碟區名稱
     * @param force 是否強制移除
     */
    public void removeVolume(String volumeName, boolean force) {
        try {
            var removeCmd = dockerClient.removeVolumeCmd(volumeName);
            // 注意：docker-java 可能不支援 withForce 方法，這裡先忽略 force 參數
            removeCmd.exec();
            log.info("磁碟區移除成功: {}", volumeName);
            
        } catch (Exception e) {
            log.error("移除磁碟區失敗: {}", volumeName, e);
            throw new RuntimeException("磁碟區移除失敗", e);
        }
    }

    /**
     * 關閉 Docker 客戶端
     */
    @PreDestroy
    public void closeDockerClient() {
        if (dockerClient != null) {
            try {
                dockerClient.close();
                log.info("Docker 客戶端已關閉");
            } catch (IOException e) {
                log.warn("關閉 Docker 客戶端時發生錯誤", e);
            }
        }
    }
}