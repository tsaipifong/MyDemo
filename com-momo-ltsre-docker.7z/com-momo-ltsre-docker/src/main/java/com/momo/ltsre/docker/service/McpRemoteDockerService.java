package com.momo.ltsre.docker.service;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.github.dockerjava.api.model.Container;
import com.github.dockerjava.api.model.Image;
import com.github.dockerjava.api.model.Network;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * MCP Docker 服務類別
 * 提供 Model Context Protocol 介面，委派給 RemoteDockerService 執行實際的 Docker 操作
 * 
 * 這個類別作為 MCP Server 的工具提供者，將所有 Docker 管理功能透過 MCP 協議暴露給 AI 模型
 */
@Service
@Slf4j
public class McpRemoteDockerService {

    /** 委派的 Docker 服務實例 */
    @Autowired
    private RemoteDockerService dockerService;

    // ================================
    // 容器管理 MCP Tools
    // ================================

    /**
     * 列出容器
     * @param showAll 是否顯示所有容器（包含已停止的）
     * @return 容器資訊的 JSON 字串
     */
    @Tool(description = "列出 Docker 容器。此工具用於查看系統中所有 Docker 容器的狀態，包括運行中、停止的容器。返回容器的詳細資訊如 ID、名稱、映像檔、狀態、端口映射等。適用於監控和管理 Docker 環境。")
    public String listContainers(@ToolParam(description = "是否顯示所有容器，包含已停止的容器。設為 true 會顯示所有容器（運行中和已停止），設為 false 只顯示運行中的容器") boolean showAll) {
        try {
            log.info("MCP: 列出容器，顯示所有: {}", showAll);
            List<Container> containers = dockerService.listContainers(showAll);
            
            // 轉換為簡化的容器資訊
            List<Map<String, Object>> containerInfos = containers.stream()
                    .map(this::convertContainerToMap)
                    .collect(Collectors.toList());
            
            Map<String, Object> result = new HashMap<>();
            result.put("success", true);
            result.put("count", containerInfos.size());
            result.put("containers", containerInfos);
            
            log.info("MCP: 成功列出 {} 個容器", containerInfos.size());
            return convertToJsonString(result);
            
        } catch (Exception e) {
            log.error("MCP: 列出容器失敗", e);
            return createErrorResponse("列出容器失敗: " + e.getMessage());
        }
    }

    /**
     * 建立容器
     * @param imageName 映像檔名稱
     * @param containerName 容器名稱
     * @return 操作結果的 JSON 字串
     */
    @Tool(description = "建立新的 Docker 容器。此工具從指定的映像檔建立一個新容器，但不會自動啟動它。建立完成後需要使用 startContainer 工具來啟動容器。適用於需要先建立容器再進行其他配置的情況。")
    public String createContainer(@ToolParam(description = "Docker 映像檔名稱，可以是本地映像檔或 Docker Hub 上的映像檔。格式如：nginx、nginx:latest、ubuntu:20.04") String imageName, 
                                 @ToolParam(description = "要建立的容器名稱，必須是唯一的。建議使用有意義的名稱方便管理，如：web-server、database-prod") String containerName) {
        try {
            log.info("MCP: 建立容器 - 映像檔: {}, 名稱: {}", imageName, containerName);
            String containerId = dockerService.createContainer(imageName, containerName);
            
            Map<String, Object> result = new HashMap<>();
            result.put("success", true);
            result.put("containerId", containerId);
            result.put("containerName", containerName);
            result.put("imageName", imageName);
            result.put("message", "容器建立成功");
            
            log.info("MCP: 容器建立成功 - ID: {}", containerId);
            return convertToJsonString(result);
            
        } catch (Exception e) {
            log.error("MCP: 建立容器失敗", e);
            return createErrorResponse("建立容器失敗: " + e.getMessage());
        }
    }

    /**
     * 運行容器（建立並啟動）
     * @param imageName 映像檔名稱
     * @param containerName 容器名稱
     * @param portsJson 端口映射的 JSON 字串（格式：{"hostPort":"containerPort"}）
     * @param envVarsJson 環境變數的 JSON 字串（格式：{"key":"value"}）
     * @return 操作結果的 JSON 字串
     */
    @Tool(description = "運行 Docker 容器（一次完成建立和啟動）。此工具會自動建立容器並立即啟動，支援端口映射和環境變數配置。這是最常用的容器部署方法，適合快速啟動服務。")
    public String runContainer(@ToolParam(description = "Docker 映像檔名稱，格式如：nginx、redis:alpine、mysql:8.0") String imageName,
                              @ToolParam(description = "容器名稱，必須唯一，建議使用描述性名稱") String containerName,
                              @ToolParam(description = "端口映射的 JSON 字串，格式：{\"主機端口\":\"容器端口\"}，如：{\"8080\":\"80\",\"3306\":\"3306\"}。空字串或 {} 表示不映射端口") String portsJson,
                              @ToolParam(description = "環境變數的 JSON 字串，格式：{\"變數名\":\"值\"}，如：{\"MYSQL_ROOT_PASSWORD\":\"password\"}。空字串或 {} 表示無環境變數") String envVarsJson) {
        try {
            log.info("MCP: 運行容器 - 映像檔: {}, 名稱: {}", imageName, containerName);
            
            Map<String, String> ports = parseJsonToMap(portsJson);
            Map<String, String> envVars = parseJsonToMap(envVarsJson);
            
            String containerId = dockerService.runContainer(imageName, containerName, ports, envVars);
            
            Map<String, Object> result = new HashMap<>();
            result.put("success", true);
            result.put("containerId", containerId);
            result.put("containerName", containerName);
            result.put("imageName", imageName);
            result.put("ports", ports);
            result.put("envVars", envVars);
            result.put("message", "容器運行成功");
            
            log.info("MCP: 容器運行成功 - ID: {}", containerId);
            return convertToJsonString(result);
            
        } catch (Exception e) {
            log.error("MCP: 運行容器失敗", e);
            return createErrorResponse("運行容器失敗: " + e.getMessage());
        }
    }

    /**
     * 運行容器，支援自定義命令
     * @param imageName 映像檔名稱
     * @param containerName 容器名稱
     * @param command 要執行的命令（空格分隔）
     * @param portsJson 端口映射的 JSON 字串
     * @param envVarsJson 環境變數的 JSON 字串
     * @return 操作結果的 JSON 字串
     */
    @Tool(description = "運行 Docker 容器並執行自定義命令。此工具可以覆蓋映像檔的預設命令，執行指定的命令。適用於需要執行特殊任務、一次性腳本或調試的情況。")
    public String runContainerWithCommand(@ToolParam(description = "Docker 映像檔名稱") String imageName,
                                         @ToolParam(description = "容器名稱，必須唯一") String containerName,
                                         @ToolParam(description = "要執行的自定義命令，以空格分隔參數。如：'python app.py'、'sh -c \"echo hello\"'。空字串表示使用映像檔預設命令") String command,
                                         @ToolParam(description = "端口映射 JSON，格式：{\"主機端口\":\"容器端口\"}") String portsJson,
                                         @ToolParam(description = "環境變數 JSON，格式：{\"變數名\":\"值\"}") String envVarsJson) {
        try {
            log.info("MCP: 運行容器（自定義命令）- 映像檔: {}, 名稱: {}, 命令: {}", imageName, containerName, command);
            
            String[] cmd = command != null && !command.trim().isEmpty() ? command.trim().split("\\s+") : null;
            Map<String, String> ports = parseJsonToMap(portsJson);
            Map<String, String> envVars = parseJsonToMap(envVarsJson);
            
            String containerId = dockerService.runContainerWithCommand(imageName, containerName, cmd, ports, envVars);
            
            Map<String, Object> result = new HashMap<>();
            result.put("success", true);
            result.put("containerId", containerId);
            result.put("containerName", containerName);
            result.put("imageName", imageName);
            result.put("command", command);
            result.put("ports", ports);
            result.put("envVars", envVars);
            result.put("message", "容器運行成功（自定義命令）");
            
            log.info("MCP: 容器運行成功（自定義命令）- ID: {}", containerId);
            return convertToJsonString(result);
            
        } catch (Exception e) {
            log.error("MCP: 運行容器失敗（自定義命令）", e);
            return createErrorResponse("運行容器失敗（自定義命令）: " + e.getMessage());
        }
    }

    /**
     * 啟動容器
     * @param containerIdOrName 容器 ID 或名稱
     * @return 操作結果的 JSON 字串
     */
    @Tool(description = "啟動已停止的 Docker 容器。此工具用於重新啟動之前建立但已停止的容器，保留容器的所有配置和數據。比重新建立容器更快速且保持狀態一致。")
    public String startContainer(@ToolParam(description = "容器的 ID 或名稱。可以是完整的容器 ID（64位元）、短 ID（前12位元）或容器名稱") String containerIdOrName) {
        try {
            log.info("MCP: 啟動容器: {}", containerIdOrName);
            dockerService.startContainer(containerIdOrName);
            
            Map<String, Object> result = new HashMap<>();
            result.put("success", true);
            result.put("container", containerIdOrName);
            result.put("message", "容器啟動成功");
            
            log.info("MCP: 容器啟動成功: {}", containerIdOrName);
            return convertToJsonString(result);
            
        } catch (Exception e) {
            log.error("MCP: 啟動容器失敗", e);
            return createErrorResponse("啟動容器失敗: " + e.getMessage());
        }
    }

    /**
     * 停止容器
     * @param containerIdOrName 容器 ID 或名稱
     * @return 操作結果的 JSON 字串
     */
    @Tool(description = "停止正在運行的 Docker 容器。此工具會優雅地停止容器，發送 SIGTERM 信號後等待一段時間，如果容器未響應則強制停止。停止的容器可以重新啟動。")
    public String stopContainer(@ToolParam(description = "要停止的容器 ID 或名稱。可以是完整 ID、短 ID 或容器名稱") String containerIdOrName) {
        try {
            log.info("MCP: 停止容器: {}", containerIdOrName);
            dockerService.stopContainer(containerIdOrName);
            
            Map<String, Object> result = new HashMap<>();
            result.put("success", true);
            result.put("container", containerIdOrName);
            result.put("message", "容器停止成功");
            
            log.info("MCP: 容器停止成功: {}", containerIdOrName);
            return convertToJsonString(result);
            
        } catch (Exception e) {
            log.error("MCP: 停止容器失敗", e);
            return createErrorResponse("停止容器失敗: " + e.getMessage());
        }
    }

    /**
     * 移除容器
     * @param containerIdOrName 容器 ID 或名稱
     * @param force 是否強制移除
     * @return 操作結果的 JSON 字串
     */
    @Tool(description = "移除 Docker 容器。此工具會永久刪除容器及其檔案系統，但不會影響映像檔。注意：移除後容器內的數據將完全丟失，除非已掛載外部磁碟區。")
    public String removeContainer(@ToolParam(description = "要移除的容器 ID 或名稱") String containerIdOrName,
                                 @ToolParam(description = "是否強制移除。false：只能移除已停止的容器；true：可以移除運行中的容器（會先強制停止）") boolean force) {
        try {
            log.info("MCP: 移除容器: {}, 強制: {}", containerIdOrName, force);
            dockerService.removeContainer(containerIdOrName, force);
            
            Map<String, Object> result = new HashMap<>();
            result.put("success", true);
            result.put("container", containerIdOrName);
            result.put("force", force);
            result.put("message", "容器移除成功");
            
            log.info("MCP: 容器移除成功: {}", containerIdOrName);
            return convertToJsonString(result);
            
        } catch (Exception e) {
            log.error("MCP: 移除容器失敗", e);
            return createErrorResponse("移除容器失敗: " + e.getMessage());
        }
    }

    /**
     * 獲取容器日誌
     * @param containerIdOrName 容器 ID 或名稱
     * @param tail 顯示最後幾行日誌
     * @param follow 是否持續追蹤日誌
     * @return 操作結果的 JSON 字串
     */
    @Tool(description = "獲取 Docker 容器的日誌輸出。此工具用於查看容器的 stdout 和 stderr 輸出，幫助調試和監控應用程式。支援限制行數和即時追蹤模式。")
    public String getContainerLogs(@ToolParam(description = "容器 ID 或名稱") String containerIdOrName,
                                  @ToolParam(description = "顯示最後 N 行日誌。0 表示顯示所有日誌，建議使用適當數值避免輸出過多內容") int tail,
                                  @ToolParam(description = "是否持續追蹤新的日誌輸出。true：即時顯示新日誌；false：只顯示當前日誌") boolean follow) {
        try {
            log.info("MCP: 獲取容器日誌: {}, tail: {}, follow: {}", containerIdOrName, tail, follow);
            String logs = dockerService.fetchContainerLogs(containerIdOrName, tail, follow);
            
            Map<String, Object> result = new HashMap<>();
            result.put("success", true);
            result.put("container", containerIdOrName);
            result.put("logs", logs);
            result.put("tail", tail);
            result.put("follow", follow);
            result.put("message", "成功獲取容器日誌");
            
            log.info("MCP: 成功獲取容器日誌，長度: {} 字元", logs.length());
            return convertToJsonString(result);
            
        } catch (Exception e) {
            log.error("MCP: 獲取容器日誌失敗", e);
            return createErrorResponse("獲取容器日誌失敗: " + e.getMessage());
        }
    }

    // ================================
    // 映像檔管理 MCP Tools
    // ================================

    /**
     * 列出映像檔
     * @param showDangling 是否顯示懸掛映像檔
     * @return 映像檔資訊的 JSON 字串
     */
    @Tool(description = "列出本地 Docker 映像檔。此工具顯示所有已下載到本地的映像檔資訊，包括映像檔 ID、標籤、大小、建立時間等。用於管理本地映像檔存儲空間。")
    public String listImages(@ToolParam(description = "是否顯示懸掛映像檔（dangling images）。true：包含沒有標籤的中間映像檔；false：只顯示有標籤的映像檔") boolean showDangling) {
        try {
            log.info("MCP: 列出映像檔，顯示懸掛映像檔: {}", showDangling);
            List<Image> images = dockerService.listImages(showDangling);
            
            // 轉換為簡化的映像檔資訊
            List<Map<String, Object>> imageInfos = images.stream()
                    .map(this::convertImageToMap)
                    .collect(Collectors.toList());
            
            Map<String, Object> result = new HashMap<>();
            result.put("success", true);
            result.put("count", imageInfos.size());
            result.put("images", imageInfos);
            
            log.info("MCP: 成功列出 {} 個映像檔", imageInfos.size());
            return convertToJsonString(result);
            
        } catch (Exception e) {
            log.error("MCP: 列出映像檔失敗", e);
            return createErrorResponse("列出映像檔失敗: " + e.getMessage());
        }
    }

    /**
     * 拉取映像檔
     * @param imageName 映像檔名稱（包含標籤）
     * @return 操作結果的 JSON 字串
     */
    @Tool(description = "從 Docker Hub 或其他註冊庫拉取映像檔到本地。此工具會下載指定的映像檔及其所有層次，使其可用於建立容器。適用於部署新應用或更新現有映像檔。")
    public String pullImage(@ToolParam(description = "要拉取的映像檔名稱，包含標籤。格式：[註冊庫/]映像檔名[:標籤]，如：nginx、nginx:alpine、mysql:8.0、docker.io/library/ubuntu:20.04") String imageName) {
        try {
            log.info("MCP: 拉取映像檔: {}", imageName);
            boolean success = dockerService.pullImage(imageName);
            
            Map<String, Object> result = new HashMap<>();
            result.put("success", success);
            result.put("imageName", imageName);
            result.put("message", success ? "映像檔拉取成功" : "映像檔拉取失敗");
            
            log.info("MCP: 映像檔拉取{}: {}", success ? "成功" : "失敗", imageName);
            return convertToJsonString(result);
            
        } catch (Exception e) {
            log.error("MCP: 拉取映像檔失敗", e);
            return createErrorResponse("拉取映像檔失敗: " + e.getMessage());
        }
    }

    /**
     * 推送映像檔
     * @param imageName 映像檔名稱（包含標籤）
     * @return 操作結果的 JSON 字串
     */
    @Tool(description = "將本地映像檔推送到 Docker 註冊庫。此工具會上傳映像檔到遠端註冊庫，使其他人可以拉取使用。需要適當的認證和推送權限。")
    public String pushImage(@ToolParam(description = "要推送的映像檔名稱，必須包含註冊庫地址和標籤。格式：註冊庫/命名空間/映像檔名:標籤，如：myregistry.com/myproject/myapp:v1.0") String imageName) {
        try {
            log.info("MCP: 推送映像檔: {}", imageName);
            boolean success = dockerService.pushImage(imageName);
            
            Map<String, Object> result = new HashMap<>();
            result.put("success", success);
            result.put("imageName", imageName);
            result.put("message", success ? "映像檔推送成功" : "映像檔推送失敗");
            
            log.info("MCP: 映像檔推送{}: {}", success ? "成功" : "失敗", imageName);
            return convertToJsonString(result);
            
        } catch (Exception e) {
            log.error("MCP: 推送映像檔失敗", e);
            return createErrorResponse("推送映像檔失敗: " + e.getMessage());
        }
    }

    /**
     * 建構映像檔
     * @param dockerfilePath Dockerfile 路徑
     * @param imageName 映像檔名稱和標籤
     * @param buildContext 建構上下文目錄
     * @return 操作結果的 JSON 字串
     */
    @Tool(description = "從 Dockerfile 建構新的 Docker 映像檔。此工具會讀取 Dockerfile 指令，執行建構步驟，創建自定義映像檔。適用於應用程式部署和環境配置。")
    public String buildImage(@ToolParam(description = "Dockerfile 的絕對路徑。如：/path/to/Dockerfile 或 C:\\project\\Dockerfile") String dockerfilePath,
                            @ToolParam(description = "要建立的映像檔名稱和標籤，格式：名稱:標籤，如：myapp:latest、myproject/backend:v1.0") String imageName,
                            @ToolParam(description = "建構上下文目錄的絕對路徑，包含應用程式檔案和 Dockerfile。如：/path/to/project 或 C:\\project") String buildContext) {
        try {
            log.info("MCP: 建構映像檔: {} from {}", imageName, dockerfilePath);
            boolean success = dockerService.buildImage(dockerfilePath, imageName, buildContext);
            
            Map<String, Object> result = new HashMap<>();
            result.put("success", success);
            result.put("imageName", imageName);
            result.put("dockerfilePath", dockerfilePath);
            result.put("buildContext", buildContext);
            result.put("message", success ? "映像檔建構成功" : "映像檔建構失敗");
            
            log.info("MCP: 映像檔建構{}: {}", success ? "成功" : "失敗", imageName);
            return convertToJsonString(result);
            
        } catch (Exception e) {
            log.error("MCP: 建構映像檔失敗", e);
            return createErrorResponse("建構映像檔失敗: " + e.getMessage());
        }
    }

    /**
     * 移除映像檔
     * @param imageIdOrName 映像檔 ID 或名稱
     * @param force 是否強制移除
     * @return 操作結果的 JSON 字串
     */
    @Tool(description = "移除本地 Docker 映像檔以釋放磁碟空間。此工具會永久刪除映像檔，如果有容器正在使用該映像檔，需要使用強制選項。有助於清理不需要的映像檔。")
    public String removeImage(@ToolParam(description = "映像檔 ID、短 ID 或名稱:標籤，如：nginx:latest、abc123456789 或完整映像檔 ID") String imageIdOrName,
                             @ToolParam(description = "是否強制移除。false：只移除未被容器使用的映像檔；true：強制移除即使有容器在使用") boolean force) {
        try {
            log.info("MCP: 移除映像檔: {}, 強制: {}", imageIdOrName, force);
            dockerService.removeImage(imageIdOrName, force);
            
            Map<String, Object> result = new HashMap<>();
            result.put("success", true);
            result.put("image", imageIdOrName);
            result.put("force", force);
            result.put("message", "映像檔移除成功");
            
            log.info("MCP: 映像檔移除成功: {}", imageIdOrName);
            return convertToJsonString(result);
            
        } catch (Exception e) {
            log.error("MCP: 移除映像檔失敗", e);
            return createErrorResponse("移除映像檔失敗: " + e.getMessage());
        }
    }

    // ================================
    // 網路管理 MCP Tools
    // ================================

    /**
     * 列出網路
     * @return 網路資訊的 JSON 字串
     */
    @Tool(description = "列出所有 Docker 網路。此工具顯示 Docker 環境中的網路配置，包括預設網路（bridge、host、none）和自定義網路。用於了解容器網路連接配置。")
    public String listNetworks() {
        try {
            log.info("MCP: 列出網路");
            List<Network> networks = dockerService.listNetworks();
            
            // 轉換為簡化的網路資訊
            List<Map<String, Object>> networkInfos = networks.stream()
                    .map(this::convertNetworkToMap)
                    .collect(Collectors.toList());
            
            Map<String, Object> result = new HashMap<>();
            result.put("success", true);
            result.put("count", networkInfos.size());
            result.put("networks", networkInfos);
            
            log.info("MCP: 成功列出 {} 個網路", networkInfos.size());
            return convertToJsonString(result);
            
        } catch (Exception e) {
            log.error("MCP: 列出網路失敗", e);
            return createErrorResponse("列出網路失敗: " + e.getMessage());
        }
    }

    /**
     * 建立網路
     * @param networkName 網路名稱
     * @param driver 網路驅動程式（bridge, overlay, host, none）
     * @return 操作結果的 JSON 字串
     */
    @Tool(description = "建立自定義 Docker 網路。此工具可以創建隔離的網路環境，讓容器間進行安全通信。支援多種網路驅動程式，適用於微服務架構和多容器應用。")
    public String createNetwork(@ToolParam(description = "網路名稱，必須唯一。建議使用描述性名稱，如：frontend-network、database-network") String networkName,
                               @ToolParam(description = "網路驅動程式類型。bridge：預設類型，適合單機多容器通信；overlay：適合跨主機通信；host：使用主機網路；none：無網路連接") String driver) {
        try {
            log.info("MCP: 建立網路: {}, 驅動程式: {}", networkName, driver);
            String networkId = dockerService.createNetwork(networkName, driver);
            
            Map<String, Object> result = new HashMap<>();
            result.put("success", true);
            result.put("networkId", networkId);
            result.put("networkName", networkName);
            result.put("driver", driver);
            result.put("message", "網路建立成功");
            
            log.info("MCP: 網路建立成功 - ID: {}", networkId);
            return convertToJsonString(result);
            
        } catch (Exception e) {
            log.error("MCP: 建立網路失敗", e);
            return createErrorResponse("建立網路失敗: " + e.getMessage());
        }
    }

    /**
     * 移除網路
     * @param networkIdOrName 網路 ID 或名稱
     * @return 操作結果的 JSON 字串
     */
    @Tool(description = "移除 Docker 網路。此工具會刪除自定義網路，釋放網路資源。注意：無法移除預設網路（bridge、host、none），且網路上不能有連接的容器。")
    public String removeNetwork(@ToolParam(description = "要移除的網路 ID 或名稱。不能是預設網路（bridge、host、none），且網路上不能有運行中的容器") String networkIdOrName) {
        try {
            log.info("MCP: 移除網路: {}", networkIdOrName);
            dockerService.removeNetwork(networkIdOrName);
            
            Map<String, Object> result = new HashMap<>();
            result.put("success", true);
            result.put("network", networkIdOrName);
            result.put("message", "網路移除成功");
            
            log.info("MCP: 網路移除成功: {}", networkIdOrName);
            return convertToJsonString(result);
            
        } catch (Exception e) {
            log.error("MCP: 移除網路失敗", e);
            return createErrorResponse("移除網路失敗: " + e.getMessage());
        }
    }

    // ================================
    // 磁碟區管理 MCP Tools
    // ================================

    /**
     * 列出磁碟區
     * @return 磁碟區資訊的 JSON 字串
     */
    @Tool(description = "列出所有 Docker 磁碟區。此工具顯示 Docker 管理的持久化儲存磁碟區，包括命名磁碟區和匿名磁碟區。用於管理容器數據持久化和共享。")
    public String listVolumes() {
        try {
            log.info("MCP: 列出磁碟區");
            List<?> volumes = dockerService.listVolumes();
            
            Map<String, Object> result = new HashMap<>();
            result.put("success", true);
            result.put("count", volumes.size());
            result.put("volumes", volumes);
            
            log.info("MCP: 成功列出 {} 個磁碟區", volumes.size());
            return convertToJsonString(result);
            
        } catch (Exception e) {
            log.error("MCP: 列出磁碟區失敗", e);
            return createErrorResponse("列出磁碟區失敗: " + e.getMessage());
        }
    }

    /**
     * 建立磁碟區
     * @param volumeName 磁碟區名稱
     * @param driver 磁碟區驅動程式
     * @param driverOptsJson 驅動程式選項的 JSON 字串
     * @return 操作結果的 JSON 字串
     */
    @Tool(description = "建立 Docker 磁碟區用於數據持久化。此工具創建命名磁碟區，讓容器數據在容器重啟或重建後仍然保存。適用於資料庫、配置檔案等需要持久化的數據。")
    public String createVolume(@ToolParam(description = "磁碟區名稱，必須唯一。建議使用描述性名稱，如：mysql-data、app-config") String volumeName,
                              @ToolParam(description = "磁碟區驅動程式。local：本地檔案系統（預設）；其他驅動程式需要額外安裝") String driver,
                              @ToolParam(description = "驅動程式選項的 JSON 字串，格式：{\"選項名\":\"值\"}。如：{\"type\":\"nfs\",\"device\":\":/path\"}。空字串或 {} 表示使用預設選項") String driverOptsJson) {
        try {
            log.info("MCP: 建立磁碟區: {}, 驅動程式: {}", volumeName, driver);
            
            Map<String, String> driverOpts = parseJsonToMap(driverOptsJson);
            String createdVolumeName = dockerService.createVolume(volumeName, driver, driverOpts);
            
            Map<String, Object> result = new HashMap<>();
            result.put("success", true);
            result.put("volumeName", createdVolumeName);
            result.put("driver", driver);
            result.put("driverOpts", driverOpts);
            result.put("message", "磁碟區建立成功");
            
            log.info("MCP: 磁碟區建立成功: {}", createdVolumeName);
            return convertToJsonString(result);
            
        } catch (Exception e) {
            log.error("MCP: 建立磁碟區失敗", e);
            return createErrorResponse("建立磁碟區失敗: " + e.getMessage());
        }
    }

    /**
     * 移除磁碟區
     * @param volumeName 磁碟區名稱
     * @param force 是否強制移除
     * @return 操作結果的 JSON 字串
     */
    @Tool(description = "移除 Docker 磁碟區以釋放儲存空間。此工具會永久刪除磁碟區及其所有數據。注意：刪除後數據無法恢復，確保沒有容器正在使用該磁碟區。")
    public String removeVolume(@ToolParam(description = "要移除的磁碟區名稱") String volumeName,
                              @ToolParam(description = "是否強制移除。false：只移除未被使用的磁碟區；true：強制移除即使有容器正在使用（危險操作）") boolean force) {
        try {
            log.info("MCP: 移除磁碟區: {}, 強制: {}", volumeName, force);
            dockerService.removeVolume(volumeName, force);
            
            Map<String, Object> result = new HashMap<>();
            result.put("success", true);
            result.put("volume", volumeName);
            result.put("force", force);
            result.put("message", "磁碟區移除成功");
            
            log.info("MCP: 磁碟區移除成功: {}", volumeName);
            return convertToJsonString(result);
            
        } catch (Exception e) {
            log.error("MCP: 移除磁碟區失敗", e);
            return createErrorResponse("移除磁碟區失敗: " + e.getMessage());
        }
    }

    // ================================
    // 系統資訊 MCP Tools
    // ================================

    /**
     * 獲取 Docker 版本資訊
     * @return Docker 版本資訊的 JSON 字串
     */
    @Tool(description = "獲取 Docker 引擎版本資訊。此工具顯示 Docker 版本、API 版本、作業系統等系統資訊。用於診斷環境問題和確認 Docker 安裝狀態。")
    public String getDockerVersion() {
        try {
            log.info("MCP: 獲取 Docker 版本資訊");
            String dockerVersion = dockerService.getDockerVersion();
            String apiVersion = dockerService.getApiVersion();
            
            Map<String, Object> result = new HashMap<>();
            result.put("success", true);
            result.put("dockerVersion", dockerVersion);
            result.put("apiVersion", apiVersion);
            result.put("message", "成功獲取 Docker 版本資訊");
            
            log.info("MCP: 成功獲取 Docker 版本資訊");
            return convertToJsonString(result);
            
        } catch (Exception e) {
            log.error("MCP: 獲取 Docker 版本資訊失敗", e);
            return createErrorResponse("獲取 Docker 版本資訊失敗: " + e.getMessage());
        }
    }

    // ================================
    // 輔助方法 (Helper Methods)
    // ================================

    /**
     * 將容器物件轉換為 Map
     * @param container 容器物件
     * @return 容器資訊 Map
     */
    private Map<String, Object> convertContainerToMap(Container container) {
        Map<String, Object> containerInfo = new HashMap<>();
        containerInfo.put("id", container.getId());
        
        // 正確處理 String[] 陣列
        containerInfo.put("names", container.getNames() != null ? 
            java.util.Arrays.asList(container.getNames()) : null);
            
        containerInfo.put("image", container.getImage());
        containerInfo.put("imageId", container.getImageId());
        containerInfo.put("command", container.getCommand());
        containerInfo.put("created", container.getCreated());
        containerInfo.put("status", container.getStatus());
        containerInfo.put("state", container.getState());
        
        // 端口資訊 - 轉換為 List
        if (container.getPorts() != null && container.getPorts().length > 0) {
            containerInfo.put("ports", java.util.Arrays.asList(container.getPorts()));
        }
        
        // 標籤資訊
        if (container.getLabels() != null) {
            containerInfo.put("labels", container.getLabels());
        }
        
        return containerInfo;
    }

    /**
     * 將映像檔物件轉換為 Map
     * @param image 映像檔物件
     * @return 映像檔資訊 Map
     */
    private Map<String, Object> convertImageToMap(Image image) {
        Map<String, Object> imageInfo = new HashMap<>();
        imageInfo.put("id", image.getId());
        imageInfo.put("parentId", image.getParentId());
        
        // 正確處理 String[] 陣列
        imageInfo.put("repoTags", image.getRepoTags() != null ? 
            java.util.Arrays.asList(image.getRepoTags()) : null);
        imageInfo.put("repoDigests", image.getRepoDigests() != null ? 
            java.util.Arrays.asList(image.getRepoDigests()) : null);
            
        imageInfo.put("created", image.getCreated());
        imageInfo.put("size", image.getSize());
        imageInfo.put("virtualSize", image.getVirtualSize());
        
        // 標籤資訊
        if (image.getLabels() != null) {
            imageInfo.put("labels", image.getLabels());
        }
        
        return imageInfo;
    }

    /**
     * 將網路物件轉換為 Map
     * @param network 網路物件
     * @return 網路資訊 Map
     */
    private Map<String, Object> convertNetworkToMap(Network network) {
        Map<String, Object> networkInfo = new HashMap<>();
        networkInfo.put("id", network.getId());
        networkInfo.put("name", network.getName());
        networkInfo.put("driver", network.getDriver());
        networkInfo.put("scope", network.getScope());
        
        // IPAM 資訊
        if (network.getIpam() != null) {
            networkInfo.put("ipam", network.getIpam());
        }
        
        // 標籤資訊
        if (network.getLabels() != null) {
            networkInfo.put("labels", network.getLabels());
        }
        
        return networkInfo;
    }

    /**
     * 將 JSON 字串解析為 Map
     * @param jsonString JSON 字串
     * @return Map 物件
     */
    private Map<String, String> parseJsonToMap(String jsonString) {
        Map<String, String> map = new HashMap<>();
        
        if (jsonString == null || jsonString.trim().isEmpty() || "{}".equals(jsonString.trim())) {
            return map;
        }
        
        try {
            // 簡單的 JSON 解析（僅處理字串鍵值對）
            String content = jsonString.trim();
            if (content.startsWith("{") && content.endsWith("}")) {
                content = content.substring(1, content.length() - 1);
                if (!content.trim().isEmpty()) {
                    String[] pairs = content.split(",");
                    for (String pair : pairs) {
                        String[] keyValue = pair.split(":");
                        if (keyValue.length == 2) {
                            String key = keyValue[0].trim().replaceAll("\"", "");
                            String value = keyValue[1].trim().replaceAll("\"", "");
                            map.put(key, value);
                        }
                    }
                }
            }
        } catch (Exception e) {
            log.warn("解析 JSON 字串失敗: {}", jsonString, e);
        }
        
        return map;
    }

    /**
     * 將物件轉換為 JSON 字串（簡化版本）
     * @param object 要轉換的物件
     * @return JSON 字串
     */
    private String convertToJsonString(Object object) {
        try {
            // 直接創建ObjectMapper實例以正確處理Docker Java API物件
            ObjectMapper mapper = new ObjectMapper();
            mapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
            mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
            mapper.setVisibility(PropertyAccessor.FIELD, JsonAutoDetect.Visibility.ANY);
            mapper.setVisibility(PropertyAccessor.GETTER, JsonAutoDetect.Visibility.ANY);
            mapper.setVisibility(PropertyAccessor.SETTER, JsonAutoDetect.Visibility.NONE);
            
            return mapper.writeValueAsString(object);
        } catch (Exception e) {
            log.error("JSON 序列化失敗: {}", e.getMessage(), e);
            // 後備機制：若Jackson序列化失敗，返回null字串
            return "null";
        }
    }

    /**
     * 建立錯誤回應
     * @param errorMessage 錯誤訊息
     * @return 錯誤回應的 JSON 字串
     */
    private String createErrorResponse(String errorMessage) {
        Map<String, Object> errorResponse = new HashMap<>();
        errorResponse.put("success", false);
        errorResponse.put("error", errorMessage);
        return convertToJsonString(errorResponse);
    }
}