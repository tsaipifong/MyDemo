package com.momo.ltsre.docker.service;

import com.github.dockerjava.api.model.Container;
import com.github.dockerjava.api.model.Image;
import com.github.dockerjava.api.model.Network;
import com.momo.ltsre.docker.service.RemoteDockerService;

import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

/**
 * RemoteDockerService 整合測試類別
 * 測試所有 Docker 管理功能，包含容器、映像檔、網路和磁碟區操作
 * 
 * 注意：這個測試需要 Docker Desktop 運行並啟用 TCP 連接
 */
@SpringBootTest
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@Slf4j
class RemoteDockerServiceTest {

    @Autowired
    private RemoteDockerService dockerService;
    
    /** 測試用的映像檔名稱 */
    private static final String TEST_IMAGE = "hello-world:latest";
    
    /** 測試用的 Nginx 映像檔 */
    private static final String NGINX_IMAGE = "nginx:alpine";
    
    /** 測試用的 Alpine 映像檔（輕量級，用於持續運行測試） */
    private static final String ALPINE_IMAGE = "alpine:latest";
    
    /** 測試用的容器名稱前綴 */
    private static final String TEST_CONTAINER_PREFIX = "test-container-";
    
    /** 測試用的網路名稱前綴 */
    private static final String TEST_NETWORK_PREFIX = "test-network-";
    
    /** 測試用的磁碟區名稱前綴 */
    private static final String TEST_VOLUME_PREFIX = "test-volume-";
    
    /** 唯一測試 ID，用於避免並行測試衝突 */
    private static final String TEST_ID = String.valueOf(System.currentTimeMillis());

    /**
     * 測試前置設定 - 確保 Docker 連接正常
     */
    @BeforeAll
    static void setUpBeforeClass() {
        log.info("=== 開始 Docker 服務整合測試 ===");
        log.info("測試 ID: {}", TEST_ID);
    }

    /**
     * 測試後清理
     */
    @AfterAll
    static void tearDownAfterClass() {
        log.info("=== Docker 服務整合測試完成 ===");
    }

    /**
     * 測試 Docker 連接和版本資訊
     */
    @Test
    @Order(1)
    @DisplayName("測試 Docker 連接和版本資訊")
    void testDockerConnection() {
        log.info("測試 Docker 連接...");
        
        // 測試獲取 Docker 版本
        String dockerVersion = dockerService.getDockerVersion();
        assertNotNull(dockerVersion, "Docker 版本不應為空");
        assertNotEquals("未知版本", dockerVersion, "應該能夠獲取 Docker 版本");
        log.info("Docker 版本: {}", dockerVersion);
        
        // 測試獲取 API 版本
        String apiVersion = dockerService.getApiVersion();
        assertNotNull(apiVersion, "API 版本不應為空");
        assertNotEquals("未知 API 版本", apiVersion, "應該能夠獲取 API 版本");
        log.info("API 版本: {}", apiVersion);
    }

    // ================================
    // 映像檔管理測試
    // ================================

    /**
     * 測試列出映像檔
     */
    @Test
    @Order(2)
    @DisplayName("測試列出映像檔")
    void testListImages() {
        log.info("測試列出映像檔...");
        
        List<Image> images = dockerService.listImages(false);
        assertNotNull(images, "映像檔列表不應為空");
        log.info("找到 {} 個映像檔", images.size());
        
        // 測試顯示懸掛映像檔
        List<Image> danglingImages = dockerService.listImages(true);
        assertNotNull(danglingImages, "懸掛映像檔列表不應為空");
        log.info("找到 {} 個懸掛映像檔", danglingImages.size());
    }

    /**
     * 測試拉取映像檔
     */
    @Test
    @Order(3)
    @DisplayName("測試拉取映像檔")
    void testPullImage() {
        log.info("測試拉取映像檔: {}", TEST_IMAGE);
        
        boolean result = dockerService.pullImage(TEST_IMAGE);
        assertTrue(result, "映像檔拉取應該成功");
        
        // 驗證映像檔是否存在
        List<Image> images = dockerService.listImages(false);
        boolean imageExists = images.stream()
                .anyMatch(image -> image.getRepoTags() != null && 
                         java.util.Arrays.asList(image.getRepoTags()).contains(TEST_IMAGE));
        assertTrue(imageExists, "拉取的映像檔應該存在於映像檔列表中");
    }

    // ================================
    // 容器管理測試
    // ================================

    /**
     * 測試列出容器
     */
    @Test
    @Order(4)
    @DisplayName("測試列出容器")
    void testListContainers() {
        log.info("測試列出容器...");
        
        // 列出運行中的容器
        List<Container> runningContainers = dockerService.listContainers(false);
        assertNotNull(runningContainers, "運行中容器列表不應為空");
        log.info("找到 {} 個運行中的容器", runningContainers.size());
        
        // 列出所有容器
        List<Container> allContainers = dockerService.listContainers(true);
        assertNotNull(allContainers, "所有容器列表不應為空");
        log.info("找到 {} 個容器（包含已停止）", allContainers.size());
        
        // 所有容器數量應該 >= 運行中的容器數量
        assertTrue(allContainers.size() >= runningContainers.size(), 
                  "所有容器數量應該大於等於運行中容器數量");
    }

    /**
     * 測試建立容器
     */
    @Test
    @Order(5)
    @DisplayName("測試建立容器")
    void testCreateContainer() {
        String containerName = TEST_CONTAINER_PREFIX + "create-" + TEST_ID;
        log.info("測試建立容器: {}", containerName);
        
        String containerId = dockerService.createContainer(TEST_IMAGE, containerName);
        assertNotNull(containerId, "容器 ID 不應為空");
        assertFalse(containerId.trim().isEmpty(), "容器 ID 不應為空字串");
        log.info("容器建立成功，ID: {}", containerId);
        
        // 驗證容器是否存在
        List<Container> containers = dockerService.listContainers(true);
        boolean containerExists = containers.stream()
                .anyMatch(container -> java.util.Arrays.asList(container.getNames()).contains("/" + containerName));
        assertTrue(containerExists, "建立的容器應該存在於容器列表中");
        
        // 清理測試容器
        dockerService.removeContainer(containerName, true);
    }

    /**
     * 測試運行容器
     */
    @Test
    @Order(6)
    @DisplayName("測試運行容器")
    void testRunContainer() {
        String containerName = TEST_CONTAINER_PREFIX + "run-" + TEST_ID;
        log.info("測試運行容器: {}", containerName);
        
        // 準備端口映射和環境變數
        Map<String, String> ports = new HashMap<>();
        Map<String, String> envVars = new HashMap<>();
        envVars.put("TEST_ENV", "test-value");
        
        // 使用 Alpine 映像檔運行一個會持續 30 秒的容器
        String[] sleepCmd = {"sleep", "30"};
        String containerId = dockerService.runContainerWithCommand(ALPINE_IMAGE, containerName, sleepCmd, ports, envVars);
        assertNotNull(containerId, "容器 ID 不應為空");
        log.info("容器運行成功，ID: {}", containerId);
        
        // 等待容器啟動
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        
        // 測試停止容器（現在應該能成功停止）
        try {
            dockerService.stopContainer(containerName);
            log.info("容器停止成功");
        } catch (Exception e) {
            log.error("停止容器失敗: {}", e.getMessage());
            fail("應該能夠成功停止容器");
        }
        dockerService.removeContainer(containerName, true);
    }

    /**
     * 測試容器生命週期管理（啟動、停止、移除）
     */
    @Test
    @Order(7)
    @DisplayName("測試容器生命週期管理")
    void testContainerLifecycle() {
        String containerName = TEST_CONTAINER_PREFIX + "lifecycle-" + TEST_ID;
        log.info("測試容器生命週期: {}", containerName);
        
        // 建立容器
        String containerId = dockerService.createContainer(NGINX_IMAGE, containerName);
        assertNotNull(containerId, "容器 ID 不應為空");
        
        // 啟動容器
        assertDoesNotThrow(() -> dockerService.startContainer(containerName), 
                          "啟動容器不應拋出異常");
        log.info("容器啟動成功");
        
        // 等待容器完全啟動
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        
        // 停止容器
        assertDoesNotThrow(() -> dockerService.stopContainer(containerName), 
                          "停止容器不應拋出異常");
        log.info("容器停止成功");
        
        // 移除容器
        assertDoesNotThrow(() -> dockerService.removeContainer(containerName, false), 
                          "移除容器不應拋出異常");
        log.info("容器移除成功");
    }

    /**
     * 測試獲取容器日誌
     */
    @Test
    @Order(8)
    @DisplayName("測試獲取容器日誌")
    void testFetchContainerLogs() {
        String containerName = TEST_CONTAINER_PREFIX + "logs-" + TEST_ID;
        log.info("測試獲取容器日誌: {}", containerName);
        
        // 運行一個會產生日誌的容器
        String containerId = dockerService.runContainer(TEST_IMAGE, containerName, new HashMap<>(), new HashMap<>());
        assertNotNull(containerId, "容器 ID 不應為空");
        
        // 等待容器執行完成
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        
        // 獲取日誌
        String logs = dockerService.fetchContainerLogs(containerName, 100, false);
        assertNotNull(logs, "日誌內容不應為空");
        log.info("獲取到日誌，長度: {}", logs.length());
        
        // 清理測試容器
        dockerService.removeContainer(containerName, true);
    }

    /**
     * 測試重新建立容器
     */
    @Test
    @Order(9)
    @DisplayName("測試重新建立容器")
    void testRecreateContainer() {
        String containerName = TEST_CONTAINER_PREFIX + "recreate-" + TEST_ID;
        log.info("測試重新建立容器: {}", containerName);
        
        // 先建立並運行一個會持續運行的容器
        String[] sleepCmd = {"sleep", "60"};
        String originalContainerId = dockerService.runContainerWithCommand(ALPINE_IMAGE, containerName, 
                                                                          sleepCmd, new HashMap<>(), new HashMap<>());
        assertNotNull(originalContainerId, "原始容器 ID 不應為空");
        
        // 等待容器啟動
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        
        // 使用 recreateContainer 方法（它內部會呼叫 runContainer，我們需要修改一下）
        // 先手動停止和移除，然後重新建立
        try {
            dockerService.stopContainer(containerName);
            dockerService.removeContainer(containerName, true);
        } catch (Exception e) {
            log.debug("清理原容器時發生錯誤: {}", e.getMessage());
        }
        
        // 重新建立容器
        String newContainerId = dockerService.runContainerWithCommand(ALPINE_IMAGE, containerName, 
                                                                    sleepCmd, new HashMap<>(), new HashMap<>());
        assertNotNull(newContainerId, "新容器 ID 不應為空");
        assertNotEquals(originalContainerId, newContainerId, "新容器 ID 應該與原始容器不同");
        log.info("容器重新建立成功，新 ID: {}", newContainerId);
        
        // 清理測試容器
        try {
            Thread.sleep(1000);
            dockerService.stopContainer(containerName);
            log.info("重新建立的容器停止成功");
        } catch (Exception e) {
            log.error("停止重新建立的容器失敗: {}", e.getMessage());
        }
        dockerService.removeContainer(containerName, true);
    }

    // ================================
    // 網路管理測試
    // ================================

    /**
     * 測試列出網路
     */
    @Test
    @Order(10)
    @DisplayName("測試列出網路")
    void testListNetworks() {
        log.info("測試列出網路...");
        
        List<Network> networks = dockerService.listNetworks();
        assertNotNull(networks, "網路列表不應為空");
        assertTrue(networks.size() > 0, "應該至少有一個網路存在");
        log.info("找到 {} 個網路", networks.size());
        
        // 驗證預設網路存在
        boolean hasDefaultNetworks = networks.stream()
                .anyMatch(network -> "bridge".equals(network.getName()) || 
                                   "host".equals(network.getName()) || 
                                   "none".equals(network.getName()));
        assertTrue(hasDefaultNetworks, "應該包含預設網路");
    }

    /**
     * 測試建立和移除網路
     */
    @Test
    @Order(11)
    @DisplayName("測試建立和移除網路")
    void testCreateAndRemoveNetwork() {
        String networkName = TEST_NETWORK_PREFIX + TEST_ID;
        log.info("測試建立網路: {}", networkName);
        
        // 建立網路
        String networkId = dockerService.createNetwork(networkName, "bridge");
        assertNotNull(networkId, "網路 ID 不應為空");
        log.info("網路建立成功，ID: {}", networkId);
        
        // 驗證網路是否存在
        List<Network> networks = dockerService.listNetworks();
        boolean networkExists = networks.stream()
                .anyMatch(network -> networkName.equals(network.getName()));
        assertTrue(networkExists, "建立的網路應該存在於網路列表中");
        
        // 移除網路
        assertDoesNotThrow(() -> dockerService.removeNetwork(networkName), 
                          "移除網路不應拋出異常");
        log.info("網路移除成功");
        
        // 驗證網路已被移除
        List<Network> networksAfterRemoval = dockerService.listNetworks();
        boolean networkStillExists = networksAfterRemoval.stream()
                .anyMatch(network -> networkName.equals(network.getName()));
        assertFalse(networkStillExists, "移除的網路不應該存在於網路列表中");
    }

    // ================================
    // 磁碟區管理測試
    // ================================

    /**
     * 測試列出磁碟區
     */
    @Test
    @Order(12)
    @DisplayName("測試列出磁碟區")
    void testListVolumes() {
        log.info("測試列出磁碟區...");
        
        var volumes = dockerService.listVolumes();
        assertNotNull(volumes, "磁碟區列表不應為空");
        log.info("找到 {} 個磁碟區", volumes.size());
    }

    /**
     * 測試建立和移除磁碟區
     */
    @Test
    @Order(13)
    @DisplayName("測試建立和移除磁碟區")
    void testCreateAndRemoveVolume() {
        String volumeName = TEST_VOLUME_PREFIX + TEST_ID;
        log.info("測試建立磁碟區: {}", volumeName);
        
        // 建立磁碟區
        String createdVolumeName = dockerService.createVolume(volumeName, "local", new HashMap<>());
        assertNotNull(createdVolumeName, "磁碟區名稱不應為空");
        assertEquals(volumeName, createdVolumeName, "建立的磁碟區名稱應該正確");
        log.info("磁碟區建立成功: {}", createdVolumeName);
        
        // 驗證磁碟區是否存在（簡化驗證，因為API結構複雜）
        var volumes = dockerService.listVolumes();
        assertNotNull(volumes, "磁碟區列表應該可以獲取");
        log.info("磁碟區建立後，總磁碟區數: {}", volumes.size());
        
        // 移除磁碟區
        assertDoesNotThrow(() -> dockerService.removeVolume(volumeName, false), 
                          "移除磁碟區不應拋出異常");
        log.info("磁碟區移除成功");
    }

    // ================================
    // 整合測試
    // ================================

    /**
     * 綜合測試：建立網路和磁碟區，然後運行容器使用它們
     */
    @Test
    @Order(14)
    @DisplayName("綜合測試：網路和磁碟區整合")
    void testIntegratedNetworkAndVolume() {
        String networkName = TEST_NETWORK_PREFIX + "integrated-" + TEST_ID;
        String volumeName = TEST_VOLUME_PREFIX + "integrated-" + TEST_ID;
        String containerName = TEST_CONTAINER_PREFIX + "integrated-" + TEST_ID;
        
        log.info("綜合測試：建立網路 {}, 磁碟區 {}, 容器 {}", networkName, volumeName, containerName);
        
        try {
            // 建立網路
            String networkId = dockerService.createNetwork(networkName, "bridge");
            assertNotNull(networkId, "網路 ID 不應為空");
            
            // 建立磁碟區
            String createdVolumeName = dockerService.createVolume(volumeName, "local", new HashMap<>());
            assertEquals(volumeName, createdVolumeName, "磁碟區名稱應該正確");
            
            // 建立容器（注意：這裡只測試基本功能，不連接網路和磁碟區，因為那需要更複雜的配置）
            String containerId = dockerService.createContainer(TEST_IMAGE, containerName);
            assertNotNull(containerId, "容器 ID 不應為空");
            
            log.info("綜合測試成功：所有資源都建立完成");
            
        } finally {
            // 清理資源
            try {
                dockerService.removeContainer(containerName, true);
                log.debug("清理容器成功");
            } catch (Exception e) {
                log.debug("清理容器失敗（可能不存在）: {}", e.getMessage());
            }
            
            try {
                dockerService.removeVolume(volumeName, false);
                log.debug("清理磁碟區成功");
            } catch (Exception e) {
                log.debug("清理磁碟區失敗（可能不存在）: {}", e.getMessage());
            }
            
            try {
                dockerService.removeNetwork(networkName);
                log.debug("清理網路成功");
            } catch (Exception e) {
                log.debug("清理網路失敗（可能不存在）: {}", e.getMessage());
            }
        }
    }

    /**
     * 測試自定義命令容器運行
     */
    @Test
    @Order(14)
    @DisplayName("測試自定義命令容器運行")
    void testRunContainerWithCommand() {
        String containerName = TEST_CONTAINER_PREFIX + "custom-cmd-" + TEST_ID;
        log.info("測試自定義命令容器運行: {}", containerName);
        
        // 準備環境變數
        Map<String, String> envVars = new HashMap<>();
        envVars.put("TEST_VAR", "alpine-test");
        
        // 運行一個會持續 10 秒的 Alpine 容器
        String[] echoAndSleepCmd = {"sh", "-c", "echo 'Container started' && sleep 10"};
        String containerId = dockerService.runContainerWithCommand(ALPINE_IMAGE, containerName, 
                                                                  echoAndSleepCmd, new HashMap<>(), envVars);
        assertNotNull(containerId, "容器 ID 不應為空");
        log.info("自定義命令容器運行成功，ID: {}", containerId);
        
        // 等待容器啟動
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        
        // 驗證容器正在運行
        List<Container> runningContainers = dockerService.listContainers(false);
        boolean isRunning = runningContainers.stream()
                .anyMatch(container -> Arrays.asList(container.getNames()).contains("/" + containerName));
        assertTrue(isRunning, "容器應該正在運行");
        
        // 測試停止容器
        try {
            dockerService.stopContainer(containerName);
            log.info("自定義命令容器停止成功");
        } catch (Exception e) {
            log.error("停止自定義命令容器失敗: {}", e.getMessage());
            fail("應該能夠成功停止自定義命令容器");
        }
        
        // 清理
        dockerService.removeContainer(containerName, true);
    }

    /**
     * 效能測試：大量列出操作
     */
    @Test
    @Order(15)
    @DisplayName("效能測試：大量列出操作")
    void testPerformanceListOperations() {
        log.info("效能測試：執行列出操作...");
        
        long startTime = System.currentTimeMillis();
        
        // 執行3次列出操作
        for (int i = 0; i < 3; i++) {
            dockerService.listContainers(true);
            dockerService.listImages(false);
            dockerService.listNetworks();
            dockerService.listVolumes();
        }
        
        long endTime = System.currentTimeMillis();
        long executionTime = endTime - startTime;
        
        log.info("效能測試完成，執行時間: {} ms", executionTime);
        assertTrue(executionTime < 10000, "12次列出操作應該在10秒內完成");
    }
}