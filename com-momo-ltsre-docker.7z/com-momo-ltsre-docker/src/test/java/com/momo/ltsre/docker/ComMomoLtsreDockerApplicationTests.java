package com.momo.ltsre.docker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * 應用程式基本測試類別
 * 測試 Spring Boot 應用程式上下文是否正常載入
 */
@SpringBootTest
class ComMomoLtsreDockerApplicationTests {

	/**
	 * 測試應用程式上下文載入
	 */
	@Test
	void contextLoads() {
		// 此測試確保 Spring Boot 應用程式上下文能夠正常載入
		// 如果上下文載入失敗，此測試將失敗
	}
}